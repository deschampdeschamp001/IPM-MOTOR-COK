import React from 'react';
import { Link } from '../../router/Router';

export interface BodyTypeItem {
  id: string;
  name: string;
  count?: number;
  svgPath: React.ReactNode;
}

export const BODY_TYPES: { id: string; name: string; description: string; svg: React.ReactNode }[] = [
  {
    id: 'SUV',
    name: 'SUV',
    description: 'Espace & Prestige 4x4',
    svg: (
      <svg viewBox="0 0 100 45" className="w-full h-full" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        {/* Sleek SUV silhouette */}
        <path d="M5 33 L15 33 M32 33 L68 33 M85 33 L95 33" />
        <circle cx="23" cy="33" r="7" strokeWidth="1.5" />
        <circle cx="76" cy="33" r="7" strokeWidth="1.5" />
        <path d="M8 29 L14 20 L26 19 L40 10 L72 10 L88 20 L94 25 L94 30 L85 30" />
        <path d="M42 12 L70 12 L84 20 L42 20 Z" />
        <line x1="56" y1="12" x2="56" y2="20" />
        {/* Ground clearance line */}
      </svg>
    )
  },
  {
    id: 'Berline',
    name: 'Berline',
    description: 'Élégance & Aérodynamisme',
    svg: (
      <svg viewBox="0 0 100 45" className="w-full h-full" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        {/* Sleek Sedan silhouette */}
        <path d="M5 35 L14 35 M31 35 L69 35 M86 35 L95 35" />
        <circle cx="22" cy="35" r="6.5" strokeWidth="1.5" />
        <circle cx="77" cy="35" r="6.5" strokeWidth="1.5" />
        <path d="M6 31 L14 26 L27 25 L41 15 L66 15 L82 25 L95 28 L95 32 L86 32" />
        <path d="M43 17 L64 17 L77 24 L43 24 Z" />
        <line x1="54" y1="17" x2="54" y2="24" />
      </svg>
    )
  },
  {
    id: 'Pick-up',
    name: 'Pick-up',
    description: 'Puissance & Franchissement',
    svg: (
      <svg viewBox="0 0 100 45" className="w-full h-full" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        {/* Rugged Pickup silhouette */}
        <path d="M5 33 L14 33 M32 33 L67 33 M85 33 L95 33" />
        <circle cx="23" cy="33" r="7.5" strokeWidth="1.5" />
        <circle cx="76" cy="33" r="7.5" strokeWidth="1.5" />
        <path d="M8 29 L16 19 L25 18 L36 11 L58 11 L60 21 L93 21 L93 30 L85 30" />
        <path d="M38 13 L56 13 L57 20 L38 20 Z" />
        <line x1="47" y1="13" x2="47" y2="20" />
        <line x1="60" y1="15" x2="60" y2="21" strokeDasharray="2 2" />
      </svg>
    )
  },
  {
    id: 'Électrique',
    name: 'Électrique',
    description: 'Innovation 0 Émission',
    svg: (
      <svg viewBox="0 0 100 45" className="w-full h-full" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        {/* Fastback Electric with bolt */}
        <path d="M5 34 L15 34 M31 34 L69 34 M85 34 L95 34" />
        <circle cx="23" cy="34" r="6.5" strokeWidth="1.5" />
        <circle cx="77" cy="34" r="6.5" strokeWidth="1.5" />
        <path d="M7 30 L15 24 L32 23 L46 13 L75 13 L88 23 L94 28 L94 32 L85 32" />
        <path d="M47 15 L72 15 L82 22 L47 22 Z" />
        {/* Small lightning mark */}
        <path d="M54 7 L51 12 L56 12 L53 17" stroke="#e10600" strokeWidth="1.5" fill="none" />
      </svg>
    )
  },
  {
    id: 'Citadine',
    name: 'Citadine',
    description: 'Agilité & Sobriété Urbaine',
    svg: (
      <svg viewBox="0 0 100 45" className="w-full h-full" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        {/* Compact Hatchback silhouette */}
        <path d="M7 34 L17 34 M32 34 L67 34 M82 34 L92 34" />
        <circle cx="24" cy="34" r="6.5" strokeWidth="1.5" />
        <circle cx="75" cy="34" r="6.5" strokeWidth="1.5" />
        <path d="M9 30 L18 24 L27 23 L37 14 L65 14 L75 22 L86 23 L89 31 L82 31" />
        <path d="M39 16 L63 16 L70 22 L39 22 Z" />
        <line x1="52" y1="16" x2="52" y2="22" />
      </svg>
    )
  }
];

export const BodyTypeSilhouettes: React.FC<{ activeType?: string; onSelect?: (type: string) => void }> = ({
  activeType,
  onSelect
}) => {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
      {BODY_TYPES.map((item) => {
        const isSelected = activeType === item.id;
        const Component: any = onSelect ? 'button' : Link;
        const props = onSelect
          ? {
              type: 'button',
              onClick: () => onSelect(item.id),
            }
          : {
              to: `/modeles?type=${encodeURIComponent(item.id)}`,
            };

        return (
          <Component
            key={item.id}
            {...props}
            className={`group relative text-left p-4 sm:p-5 rounded-2xl border transition-all duration-300 flex flex-col justify-between ${
              isSelected
                ? 'border-[#e10600] bg-[#e10600]/5 ring-1 ring-[#e10600]'
                : 'border-[var(--border)] bg-[var(--card)] hover:border-[#e10600] hover:shadow-md'
            }`}
          >
            <div className="h-12 w-full text-zinc-400 group-hover:text-[#e10600] group-hover:scale-105 transition-all duration-300 mb-3">
              {item.svg}
            </div>

            <div>
              <div className="flex items-center justify-between">
                <span className="font-heading font-medium text-sm sm:text-base group-hover:text-[#e10600] transition-colors">
                  {item.name}
                </span>
                <span className="text-xs text-zinc-400 opacity-0 group-hover:opacity-100 transition-opacity">
                  →
                </span>
              </div>
              <p className="text-[11px] text-[#6b6b72] mt-0.5 line-clamp-1">
                {item.description}
              </p>
            </div>
          </Component>
        );
      })}
    </div>
  );
};
