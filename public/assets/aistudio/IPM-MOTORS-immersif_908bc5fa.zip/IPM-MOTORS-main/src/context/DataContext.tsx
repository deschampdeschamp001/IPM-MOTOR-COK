import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { Vehicle, Brand, NewsArticle, NewsletterSubscriber, Lead } from '../types';
import { FALLBACK_VEHICLES } from '../data/mockVehicles';
import { getVehiclesFromDB, isSupabaseConfigured, getBrandsFromDB, getLeadsFromDB } from '../lib/supabase';
import { getLocalStoredBrands, loadAllBrands, subscribeToBrands } from '../lib/brandsStorage';
import { getLocalStoredNews, loadAllNews, subscribeToNews } from '../lib/newsStorage';
import { getAllSubscribers, getLocalSubscribers } from '../lib/newsletterStorage';

interface DataContextType {
  vehicles: Vehicle[];
  brands: Brand[];
  newsArticles: NewsArticle[];
  subscribers: NewsletterSubscriber[];
  leads: Lead[];
  isLoading: boolean;
  isUsingFallback: boolean;
  refreshVehicles: () => Promise<void>;
  refreshBrands: () => Promise<void>;
  refreshNews: () => Promise<void>;
  refreshSubscribers: () => Promise<void>;
  refreshLeads: () => Promise<void>;
  getVehicleById: (id: string) => Vehicle | undefined;
  getBrandBySlug: (slug: string) => Brand | undefined;
  getArticleBySlug: (slug: string) => NewsArticle | undefined;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [vehicles, setVehicles] = useState<Vehicle[]>(() => {
    const cached = localStorage.getItem('ipm_cached_vehicles');
    if (cached) {
      try {
        return JSON.parse(cached);
      } catch {
        // fallback
      }
    }
    return FALLBACK_VEHICLES;
  });

  const [brands, setBrands] = useState<Brand[]>(() => getLocalStoredBrands());
  const [newsArticles, setNewsArticles] = useState<NewsArticle[]>(() => getLocalStoredNews());
  const [subscribers, setSubscribers] = useState<NewsletterSubscriber[]>(() => getLocalSubscribers());
  const [leads, setLeads] = useState<Lead[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isUsingFallback, setIsUsingFallback] = useState<boolean>(!isSupabaseConfigured());

  const refreshVehicles = useCallback(async () => {
    try {
      if (isSupabaseConfigured()) {
        const { data, error } = await getVehiclesFromDB();
        if (!error && data && data.length > 0) {
          setVehicles(data);
          localStorage.setItem('ipm_cached_vehicles', JSON.stringify(data));
          setIsUsingFallback(false);
          return;
        }
      }
    } catch {
      // fallback
    }
    // Fallback: check local storage or use mock
    const saved = localStorage.getItem('ipm_cached_vehicles');
    if (saved) {
      try {
        setVehicles(JSON.parse(saved));
      } catch {
        setVehicles(FALLBACK_VEHICLES);
      }
    } else {
      setVehicles(FALLBACK_VEHICLES);
    }
    setIsUsingFallback(true);
  }, []);

  const refreshBrands = useCallback(async () => {
    const fresh = await loadAllBrands();
    if (fresh && fresh.length > 0) {
      setBrands(fresh);
    }
  }, []);

  const refreshNews = useCallback(async () => {
    const fresh = await loadAllNews();
    if (fresh && fresh.length > 0) {
      setNewsArticles(fresh);
    }
  }, []);

  const refreshSubscribers = useCallback(async () => {
    const fresh = await getAllSubscribers();
    setSubscribers(fresh);
  }, []);

  const refreshLeads = useCallback(async () => {
    if (isSupabaseConfigured()) {
      const { data } = await getLeadsFromDB();
      if (data) setLeads(data);
    } else {
      const saved = localStorage.getItem('ipm_leads');
      if (saved) {
        try {
          setLeads(JSON.parse(saved));
        } catch {
          // fallback
        }
      }
    }
  }, []);

  useEffect(() => {
    let mounted = true;
    const init = async () => {
      setIsLoading(true);
      await Promise.allSettled([
        refreshVehicles(),
        refreshBrands(),
        refreshNews(),
        refreshSubscribers(),
        refreshLeads()
      ]);
      if (mounted) setIsLoading(false);
    };
    init();

    const unsubBrands = subscribeToBrands((updated) => setBrands(updated));
    const unsubNews = subscribeToNews((updated) => setNewsArticles(updated));

    return () => {
      mounted = false;
      unsubBrands();
      unsubNews();
    };
  }, [refreshVehicles, refreshBrands, refreshNews, refreshSubscribers, refreshLeads]);

  const getVehicleById = useCallback((id: string) => {
    return vehicles.find(v => v.id === id);
  }, [vehicles]);

  const getBrandBySlug = useCallback((slug: string) => {
    const normalized = slug.toLowerCase().trim();
    return brands.find(b => (b.slug || b.name.toLowerCase().replace(/\s+/g, '-')) === normalized);
  }, [brands]);

  const getArticleBySlug = useCallback((slug: string) => {
    const normalized = slug.toLowerCase().trim();
    return newsArticles.find(a => (a.slug || a.id) === normalized);
  }, [newsArticles]);

  return (
    <DataContext.Provider
      value={{
        vehicles,
        brands,
        newsArticles,
        subscribers,
        leads,
        isLoading,
        isUsingFallback,
        refreshVehicles,
        refreshBrands,
        refreshNews,
        refreshSubscribers,
        refreshLeads,
        getVehicleById,
        getBrandBySlug,
        getArticleBySlug
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const ctx = useContext(DataContext);
  if (!ctx) {
    throw new Error('useData must be used within a DataProvider');
  }
  return ctx;
};
