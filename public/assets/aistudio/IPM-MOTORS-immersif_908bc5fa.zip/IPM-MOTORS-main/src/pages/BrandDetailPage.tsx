import React, { useEffect } from 'react';
import { useParams, Link } from '../router/Router';
import { useData } from '../context/DataContext';
import { VehicleCard } from '../components/VehicleCard';
import { ArrowLeft, ChevronRight, Globe, Sparkles } from 'lucide-react';

export const BrandDetailPage: React.FC = () => {
  const { slug } = useParams();
  const { brands, vehicles, getBrandBySlug } = useData();

  const brand = getBrandBySlug(slug || '');

  useEffect(() => {
    if (brand) {
      document.title = `Véhicules ${brand.name} 0 km | IPM Motors Abidjan`;
    }
  }, [brand]);

  if (!brand) {
    return (
      <div className="pt-36 pb-24 max-w-4xl mx-auto px-4 text-center">
        <h1 className="font-heading font-light text-3xl mb-4">Marque introuvable</h1>
        <p className="text-sm text-[#6b6b72] mb-8 font-light">
          Cette marque ne figure pas dans notre catalogue actuel.
        </p>
        <Link
          to="/marques"
          className="pill-btn px-6 py-3 bg-[#e10600] text-white text-xs font-semibold inline-flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Voir toutes les marques</span>
        </Link>
      </div>
    );
  }

  const brandVehicles = vehicles.filter(
    (v) => v.brand.toLowerCase() === brand.name.toLowerCase()
  );

  return (
    <div className="pt-24 sm:pt-32 pb-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-xs text-[#6b6b72] mb-6 font-mono">
        <Link to="/" className="hover:text-[var(--fg)]">Accueil</Link>
        <ChevronRight className="w-3.5 h-3.5" />
        <Link to="/marques" className="hover:text-[var(--fg)]">Marques</Link>
        <ChevronRight className="w-3.5 h-3.5" />
        <span className="text-[var(--fg)] font-semibold">{brand.name}</span>
      </nav>

      {/* Brand Hero Card */}
      <div className="p-8 sm:p-12 rounded-3xl border border-[var(--border)] bg-[var(--card)] mb-12 flex flex-col md:flex-row items-center justify-between gap-8 shadow-sm">
        <div className="space-y-4 max-w-2xl text-center md:text-left">
          <div className="flex items-center justify-center md:justify-start gap-3">
            <span className="eyebrow">Constructeur Officiel</span>
            {brand.country && (
              <span className="text-xs text-[#6b6b72] flex items-center gap-1 font-mono">
                <Globe className="w-3 h-3 text-[#e10600]" />
                <span>{brand.country}</span>
              </span>
            )}
          </div>

          <h1 className="font-heading font-light text-3xl sm:text-5xl tracking-tight">
            {brand.name} <span className="font-semibold text-[#e10600]">0 km</span>
          </h1>

          <p className="text-sm sm:text-base text-[#6b6b72] font-light leading-relaxed">
            {brand.description || `Découvrez tous les véhicules neufs 0 km de la marque ${brand.name} en exposition dans notre showroom de Cocody Riviera Bonoumin.`}
          </p>
        </div>

        {brand.logo_url && (
          <div className="w-36 h-24 p-4 rounded-2xl bg-white border border-neutral-200 flex items-center justify-center shadow-sm shrink-0">
            <img
              src={brand.logo_url}
              alt={`Logo ${brand.name}`}
              className="max-h-full max-w-full object-contain"
            />
          </div>
        )}
      </div>

      {/* Matching Vehicles Grid */}
      <div>
        <div className="flex items-center justify-between mb-8">
          <h2 className="font-heading font-medium text-xl sm:text-2xl">
            Modèles {brand.name} disponibles ({brandVehicles.length})
          </h2>
          <Link
            to={`/contact?vehicule=${encodeURIComponent(`Commande sur-mesure ${brand.name}`)}`}
            className="text-xs text-[#e10600] font-semibold hover:underline"
          >
            Commander un autre modèle {brand.name} →
          </Link>
        </div>

        {brandVehicles.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {brandVehicles.map((vehicle) => (
              <VehicleCard key={vehicle.id} vehicle={vehicle} />
            ))}
          </div>
        ) : (
          <div className="p-12 text-center rounded-3xl border border-dashed border-[var(--border)] bg-[var(--surface)]">
            <Sparkles className="w-8 h-8 text-[#e10600] mx-auto mb-3" />
            <h3 className="font-heading font-medium text-xl mb-2">
              Aucun modèle {brand.name} en stock immédiat
            </h3>
            <p className="text-sm text-[#6b6b72] max-w-md mx-auto mb-6 font-light">
              Notre équipe d'importation peut faire venir le véhicule {brand.name} de votre choix sous 15 à 30 jours avec formalités d'immatriculation complètes.
            </p>
            <Link
              to={`/contact?vehicule=${encodeURIComponent(`Commande sur-mesure ${brand.name}`)}`}
              className="pill-btn px-7 py-3 bg-[#e10600] text-white text-xs font-semibold inline-flex items-center gap-2"
            >
              <span>Demander une commande sur-mesure {brand.name}</span>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
};
