import React, { useEffect, useRef, useState } from 'react';
import {
  AnimatePresence,
  motion,
  MotionValue,
  useMotionTemplate,
  useMotionValueEvent,
  useReducedMotion,
  useScroll,
  useSpring,
  useTransform,
} from 'motion/react';
import { ArrowRight, ShieldCheck } from 'lucide-react';
import { Link } from '../router/Router';
import { HERO_INTRO, HERO_SCENES, HeroScene } from '../data/heroScenes';

/* ------------------------------------------------------------------ */
/*  Timeline (progression du scroll 0 → 1 sur toute la hauteur du hero) */
/* ------------------------------------------------------------------ */
const TOTAL = HERO_SCENES.length;
const EXPAND_END = 0.22; // le cadre arrondi devient plein écran
const ZOOM_END = 0.3; // fin du dézoom de la 1ère scène
const FIRST_HOLD = 0.36; // début de la 2ème scène
const SCENE_STEP = 0.16; // écart entre deux scènes
const REVEAL = 0.08; // durée du "wipe" entre deux scènes

const sceneStart = (i: number) => (i === 0 ? 0 : FIRST_HOLD + (i - 1) * SCENE_STEP);
const sceneAt = (p: number) => {
  let active = 0;
  for (let i = 1; i < TOTAL; i++) if (p >= sceneStart(i) + REVEAL * 0.5) active = i;
  return active;
};

const getIsMobile = () =>
  typeof window !== 'undefined' && window.matchMedia('(max-width: 767px)').matches;

/* ------------------------------------------------------------------ */
/*  Couche image d'une scène (dézoom + wipe vers le haut)               */
/* ------------------------------------------------------------------ */
const SceneLayer: React.FC<{
  scene: HeroScene;
  index: number;
  p: MotionValue<number>;
  isMobile: boolean;
}> = ({ scene, index, p, isMobile }) => {
  const start = sceneStart(index);
  const videoRef = useRef<HTMLVideoElement>(null);

  const clipPath = useTransform(
    p,
    index === 0 ? [0, 1] : [start, start + REVEAL],
    index === 0 ? ['inset(0% 0% 0% 0%)', 'inset(0% 0% 0% 0%)'] : ['inset(100% 0% 0% 0%)', 'inset(0% 0% 0% 0%)'],
  );
  const scale = useTransform(
    p,
    index === 0 ? [0, ZOOM_END, 1] : [start, start + REVEAL + 0.08, 1],
    index === 0 ? [2.2, 1, 1.06] : [1.28, 1.04, 1.1],
  );

  // Option vidéo : le scroll pilote le temps de lecture
  useMotionValueEvent(p, 'change', (v) => {
    const vid = videoRef.current;
    if (index !== 0 || !vid || !vid.duration) return;
    vid.currentTime = vid.duration * Math.min(1, Math.max(0, v / FIRST_HOLD));
  });

  return (
    <motion.div style={{ clipPath }} className="absolute inset-0 overflow-hidden">
      {index === 0 && scene.video ? (
        <video
          ref={videoRef}
          src={scene.video}
          poster={scene.image}
          muted
          playsInline
          preload="auto"
          className="absolute inset-0 w-full h-full object-cover"
        />
      ) : (
        <>
          {/* Mobile (écran portrait) : on montre la voiture en entier sur un fond flouté */}
          {isMobile && (
            <img
              src={scene.image}
              alt=""
              aria-hidden
              decoding="async"
              draggable={false}
              className="absolute inset-0 w-full h-full object-cover scale-125 blur-2xl opacity-60"
            />
          )}
          <motion.img
            src={scene.image}
            alt=""
            decoding="async"
            fetchPriority={index === 0 ? 'high' : 'auto'}
            draggable={false}
            className={`absolute inset-0 w-full h-full will-change-transform ${
              isMobile ? 'object-contain' : 'object-cover'
            }`}
            style={{
              scale,
              objectPosition: isMobile ? '50% 70%' : scene.imagePosition,
              transformOrigin: index === 0 ? scene.zoomOrigin || '50% 50%' : '50% 50%',
            }}
          />
        </>
      )}
    </motion.div>
  );
};

/* ------------------------------------------------------------------ */
/*  Gros mot qui monte depuis le bas (un par scène)                    */
/* ------------------------------------------------------------------ */
const GiantWord: React.FC<{ scene: HeroScene; index: number; p: MotionValue<number> }> = ({
  scene,
  index,
  p,
}) => {
  const isLast = index === TOTAL - 1;
  // Le mot sort juste avant le wipe de la scène suivante, puis le nouveau mot entre
  const inStart = index === 0 ? EXPAND_END - 0.02 : sceneStart(index) + 0.03;
  const inEnd = inStart + (index === 0 ? 0.06 : 0.05);
  const outStart = isLast ? 2 : sceneStart(index + 1) - 0.02;

  const y = useTransform(
    p,
    isLast ? [inStart, inEnd] : [inStart, inEnd, outStart, outStart + 0.05],
    isLast ? ['108%', '0%'] : ['108%', '0%', '0%', '-108%'],
  );

  return (
    <div
      aria-hidden
      className="absolute inset-x-0 bottom-0 flex justify-center overflow-hidden pointer-events-none"
      style={{ fontSize: `${scene.wordSize}vw`, lineHeight: 0.92 }}
    >
      <motion.span
        style={{ y }}
        className="block font-heading font-bold uppercase tracking-[-0.04em] whitespace-nowrap pb-[0.06em] text-transparent bg-clip-text bg-gradient-to-b from-white via-white/90 to-white/40"
      >
        {scene.word}
      </motion.span>
    </div>
  );
};

/* ------------------------------------------------------------------ */
/*  Version immersive (scroll scrubbing)                                */
/* ------------------------------------------------------------------ */
const ScrollHero: React.FC = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const [isMobile] = useState(getIsMobile);
  const [active, setActive] = useState(0);
  const [captionOn, setCaptionOn] = useState(false);
  const [clock, setClock] = useState('');

  const { scrollYProgress } = useScroll({ target: sectionRef, offset: ['start start', 'end end'] });
  const p = useSpring(scrollYProgress, { stiffness: 140, damping: 30, mass: 0.35 });

  useMotionValueEvent(p, 'change', (v) => {
    setActive(sceneAt(v));
    setCaptionOn(v > EXPAND_END);
  });

  // Horloge d'Abidjan (UTC+0)
  useEffect(() => {
    const tick = () => {
      const n = new Date();
      const f = (x: number) => String(x).padStart(2, '0');
      setClock(`${f(n.getUTCHours())}:${f(n.getUTCMinutes())}:${f(n.getUTCSeconds())}`);
    };
    tick();
    const id = window.setInterval(tick, 1000);
    return () => window.clearInterval(id);
  }, []);

  // Cadre : arrondi et inset → plein écran
  const top = useTransform(p, [0, EXPAND_END], [isMobile ? 47 : 43, 0]);
  const side = useTransform(p, [0, EXPAND_END], [isMobile ? 5 : 7, 0]);
  const bottom = useTransform(p, [0, EXPAND_END], [isMobile ? 9 : 10, 0]);
  const radius = useTransform(p, [0, EXPAND_END], [isMobile ? 22 : 32, 0]);
  const clipPath = useMotionTemplate`inset(${top}% ${side}% ${bottom}% ${side}% round ${radius}px)`;

  // Titre d'intro, halo, indices
  const introOpacity = useTransform(p, [0, 0.1], [1, 0]);
  const introY = useTransform(p, [0, 0.1], [0, -50]);
  const introPointer = useTransform(p, (v) => (v < 0.08 ? 'auto' : 'none'));
  const glowOpacity = useTransform(p, [0, EXPAND_END], [1, 0]);
  const cueOpacity = useTransform(p, [0, 0.05], [1, 0]);
  const railOpacity = useTransform(p, [EXPAND_END - 0.04, EXPAND_END + 0.04], [0, 1]);
  const barScale = p;

  const goToScene = (i: number) => {
    const el = sectionRef.current;
    if (!el) return;
    const target = i === 0 ? ZOOM_END : sceneStart(i) + REVEAL + 0.02;
    const distance = el.offsetHeight - window.innerHeight;
    const top0 = el.getBoundingClientRect().top + window.scrollY;
    window.scrollTo({ top: top0 + distance * target, behavior: 'smooth' });
  };

  const scene = HERO_SCENES[active];

  return (
    <section
      ref={sectionRef}
      id="hero"
      aria-label="Présentation IPM Motors"
      className="relative bg-[#09090b] text-white h-[500vh] md:h-[560vh]"
    >
      <div className="sticky top-0 h-svh overflow-hidden select-none">
        {/* Halo rouge sous le cadre */}
        <motion.div
          aria-hidden
          style={{ opacity: glowOpacity }}
          className="absolute left-1/2 -translate-x-1/2 bottom-[2%] w-[72%] h-[26%] rounded-full bg-[#e10600]/40 blur-[90px] pointer-events-none"
        />

        {/* Intro : titre + CTA au-dessus du cadre */}
        <motion.div
          style={{ opacity: introOpacity, y: introY, pointerEvents: introPointer }}
          className="absolute inset-x-0 top-0 z-20 px-4 pt-[4.75rem] sm:pt-24 text-center"
        >
          <div className="hidden [@media(min-height:780px)]:inline-flex items-center gap-2 px-3 py-1 mb-4 bg-white/10 backdrop-blur-md rounded-full border border-white/15 text-xs font-semibold text-white">
            <ShieldCheck className="w-3.5 h-3.5 text-[#e10600]" />
            <span>{HERO_INTRO.badge}</span>
          </div>
          <h1 className="font-heading text-white text-balance leading-[1.08] tracking-tight text-[clamp(1.65rem,3.1vw+1.6vh,3.9rem)]">
            <span className="font-extralight">{HERO_INTRO.titleLight}</span>{' '}
            <span className="font-semibold">{HERO_INTRO.titleStrong}</span>
          </h1>
          <div className="mt-4 sm:mt-5 flex items-center justify-center gap-3">
            <Link
              to="/modeles"
              className="pill-btn inline-flex items-center gap-2 px-5 sm:px-7 py-2.5 sm:py-3 bg-[#e10600] hover:bg-[#c30500] text-white text-xs sm:text-sm font-semibold shadow-lg shadow-[#e10600]/30"
            >
              <span>Explorer les véhicules</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              to="/contact"
              className="pill-btn hidden sm:inline-flex items-center gap-2 px-6 py-3 bg-white/10 hover:bg-white/20 backdrop-blur-md text-white text-sm font-medium border border-white/20"
            >
              Contacter un conseiller
            </Link>
          </div>
        </motion.div>

        {/* Horloge d'Abidjan */}
        <motion.div
          style={{ opacity: introOpacity }}
          className="hidden lg:flex absolute bottom-[2.2%] left-8 z-20 items-center gap-3 bg-black/60 backdrop-blur-md px-3.5 py-1.5 rounded-full border border-white/10 text-xs font-mono tracking-wider"
        >
          <span className="w-2 h-2 rounded-full bg-[#e10600] animate-pulse" />
          <span className="text-white/60">ABIDJAN GMT</span>
          <span className="text-white font-semibold tracking-widest">{clock || '00:00:00'}</span>
        </motion.div>

        {/* Cadre : les scènes */}
        <motion.div style={{ clipPath }} className="absolute inset-0 bg-zinc-950">
          {HERO_SCENES.map((s, i) => (
            <SceneLayer key={s.id} scene={s} index={i} p={p} isMobile={isMobile} />
          ))}

          {/* Voiles pour la lisibilité */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#09090b]/90 via-transparent to-[#09090b]/55 pointer-events-none" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#09090b]/70 via-transparent to-transparent pointer-events-none hidden md:block" />

          {HERO_SCENES.map((s, i) => (
            <GiantWord key={s.id} scene={s} index={i} p={p} />
          ))}
        </motion.div>

        {/* Légende de la scène active (haut gauche, sous la navbar) */}
        <div className="absolute z-20 left-4 sm:left-8 lg:left-14 top-24 sm:top-28 max-w-[min(26rem,calc(100%-2rem))]">
          <AnimatePresence mode="wait">
            {captionOn && (
              <motion.div
                key={scene.id}
                initial={{ opacity: 0, y: 24 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -16 }}
                transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
              >
                <div className="inline-flex items-center gap-2 px-3 py-1 mb-3 bg-black/40 backdrop-blur-md rounded-full border border-white/15 text-[11px] sm:text-xs font-semibold">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#e10600]" />
                  {scene.badge}
                </div>
                <h2 className="font-heading font-light text-2xl sm:text-4xl leading-[1.1] tracking-tight text-balance drop-shadow-md">
                  {scene.title}
                </h2>
                <p className="mt-3 text-sm sm:text-base text-zinc-200 font-light leading-relaxed drop-shadow">
                  {scene.subtitle}
                </p>
                <Link
                  to={scene.link}
                  className="pill-btn mt-5 inline-flex items-center gap-2 px-5 py-2.5 bg-white text-zinc-950 hover:bg-[#e10600] hover:text-white text-xs sm:text-sm font-semibold"
                >
                  <span>{scene.cta}</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Rail de navigation entre les scènes */}
        <motion.nav
          aria-label="Aller à une scène"
          style={{ opacity: railOpacity }}
          className="hidden md:flex absolute z-30 right-6 top-1/2 -translate-y-1/2 flex-col items-end gap-3"
        >
          {HERO_SCENES.map((s, i) => (
            <button
              key={s.id}
              onClick={() => goToScene(i)}
              aria-label={`Scène ${i + 1} : ${s.rail}`}
              aria-current={i === active}
              className="group flex items-center gap-3 cursor-pointer focus-visible:outline-2 focus-visible:outline-white rounded"
            >
              <span
                className={`text-[11px] font-medium transition-all duration-300 ${
                  i === active ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-2 group-hover:opacity-80 group-hover:translate-x-0'
                }`}
              >
                {s.rail}
              </span>
              <span
                className={`block rounded-full transition-all duration-300 ${
                  i === active ? 'w-2.5 h-2.5 bg-[#e10600]' : 'w-1.5 h-1.5 bg-white/60'
                }`}
              />
            </button>
          ))}
        </motion.nav>

        {/* Indice de scroll */}
        <motion.div
          aria-hidden
          style={{ opacity: cueOpacity }}
          className="absolute z-20 left-1/2 -translate-x-1/2 bottom-[2.2%] flex flex-col items-center gap-1.5 text-[11px] text-white/70"
        >
          <span>Faites défiler</span>
          <span className="block w-px h-6 bg-gradient-to-b from-white/70 to-transparent animate-pulse" />
        </motion.div>

        {/* Barre de progression */}
        <motion.div
          aria-hidden
          style={{ scaleX: barScale }}
          className="absolute z-30 left-0 right-0 bottom-0 h-0.5 bg-[#e10600] origin-left"
        />
      </div>
    </section>
  );
};

/* ------------------------------------------------------------------ */
/*  Version sobre pour "réduire les animations"                         */
/* ------------------------------------------------------------------ */
const StaticHero: React.FC = () => {
  const s = HERO_SCENES[0];
  return (
    <section
      aria-label="Présentation IPM Motors"
      className="relative min-h-svh flex items-end overflow-hidden bg-[#09090b] text-white pt-28 pb-16"
    >
      <img src={s.image} alt="" className="absolute inset-0 w-full h-full object-cover" style={{ objectPosition: s.imagePosition }} />
      <div className="absolute inset-0 bg-gradient-to-t from-[#09090b] via-[#09090b]/50 to-black/40" />
      <div className="relative z-10 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="font-heading text-4xl sm:text-6xl tracking-tight leading-[1.08] text-balance max-w-3xl">
          <span className="font-extralight">{HERO_INTRO.titleLight}</span>{' '}
          <span className="font-semibold">{HERO_INTRO.titleStrong}</span>
        </h1>
        <p className="mt-4 max-w-xl text-zinc-300 font-light">{s.subtitle}</p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Link to="/modeles" className="pill-btn inline-flex items-center gap-2 px-7 py-3 bg-[#e10600] text-white text-sm font-semibold">
            <span>Explorer les véhicules</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
          <Link to="/contact" className="pill-btn inline-flex items-center px-6 py-3 bg-white/10 border border-white/20 text-sm font-medium">
            Contacter un conseiller
          </Link>
        </div>
      </div>
    </section>
  );
};

export const Hero: React.FC = () => {
  const reduce = useReducedMotion();
  return reduce ? <StaticHero /> : <ScrollHero />;
};
