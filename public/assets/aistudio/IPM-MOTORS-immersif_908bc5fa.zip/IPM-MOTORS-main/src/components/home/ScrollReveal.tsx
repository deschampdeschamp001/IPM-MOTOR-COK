import React, { useEffect, useRef } from 'react';
import { animate, motion, MotionValue, useInView, useMotionValue, useReducedMotion, useScroll, useTransform } from 'motion/react';

const Word: React.FC<{ word: string; range: [number, number]; p: MotionValue<number> }> = ({ word, range, p }) => {
  const opacity = useTransform(p, range, [0.16, 1]);
  return (
    <motion.span style={{ opacity }} className="inline-block mr-[0.28em]">
      {word}
    </motion.span>
  );
};

/** Texte dont les mots s'allument un par un au fil du scroll */
export const ScrollReveal: React.FC<{ text: string; className?: string }> = ({ text, className }) => {
  const reduce = useReducedMotion();
  const ref = useRef<HTMLParagraphElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start 0.88', 'end 0.55'] });
  const words = text.split(' ');

  if (reduce) return <p className={className}>{text}</p>;

  return (
    <p ref={ref} className={className} aria-label={text}>
      {words.map((w, i) => {
        const start = i / words.length;
        const end = Math.min(1, start + 1.6 / words.length);
        return <Word key={`${w}-${i}`} word={w} range={[start, end]} p={scrollYProgress} />;
      })}
    </p>
  );
};

/** Compteur qui monte jusqu'à `to` quand il entre à l'écran */
export const CountUp: React.FC<{ to: number; suffix?: string; className?: string }> = ({ to, suffix = '', className }) => {
  const reduce = useReducedMotion();
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: '0px 0px -15% 0px' });
  const value = useMotionValue(reduce ? to : 0);

  useEffect(() => {
    if (!inView || reduce) return;
    const controls = animate(value, to, {
      duration: 1.6,
      ease: [0.16, 1, 0.3, 1],
      onUpdate: (v) => {
        if (ref.current) ref.current.textContent = `${Math.round(v)}${suffix}`;
      },
    });
    return () => controls.stop();
  }, [inView, reduce, to, suffix, value]);

  return (
    <span ref={ref} className={className} aria-label={`${to}${suffix}`}>
      {reduce ? `${to}${suffix}` : `0${suffix}`}
    </span>
  );
};
