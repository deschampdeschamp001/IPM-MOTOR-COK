import React, { useState } from 'react';
import { X, SlidersHorizontal, Send, Phone, CheckCircle2 } from 'lucide-react';
import { DEALERSHIP_CONFIG, buildWhatsAppUrl } from '../../config/dealership';
import { recordLeadInDB } from '../../lib/supabase';

interface CustomOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CustomOrderModal: React.FC<CustomOrderModalProps> = ({ isOpen, onClose }) => {
  const [brand, setBrand] = useState('Toyota');
  const [model, setModel] = useState('');
  const [bodyType, setBodyType] = useState('SUV');
  const [fuel, setFuel] = useState('Essence');
  const [transmission, setTransmission] = useState('Automatique');
  const [budget, setBudget] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone) return;

    const message = `Demande de configuration sur-mesure : ${brand} ${model || ''} (${bodyType}, ${fuel}, ${transmission}). Budget : ${budget || 'Non spécifié'}. Notes : ${notes || 'Aucune'}`;

    try {
      await recordLeadInDB({
        name: name.trim(),
        phone: phone.trim(),
        vehicle_brand: brand,
        vehicle_model: model,
        message,
      });
    } catch {
      // safe fallback
    }

    const waMsg = `Bonjour IPM Motors,
Je souhaite configurer et commander un véhicule neuf 0 km sur-mesure :
• *Marque :* ${brand}
• *Modèle :* ${model || 'À conseiller'}
• *Carrosserie :* ${bodyType}
• *Motorisation :* ${fuel} (${transmission})
• *Budget envisagé :* ${budget || 'À définir'}
• *Mes coordonnées :* ${name} (${phone})
${notes ? `• *Options spécifiques :* ${notes}` : ''}

Merci de me recontacter avec les disponibilités et votre meilleure offre.`;

    const waUrl = buildWhatsAppUrl(waMsg);
    setIsSubmitted(true);
    window.open(waUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#141414] border border-[#2A2A2A] rounded-2xl max-w-xl w-full max-h-[92vh] overflow-y-auto p-6 sm:p-8 space-y-6 text-white shadow-2xl relative">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-[#2A2A2A] pb-4">
          <div>
            <div className="inline-flex items-center gap-1.5 text-[11px] uppercase tracking-widest font-bold text-[#E10600] mb-1">
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>Commande sur-mesure & Importation 0 km</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight">
              Configurez le véhicule de vos rêves
            </h2>
            <p className="text-xs text-[#8A8A8A] mt-1">
              IPM Motors trouve, importe et immatricule la configuration exacte de votre choix avec garantie constructeur.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-[#8A8A8A] hover:text-white rounded-lg hover:bg-[#222222] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSubmitted ? (
          <div className="py-12 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold">Demande transmise avec succès</h3>
            <p className="text-sm text-[#8A8A8A] max-w-md mx-auto">
              Votre conseiller privé IPM Motors a reçu votre cahier des charges et prépare une proposition personnalisée.
            </p>
            <button
              onClick={() => {
                setIsSubmitted(false);
                onClose();
              }}
              className="px-6 py-2.5 bg-[#E10600] hover:bg-[#B00500] text-white text-xs font-bold uppercase tracking-wider rounded-lg transition-colors cursor-pointer"
            >
              Fermer
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                  Marque souhaitée *
                </label>
                <select
                  value={brand}
                  onChange={(e) => setBrand(e.target.value)}
                  className="w-full px-3 py-2.5 bg-[#0A0A0A] border border-[#2A2A2A] rounded-lg text-sm text-white focus:outline-none focus:border-[#E10600]"
                >
                  <option value="Toyota">Toyota</option>
                  <option value="Mercedes-Benz">Mercedes-Benz</option>
                  <option value="BYD">BYD</option>
                  <option value="BMW">BMW</option>
                  <option value="Land Rover">Land Rover</option>
                  <option value="Jetour">Jetour</option>
                  <option value="Kia">Kia</option>
                  <option value="Nissan">Nissan</option>
                  <option value="Mitsubishi">Mitsubishi</option>
                  <option value="Changan">Changan</option>
                  <option value="Geely">Geely</option>
                  <option value="Autre">Autre constructeur d'exception</option>
                </select>
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                  Modèle envisagé
                </label>
                <input
                  type="text"
                  value={model}
                  onChange={(e) => setModel(e.target.value)}
                  placeholder="Ex: Land Cruiser, Defender, Classe G, Seal..."
                  className="w-full px-3 py-2.5 bg-[#0A0A0A] border border-[#2A2A2A] rounded-lg text-sm text-white focus:outline-none focus:border-[#E10600]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                  Silhouette
                </label>
                <select
                  value={bodyType}
                  onChange={(e) => setBodyType(e.target.value)}
                  className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded-lg text-xs text-white focus:outline-none focus:border-[#E10600]"
                >
                  <option value="SUV">SUV Prestige</option>
                  <option value="Berline">Berline de Luxe</option>
                  <option value="Pick-up">Pick-up Puissant</option>
                  <option value="Électrique">100% Électrique</option>
                </select>
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                  Énergie
                </label>
                <select
                  value={fuel}
                  onChange={(e) => setFuel(e.target.value)}
                  className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded-lg text-xs text-white focus:outline-none focus:border-[#E10600]"
                >
                  <option value="Essence">Essence</option>
                  <option value="Diesel">Diesel</option>
                  <option value="Électrique">Électrique</option>
                  <option value="Hybride">Hybride Rechargeable</option>
                </select>
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                  Boîte
                </label>
                <select
                  value={transmission}
                  onChange={(e) => setTransmission(e.target.value)}
                  className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded-lg text-xs text-white focus:outline-none focus:border-[#E10600]"
                >
                  <option value="Automatique">Automatique</option>
                  <option value="Manuelle">Manuelle</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                Budget approximatif (FCFA, optionnel)
              </label>
              <input
                type="text"
                value={budget}
                onChange={(e) => setBudget(e.target.value)}
                placeholder="Ex: 35 000 000 FCFA à 70 000 000 FCFA"
                className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded-lg text-sm text-white focus:outline-none focus:border-[#E10600]"
              />
            </div>

            <div>
              <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                Options & Finitions souhaitées
              </label>
              <textarea
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Couleur extérieure, sellerie cuir, toit panoramique, système audio..."
                className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded-lg text-xs text-white focus:outline-none focus:border-[#E10600]"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-[#2A2A2A]">
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                  Votre Nom complet *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ex: M. Jean Kouassi"
                  className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded-lg text-sm text-white focus:outline-none focus:border-[#E10600]"
                />
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                  Numéro de téléphone / WhatsApp *
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="Ex: 07 08 09 10 11"
                  className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded-lg text-sm text-white focus:outline-none focus:border-[#E10600]"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 bg-[#222222] hover:bg-[#333333] text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
              >
                Annuler
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 bg-[#E10600] hover:bg-[#B00500] text-white text-xs font-bold uppercase tracking-wider rounded-lg transition-colors flex items-center gap-2 cursor-pointer shadow-lg shadow-[#E10600]/25"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Transmettre mon cahier des charges</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
