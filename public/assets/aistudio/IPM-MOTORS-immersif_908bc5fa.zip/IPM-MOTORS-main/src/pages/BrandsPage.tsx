import React, { useEffect } from 'react';
import { useData } from '../context/DataContext';
import { Link } from '../router/Router';
import { ArrowRight, Globe } from 'lucide-react';

export const BrandsPage: React.FC = () => {
  const { brands, vehicles } = useData();

  useEffect(() => {
    document.title = 'Nos Marques Partenaires | IPM Motors Abidjan';
  }, []);

  const activeBrands = brands.filter(b => b.is_active);

  return (
    <div className="pt-24 sm:pt-32 pb-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-16">
        <span className="eyebrow block mb-2">Toutes marques, un seul showroom</span>
        <h1 className="font-heading font-light text-3xl sm:text-5xl tracking-tight">
          Nos Constructeurs & <span className="font-semibold">Marques</span>
        </h1>
        <p className="text-sm sm:text-base text-[#6b6b72] mt-3 font-light">
          IPM Motors distribue les modèles neufs 0 km des plus grands groupes automobiles mondiaux. Sélectionnez une marque pour voir les véhicules disponibles.
        </p>
      </div>

      {/* Grid of Brand Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {activeBrands.map((brand) => {
          const brandSlug = brand.slug || brand.name.toLowerCase().replace(/\s+/g, '-');
          const count = vehicles.filter(v => v.brand.toLowerCase() === brand.name.toLowerCase()).length;

          return (
            <Link
              key={brand.id}
              to={`/marques/${brandSlug}`}
              className="group p-7 rounded-3xl border border-[var(--border)] bg-[var(--card)] hover:border-[#e10600] transition-all duration-300 flex flex-col justify-between hover:shadow-lg"
            >
              <div>
                {/* Logo and Country Lockup */}
                <div className="flex items-center justify-between mb-6 pb-4 border-b border-[var(--border)]">
                  <div className="h-12 w-28 flex items-center justify-start filter grayscale group-hover:grayscale-0 transition-all duration-300">
                    {brand.logo_url ? (
                      <img
                        src={brand.logo_url}
                        alt={`Logo ${brand.name}`}
                        className="max-h-12 max-w-[110px] object-contain"
                      />
                    ) : (
                      <span className="font-heading font-bold text-lg">{brand.name}</span>
                    )}
                  </div>

                  {brand.country && (
                    <span className="text-[11px] font-medium text-[#6b6b72] flex items-center gap-1">
                      <Globe className="w-3 h-3" />
                      <span>{brand.country}</span>
                    </span>
                  )}
                </div>

                <h3 className="font-heading font-semibold text-xl group-hover:text-[#e10600] transition-colors">
                  {brand.name}
                </h3>
                <p className="text-xs text-[#6b6b72] mt-2 font-light line-clamp-2 leading-relaxed">
                  {brand.description || `Découvrez tous les véhicules 0 km de la marque ${brand.name} disponibles dans notre showroom à Abidjan.`}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-[var(--border)] flex items-center justify-between text-xs">
                <span className="text-[#6b6b72] font-mono">
                  {count} modèle{count > 1 ? 's' : ''} en stock
                </span>
                <span className="text-[#e10600] font-semibold flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                  <span>Explorer</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
};
