/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { RouterProvider, useRouter, matchPath } from './router/Router';
import { ThemeProvider } from './context/ThemeContext';
import { DataProvider } from './context/DataContext';

import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { ScrollToTop } from './components/ScrollToTop';

import { HomePage } from './pages/HomePage';
import { ModelsPage } from './pages/ModelsPage';
import { VehicleDetailPage } from './pages/VehicleDetailPage';
import { BrandsPage } from './pages/BrandsPage';
import { BrandDetailPage } from './pages/BrandDetailPage';
import { OffersPage } from './pages/OffersPage';
import { AfterSalesPage } from './pages/AfterSalesPage';
import { AboutPage } from './pages/AboutPage';
import { NewsPage } from './pages/NewsPage';
import { NewsArticlePage } from './pages/NewsArticlePage';
import { ContactPage } from './pages/ContactPage';
import { AdminPage } from './pages/AdminPage';

function AppRouter() {
  const { pathname } = useRouter();

  // Admin route has its own full-screen layout
  if (pathname === '/admin') {
    return <AdminPage />;
  }

  // Route matching
  let PageComponent = HomePage;

  if (pathname === '/') {
    PageComponent = HomePage;
  } else if (pathname === '/modeles') {
    PageComponent = ModelsPage;
  } else if (matchPath('/vehicule/:id', pathname).matches) {
    PageComponent = VehicleDetailPage;
  } else if (pathname === '/marques') {
    PageComponent = BrandsPage;
  } else if (matchPath('/marques/:slug', pathname).matches) {
    PageComponent = BrandDetailPage;
  } else if (pathname === '/offres') {
    PageComponent = OffersPage;
  } else if (pathname === '/apres-vente') {
    PageComponent = AfterSalesPage;
  } else if (pathname === '/a-propos') {
    PageComponent = AboutPage;
  } else if (pathname === '/actualites') {
    PageComponent = NewsPage;
  } else if (matchPath('/actualites/:slug', pathname).matches) {
    PageComponent = NewsArticlePage;
  } else if (pathname === '/contact') {
    PageComponent = ContactPage;
  } else {
    // Fallback to home
    PageComponent = HomePage;
  }

  return (
    <div className="flex flex-col min-h-screen bg-[var(--bg)] text-[var(--fg)] transition-colors duration-200">
      <Navbar />
      <main className="flex-1">
        <PageComponent />
      </main>
      <Footer />
      <ScrollToTop />
      <FloatingWhatsApp />
    </div>
  );
}

export function App() {
  return (
    <ThemeProvider>
      <RouterProvider>
        <DataProvider>
          <AppRouter />
        </DataProvider>
      </RouterProvider>
    </ThemeProvider>
  );
}

export default App;
