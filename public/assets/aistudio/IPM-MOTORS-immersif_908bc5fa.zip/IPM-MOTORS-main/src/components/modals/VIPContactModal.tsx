import React, { useState } from 'react';
import { X, MessageSquare, Phone, Send, User, CheckCircle2 } from 'lucide-react';
import { DEALERSHIP_CONFIG, buildWhatsAppUrl } from '../../config/dealership';
import { recordLeadInDB } from '../../lib/supabase';

interface VIPContactModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const VIPContactModal: React.FC<VIPContactModalProps> = ({ isOpen, onClose }) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [requestType, setRequestType] = useState('Devis véhicule neuf');
  const [message, setMessage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone) return;

    try {
      await recordLeadInDB({
        name: name.trim(),
        phone: phone.trim(),
        message: `[${requestType}] ${message || 'Demande de contact prioritaire'}`,
      });
    } catch {
      // safe fallback
    }

    const waMsg = `Bonjour IPM Motors,
Je m'appelle *${name}* (${phone}).
Type de demande : *${requestType}*.
${message ? `Détails : ${message}` : 'Je souhaite être contacté par un conseiller commercial pour un projet d’achat 0 km.'}`;

    const waUrl = buildWhatsAppUrl(waMsg);
    setIsSubmitted(true);
    window.open(waUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#141414] border border-[#2A2A2A] rounded-2xl max-w-lg w-full max-h-[92vh] overflow-y-auto p-6 sm:p-8 space-y-6 text-white shadow-2xl relative">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-[#2A2A2A] pb-4">
          <div>
            <div className="inline-flex items-center gap-1.5 text-[11px] uppercase tracking-widest font-bold text-[#E10600] mb-1">
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Conseil Commercial & Devis Express</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight">
              Échangez avec un conseiller privé
            </h2>
            <p className="text-xs text-[#8A8A8A] mt-1">
              Réponse rapide garantie en moins de 15 minutes par WhatsApp ou téléphone.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-[#8A8A8A] hover:text-white rounded-lg hover:bg-[#222222] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Fast Action Row */}
        <div className="grid grid-cols-2 gap-3">
          <a
            href={buildWhatsAppUrl('Bonjour IPM Motors, je souhaite échanger directement avec un conseiller commercial.')}
            target="_blank"
            rel="noopener noreferrer"
            className="p-3.5 bg-emerald-950/40 border border-emerald-800/60 hover:bg-emerald-900/50 rounded-xl flex items-center gap-2.5 transition-colors group cursor-pointer"
          >
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
              <MessageSquare className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-bold text-white group-hover:text-emerald-400">WhatsApp Direct</div>
              <div className="text-[10px] text-neutral-400">Réponse immédiate</div>
            </div>
          </a>

          <a
            href={`tel:${DEALERSHIP_CONFIG.phone}`}
            className="p-3.5 bg-[#1F1F1F] border border-[#333333] hover:bg-[#282828] rounded-xl flex items-center gap-2.5 transition-colors group cursor-pointer"
          >
            <div className="w-8 h-8 rounded-lg bg-[#E10600]/20 text-[#E10600] flex items-center justify-center shrink-0">
              <Phone className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-bold text-white group-hover:text-[#E10600]">Appel Téléphonique</div>
              <div className="text-[10px] text-neutral-400">{DEALERSHIP_CONFIG.phoneDisplay}</div>
            </div>
          </a>
        </div>

        {isSubmitted ? (
          <div className="py-8 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold">Demande envoyée</h3>
            <p className="text-xs text-[#8A8A8A]">Votre conseiller vous recontacte dans les plus brefs délais.</p>
            <button
              onClick={() => {
                setIsSubmitted(false);
                onClose();
              }}
              className="px-5 py-2 bg-[#E10600] text-white text-xs font-bold uppercase rounded-lg"
            >
              Fermer
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 pt-2 border-t border-[#2A2A2A]">
            <div>
              <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                Objet de votre demande
              </label>
              <select
                value={requestType}
                onChange={(e) => setRequestType(e.target.value)}
                className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded-lg text-xs text-white focus:outline-none focus:border-[#E10600]"
              >
                <option value="Devis véhicule neuf">Devis tarifaire véhicule neuf 0 km</option>
                <option value="Disponibilité immédiate en stock">Vérifier une disponibilité immédiate</option>
                <option value="Conseil financement & leasing">Conseil financement & leasing professionnel</option>
                <option value="Commande entreprise ou flotte">Commande entreprise / flotte société</option>
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                  Nom & Prénoms *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ex: M. Bamba"
                  className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded-lg text-xs text-white focus:outline-none focus:border-[#E10600]"
                />
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                  Téléphone / WhatsApp *
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="Ex: 05 04 03 02 01"
                  className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded-lg text-xs text-white focus:outline-none focus:border-[#E10600]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                Message ou question
              </label>
              <textarea
                rows={2}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Précisez votre véhicule recherché ou vos questions..."
                className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded-lg text-xs text-white focus:outline-none focus:border-[#E10600]"
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 bg-[#222222] hover:bg-[#333333] text-white text-xs font-semibold rounded-lg"
              >
                Annuler
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-[#E10600] hover:bg-[#B00500] text-white text-xs font-bold uppercase tracking-wider rounded-lg flex items-center gap-2 transition-colors cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Envoyer ma demande</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
