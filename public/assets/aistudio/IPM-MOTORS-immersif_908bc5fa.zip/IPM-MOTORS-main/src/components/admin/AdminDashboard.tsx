import React, { useState, useEffect } from 'react';
import {
  Car,
  Users,
  Plus,
  Eye,
  EyeOff,
  Trash2,
  Edit,
  LogOut,
  Upload,
  AlertCircle,
  CheckCircle,
  Phone,
  MessageSquare,
  ArrowLeft,
  X,
  Star,
  Tags,
  Image as ImageIcon,
  Newspaper,
  Calendar,
  Mail,
  Download,
} from 'lucide-react';
import { Vehicle, Lead, Brand, VehicleType, NewsArticle, NewsletterSubscriber } from '../../types';
import { getAllSubscribers } from '../../lib/newsletterStorage';
import {
  supabase,
  isSupabaseConfigured,
  getAllVehiclesForAdmin,
  saveVehicleToDB,
  deleteVehicleFromDB,
  toggleVehicleVisibility,
  getLeadsFromDB,
  uploadVehicleImage,
  getAllBrandsForAdmin,
  saveBrandToDB,
  deleteBrandFromDB,
  uploadBrandLogo
} from '../../lib/supabase';
import { DEALERSHIP_CONFIG, buildWhatsAppUrl } from '../../config/dealership';
import { FALLBACK_VEHICLES } from '../../data/mockVehicles';
import { DEFAULT_BRANDS, DEFAULT_BRAND_LOGOS } from '../../data/defaultBrands';
import {
  loadAllBrands,
  saveBrandRecord,
  deleteBrandRecord,
  subscribeToBrands,
  resetBrandToDefault,
  getLocalStoredBrands,
} from '../../lib/brandsStorage';
import {
  loadAllNews,
  saveNewsRecord,
  deleteNewsRecord,
  subscribeToNews,
  getLocalStoredNews,
} from '../../lib/newsStorage';

interface AdminDashboardProps {
  onBackToSite: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onBackToSite }) => {
  const [activeTab, setActiveTab] = useState<'vehicles' | 'brands' | 'news' | 'leads' | 'newsletter'>('vehicles');
  const [subscribers, setSubscribers] = useState<NewsletterSubscriber[]>([]);
  const [isLoadingSubscribers, setIsLoadingSubscribers] = useState(false);
  const [session, setSession] = useState<any>(null);
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [isAuthLoading, setIsAuthLoading] = useState(false);

  // Vehicles state
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [isLoadingVehicles, setIsLoadingVehicles] = useState(true);

  // Brands state
  const [brands, setBrands] = useState<Brand[]>(() => getLocalStoredBrands());
  const [isLoadingBrands, setIsLoadingBrands] = useState(false);

  // News state
  const [newsList, setNewsList] = useState<NewsArticle[]>(() => getLocalStoredNews());
  const [isLoadingNews, setIsLoadingNews] = useState(false);
  const [editingArticle, setEditingArticle] = useState<Partial<NewsArticle> | null>(null);
  const [isSavingArticle, setIsSavingArticle] = useState(false);
  const [uploadingArticleImage, setUploadingArticleImage] = useState(false);
  const [deleteConfirmArticleId, setDeleteConfirmArticleId] = useState<string | null>(null);

  // Leads state
  const [leads, setLeads] = useState<Lead[]>([]);
  const [isLoadingLeads, setIsLoadingLeads] = useState(false);

  // Vehicle Modal (Add / Edit)
  const [editingVehicle, setEditingVehicle] = useState<Partial<Vehicle> | null>(null);
  const [isSavingVehicle, setIsSavingVehicle] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [deleteConfirmVehicleId, setDeleteConfirmVehicleId] = useState<string | null>(null);

  // Brand Modal (Add / Edit)
  const [editingBrand, setEditingBrand] = useState<Partial<Brand> | null>(null);
  const [isSavingBrand, setIsSavingBrand] = useState(false);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [deleteConfirmBrandId, setDeleteConfirmBrandId] = useState<string | null>(null);

  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Check Supabase session on mount
  useEffect(() => {
    if (isSupabaseConfigured() && supabase) {
      supabase.auth.getSession().then(({ data: { session } }) => {
        setSession(session);
      });

      const {
        data: { subscription },
      } = supabase.auth.onAuthStateChange((_event, session) => {
        setSession(session);
      });

      return () => subscription.unsubscribe();
    }
  }, []);

  // Listen for brand changes from any source
  useEffect(() => {
    const unsubscribe = subscribeToBrands((updatedBrands) => {
      setBrands(updatedBrands);
    });
    return unsubscribe;
  }, []);

  // Listen for news updates
  useEffect(() => {
    const unsubscribeNews = subscribeToNews((updatedNews) => {
      setNewsList(updatedNews);
    });
    return unsubscribeNews;
  }, []);

  // Fetch data when authenticated
  useEffect(() => {
    loadVehicles();
    loadBrands();
    loadNews();
  }, [session]);

  const showNotification = (message: string, type: 'success' | 'error' = 'success') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 4000);
  };

  const loadVehicles = async () => {
    setIsLoadingVehicles(true);
    if (!isSupabaseConfigured()) {
      setVehicles(FALLBACK_VEHICLES);
      setIsLoadingVehicles(false);
      return;
    }

    const { data, error } = await getAllVehiclesForAdmin();
    if (error || !data || data.length === 0) {
      setVehicles(FALLBACK_VEHICLES);
    } else {
      setVehicles(data);
    }
    setIsLoadingVehicles(false);
  };

  const loadBrands = async () => {
    setIsLoadingBrands(true);
    const loaded = await loadAllBrands();
    setBrands(loaded);
    setIsLoadingBrands(false);
  };

  const loadNews = async () => {
    setIsLoadingNews(true);
    const loaded = await loadAllNews();
    setNewsList(loaded);
    setIsLoadingNews(false);
  };

  const loadLeads = async () => {
    setIsLoadingLeads(true);
    if (!isSupabaseConfigured()) {
      setLeads([
        {
          id: 'lead-1',
          name: 'M. Touré Ibrahim',
          phone: '0708091011',
          message: 'Bonjour, je souhaite un devis pro pour un Toyota Land Cruiser LC300 pour livraison à Cocody.',
          created_at: new Date().toISOString(),
          vehicle_brand: 'Toyota',
          vehicle_model: 'Land Cruiser LC300 VXR'
        },
        {
          id: 'lead-2',
          name: 'Cabinet Kouamé & Associés',
          phone: '0501020304',
          message: 'Demande de fiche technique et disponibilité sur la Mercedes Classe S.',
          created_at: new Date(Date.now() - 86400000).toISOString(),
          vehicle_brand: 'Mercedes-Benz',
          vehicle_model: 'Classe S 500'
        }
      ]);
      setIsLoadingLeads(false);
      return;
    }

    const { data, error } = await getLeadsFromDB();
    if (error) {
      showNotification('Impossible de charger les demandes : ' + error.message, 'error');
    } else {
      setLeads(data || []);
    }
    setIsLoadingLeads(false);
  };

  const loadSubscribers = async () => {
    setIsLoadingSubscribers(true);
    const data = await getAllSubscribers();
    setSubscribers(data);
    setIsLoadingSubscribers(false);
  };

  const exportSubscribersCSV = () => {
    if (subscribers.length === 0) {
      showNotification('Aucun abonné à exporter.', 'error');
      return;
    }
    const headers = 'ID,Email,Source,Date_Inscription\n';
    const rows = subscribers
      .map((s) => `"${s.id}","${s.email}","${s.source || 'Site web'}","${s.created_at}"`)
      .join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `newsletter-abonnes-ipm-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showNotification('Export CSV téléchargé avec succès !', 'success');
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setIsAuthLoading(true);

    if (!isSupabaseConfigured() || !supabase) {
      if (authEmail === 'admin@ipmotors.ci' && authPassword === 'admin') {
        setSession({ user: { email: authEmail } });
        setIsAuthLoading(false);
        return;
      }
      setAuthError('Supabase non configuré. Pour tester en mode démo, utilisez : admin@ipmotors.ci / admin');
      setIsAuthLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: authEmail.trim(),
        password: authPassword,
      });

      if (error) {
        setAuthError(error.message);
      } else {
        setSession(data.session);
      }
    } catch (err: any) {
      setAuthError(err.message || 'Erreur lors de la connexion');
    } finally {
      setIsAuthLoading(false);
    }
  };

  const handleLogout = async () => {
    if (supabase && isSupabaseConfigured()) {
      await supabase.auth.signOut();
    }
    setSession(null);
  };

  // Vehicles operations
  const handleToggleVisibility = async (vehicle: Vehicle) => {
    const newStatus = !vehicle.is_available;
    setVehicles((prev) =>
      prev.map((v) => (v.id === vehicle.id ? { ...v, is_available: newStatus } : v))
    );

    if (isSupabaseConfigured()) {
      const { success, error } = await toggleVehicleVisibility(vehicle.id, newStatus);
      if (!success) {
        showNotification('Erreur de mise à jour : ' + (error?.message || ''), 'error');
        loadVehicles();
      } else {
        showNotification(newStatus ? 'Véhicule rendu visible' : 'Véhicule masqué du catalogue');
      }
    } else {
      showNotification('Statut mis à jour (Mode local)');
    }
  };

  const handleDeleteVehicle = async (id: string) => {
    setVehicles((prev) => prev.filter((v) => v.id !== id));
    setDeleteConfirmVehicleId(null);

    if (isSupabaseConfigured()) {
      const { success, error } = await deleteVehicleFromDB(id);
      if (!success) {
        showNotification('Erreur de suppression : ' + (error?.message || ''), 'error');
        loadVehicles();
      } else {
        showNotification('Véhicule supprimé définitivement');
      }
    } else {
      showNotification('Véhicule supprimé (Mode local)');
    }
  };

  const handleSaveVehicle = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingVehicle?.brand || !editingVehicle?.model) {
      showNotification('Veuillez renseigner la marque et le modèle', 'error');
      return;
    }

    setIsSavingVehicle(true);
    const vehiclePayload: Partial<Vehicle> = {
      ...editingVehicle,
      year: Number(editingVehicle.year) || new Date().getFullYear(),
      type: (editingVehicle.type as VehicleType) || 'SUV',
      fuel: editingVehicle.fuel || 'Essence',
      transmission: editingVehicle.transmission || 'Automatique',
      seats: Number(editingVehicle.seats) || 5,
      is_available: editingVehicle.is_available ?? true,
      is_featured: editingVehicle.is_featured ?? false,
      images: editingVehicle.images && editingVehicle.images.length > 0
        ? editingVehicle.images
        : ['/src/assets/images/hero_dealership_car_1793116464643.jpg'],
      price_label: editingVehicle.price_label || 'Sur demande',
    };

    if (isSupabaseConfigured()) {
      const { error } = await saveVehicleToDB(vehiclePayload);
      if (error) {
        showNotification('Erreur lors de la sauvegarde : ' + error.message, 'error');
      } else {
        showNotification('Véhicule enregistré avec succès !');
        setEditingVehicle(null);
        loadVehicles();
      }
    } else {
      if (vehiclePayload.id) {
        setVehicles((prev) =>
          prev.map((v) => (v.id === vehiclePayload.id ? ({ ...v, ...vehiclePayload } as Vehicle) : v))
        );
      } else {
        const newV = {
          ...vehiclePayload,
          id: 'custom-' + Date.now(),
          created_at: new Date().toISOString(),
        } as Vehicle;
        setVehicles((prev) => [newV, ...prev]);
      }
      showNotification('Véhicule enregistré (Mode local)');
      setEditingVehicle(null);
    }
    setIsSavingVehicle(false);
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setUploadingImage(true);
    const uploadedUrls: string[] = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (isSupabaseConfigured()) {
        const { url, error } = await uploadVehicleImage(file);
        if (url) {
          uploadedUrls.push(url);
        } else if (error) {
          showNotification('Erreur de téléversement : ' + error.message, 'error');
        }
      } else {
        const localUrl = URL.createObjectURL(file);
        uploadedUrls.push(localUrl);
      }
    }

    if (uploadedUrls.length > 0) {
      setEditingVehicle((prev) => ({
        ...prev,
        images: [...(prev?.images || []), ...uploadedUrls],
      }));
      showNotification(`${uploadedUrls.length} image(s) ajoutée(s)`);
    }
    setUploadingImage(false);
  };

  // Brands operations
  const handleSaveBrand = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBrand?.name?.trim()) {
      showNotification('Veuillez renseigner le nom de la marque', 'error');
      return;
    }

    setIsSavingBrand(true);
    const brandPayload: Partial<Brand> = {
      ...editingBrand,
      name: editingBrand.name.trim(),
      logo_url: editingBrand.logo_url?.trim() || '',
      sort_order: Number(editingBrand.sort_order) || brands.length + 1,
      is_active: editingBrand.is_active ?? true,
    };

    const result = await saveBrandRecord(brandPayload);
    if (result.success) {
      showNotification(`Marque "${result.brand.name}" enregistrée avec succès !`);
      setEditingBrand(null);
      loadBrands();
    } else {
      showNotification(`Erreur sauvegarde marque : ${result.error || 'Erreur'}`, 'error');
    }
    setIsSavingBrand(false);
  };

  const handleDeleteBrand = async (id: string) => {
    await deleteBrandRecord(id);
    setDeleteConfirmBrandId(null);
    showNotification('Marque supprimée');
    loadBrands();
  };

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingLogo(true);

    // 1. Immediately read as Base64 Data URL for instant rendering, localStorage persistence & zero broken links
    const reader = new FileReader();
    reader.onload = async () => {
      const base64Url = reader.result as string;
      setEditingBrand((prev) => ({ ...prev, logo_url: base64Url }));

      // 2. If Supabase is configured, also attempt to upload to storage bucket
      if (isSupabaseConfigured()) {
        try {
          const { url, error } = await uploadBrandLogo(file);
          if (url) {
            setEditingBrand((prev) => ({ ...prev, logo_url: url }));
            showNotification('Logo téléversé vers le bucket brand-logos !');
          } else if (error) {
            showNotification('Logo conservé en haute qualité locale (Supabase : ' + error.message + ')', 'success');
          }
        } catch {
          // Base64 is kept
        } finally {
          setUploadingLogo(false);
        }
      } else {
        showNotification('Nouveau logo chargé avec succès !');
        setUploadingLogo(false);
      }
    };

    reader.onerror = () => {
      showNotification('Erreur de lecture du fichier image', 'error');
      setUploadingLogo(false);
    };

    reader.readAsDataURL(file);
  };

  // News operations
  const handleSaveArticle = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingArticle?.title?.trim()) {
      showNotification("Veuillez renseigner le titre de l'actualité", 'error');
      return;
    }

    setIsSavingArticle(true);
    const result = await saveNewsRecord({
      ...editingArticle,
      title: editingArticle.title.trim(),
      category: editingArticle.category || 'Nouveautés 0 km',
      published_at: editingArticle.published_at || new Date().toISOString().split('T')[0],
      is_published: editingArticle.is_published ?? true,
      is_featured: editingArticle.is_featured ?? false,
      read_time: editingArticle.read_time || '3 min',
      author: editingArticle.author || 'Équipe IPM Motors',
    });

    if (result.success) {
      showNotification(`Actualité "${result.article.title}" enregistrée avec succès !`);
      setEditingArticle(null);
      loadNews();
    } else {
      showNotification(`Erreur d'enregistrement : ${result.error}`, 'error');
    }
    setIsSavingArticle(false);
  };

  const handleDeleteArticle = async (id: string) => {
    await deleteNewsRecord(id);
    setDeleteConfirmArticleId(null);
    showNotification('Actualité supprimée');
    loadNews();
  };

  const handleArticleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingArticleImage(true);

    const reader = new FileReader();
    reader.onload = async () => {
      const base64Url = reader.result as string;
      setEditingArticle((prev) => ({ ...prev, cover_image: base64Url }));

      if (isSupabaseConfigured()) {
        try {
          const { url, error } = await uploadVehicleImage(file);
          if (url) {
            setEditingArticle((prev) => ({ ...prev, cover_image: url }));
            showNotification('Image téléversée avec succès !');
          } else if (error) {
            showNotification('Image enregistrée en haute définition locale', 'success');
          }
        } catch {
          // Keep base64
        } finally {
          setUploadingArticleImage(false);
        }
      } else {
        showNotification('Image enregistrée avec succès');
        setUploadingArticleImage(false);
      }
    };

    reader.onerror = () => {
      showNotification('Impossible de lire le fichier image sélectionné', 'error');
      setUploadingArticleImage(false);
    };

    reader.readAsDataURL(file);
  };

  // 1. Login View
  if (!session) {
    return (
      <div className="min-h-screen bg-[#0A0A0A] text-white flex flex-col justify-center items-center px-4 py-12">
        <div className="w-full max-w-md bg-[#141414] border border-[#2A2A2A] rounded-xl p-8 shadow-2xl space-y-6">
          <div className="text-center space-y-2">
            <img
              src="/assets/aistudio/image_150e736b.png"
              alt="IPM Motors"
              className="h-12 w-auto mx-auto object-contain"
            />
            <h1 className="text-xl font-bold tracking-tight text-white">
              Espace Administration IPM Motors
            </h1>
            <p className="text-xs text-[#8A8A8A]">
              Gestion du catalogue, marques partenaires & demandes clients
            </p>
          </div>

          {!isSupabaseConfigured() && (
            <div className="p-3 bg-[#1A1A1A] border border-[#333333] rounded-lg text-xs text-[#AAAAAA] space-y-1">
              <div className="flex items-center gap-1.5 font-semibold text-[#E10600]">
                <AlertCircle className="w-4 h-4" />
                <span>Base Supabase en attente de clés</span>
              </div>
              <p>Pour tester l'interface en mode prévisualisation :</p>
              <div className="font-mono text-[11px] text-white bg-black/60 p-1.5 rounded">
                admin@ipmotors.ci / admin
              </div>
            </div>
          )}

          {authError && (
            <div className="p-3 bg-red-950/60 border border-red-800 rounded-lg text-xs text-red-200">
              {authError}
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1.5">
                E-mail administrateur
              </label>
              <input
                type="email"
                required
                value={authEmail}
                onChange={(e) => setAuthEmail(e.target.value)}
                placeholder="admin@ipmotors.ci"
                className="w-full px-3.5 py-2.5 text-sm bg-[#0A0A0A] border border-[#2A2A2A] rounded-md text-white focus:outline-none focus:border-[#E10600]"
              />
            </div>

            <div>
              <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1.5">
                Mot de passe
              </label>
              <input
                type="password"
                required
                value={authPassword}
                onChange={(e) => setAuthPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-3.5 py-2.5 text-sm bg-[#0A0A0A] border border-[#2A2A2A] rounded-md text-white focus:outline-none focus:border-[#E10600]"
              />
            </div>

            <button
              type="submit"
              disabled={isAuthLoading}
              className="w-full py-3 bg-[#E10600] hover:bg-[#B00500] disabled:bg-[#E10600]/50 text-white text-xs font-bold uppercase tracking-wider rounded-md transition-colors cursor-pointer"
            >
              {isAuthLoading ? 'Connexion en cours...' : 'Se connecter'}
            </button>
          </form>

          <div className="pt-4 border-t border-[#2A2A2A] text-center">
            <button
              onClick={onBackToSite}
              className="inline-flex items-center gap-1.5 text-xs text-[#8A8A8A] hover:text-white transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Retourner au site public</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 2. Admin Dashboard with 3 Tabs: Vehicles, Brands, Leads
  return (
    <div className="min-h-screen bg-[#0A0A0A] text-white flex flex-col">
      {/* Top Header */}
      <header className="bg-[#141414] border-b border-[#2A2A2A] px-4 sm:px-8 py-4 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <button
              onClick={onBackToSite}
              className="p-2 text-[#8A8A8A] hover:text-white hover:bg-white/5 rounded-md transition-colors"
              title="Voir le site en direct"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3">
              <img
                src="/assets/aistudio/image_150e736b.png"
                alt="Logo IPM"
                className="h-8 w-auto object-contain"
              />
              <div>
                <span className="text-base font-bold text-white tracking-tight">IPM MOTORS</span>
                <span className="ml-2 px-2 py-0.5 text-[10px] uppercase font-bold bg-[#E10600] text-white rounded">
                  Admin
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <span className="hidden sm:inline-block text-xs text-[#8A8A8A]">
              Connecté : <span className="text-white font-medium">{session?.user?.email || 'admin@ipmotors.ci'}</span>
            </span>
            <button
              onClick={handleLogout}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs text-[#8A8A8A] hover:text-white hover:bg-white/5 rounded transition-colors cursor-pointer border border-[#2A2A2A]"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Déconnexion</span>
            </button>
          </div>
        </div>
      </header>

      {/* Toast Notification */}
      {notification && (
        <div className="fixed top-20 right-6 z-50 p-4 rounded-lg shadow-2xl flex items-center gap-3 text-xs font-semibold animate-in fade-in duration-200 border bg-[#141414] border-[#E10600] text-white">
          {notification.type === 'success' ? (
            <CheckCircle className="w-4 h-4 text-[#E10600]" />
          ) : (
            <AlertCircle className="w-4 h-4 text-red-500" />
          )}
          <span>{notification.message}</span>
        </div>
      )}

      {/* Main Content */}
      <main className="max-w-7xl mx-auto w-full px-4 sm:px-8 py-8 flex-1 space-y-6">
        {/* Navigation Tabs */}
        <div className="flex flex-wrap items-center justify-between border-b border-[#2A2A2A] pb-4 gap-4">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('vehicles')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-xs uppercase tracking-wider font-semibold transition-colors cursor-pointer ${
                activeTab === 'vehicles'
                  ? 'bg-[#E10600] text-white'
                  : 'text-[#8A8A8A] hover:text-white hover:bg-[#141414]'
              }`}
            >
              <Car className="w-4 h-4" />
              <span>Catalogue ({vehicles.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('brands')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-xs uppercase tracking-wider font-semibold transition-colors cursor-pointer ${
                activeTab === 'brands'
                  ? 'bg-[#E10600] text-white'
                  : 'text-[#8A8A8A] hover:text-white hover:bg-[#141414]'
              }`}
            >
              <Tags className="w-4 h-4" />
              <span>Marques ({brands.length})</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('news');
                loadNews();
              }}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-xs uppercase tracking-wider font-semibold transition-colors cursor-pointer ${
                activeTab === 'news'
                  ? 'bg-[#E10600] text-white'
                  : 'text-[#8A8A8A] hover:text-white hover:bg-[#141414]'
              }`}
            >
              <Newspaper className="w-4 h-4" />
              <span>Actualités ({newsList.length})</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('leads');
                loadLeads();
              }}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-xs uppercase tracking-wider font-semibold transition-colors cursor-pointer ${
                activeTab === 'leads'
                  ? 'bg-[#E10600] text-white'
                  : 'text-[#8A8A8A] hover:text-white hover:bg-[#141414]'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>Demandes ({leads.length})</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('newsletter');
                loadSubscribers();
              }}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-xs uppercase tracking-wider font-semibold transition-colors cursor-pointer ${
                activeTab === 'newsletter'
                  ? 'bg-[#E10600] text-white'
                  : 'text-[#8A8A8A] hover:text-white hover:bg-[#141414]'
              }`}
            >
              <Mail className="w-4 h-4" />
              <span>Newsletter ({subscribers.length})</span>
            </button>
          </div>

          {activeTab === 'newsletter' && (
            <button
              onClick={exportSubscribersCSV}
              className="inline-flex items-center gap-2 px-4 py-2 bg-[#222222] hover:bg-[#333333] text-white text-xs uppercase tracking-wider font-bold rounded-md transition-colors cursor-pointer border border-[#333333]"
            >
              <Download className="w-4 h-4 text-[#E10600]" />
              <span>Exporter en CSV</span>
            </button>
          )}

          {activeTab === 'vehicles' && (
            <button
              onClick={() =>
                setEditingVehicle({
                  brand: 'Toyota',
                  model: '',
                  year: new Date().getFullYear(),
                  type: 'SUV',
                  fuel: 'Essence',
                  transmission: 'Automatique',
                  seats: 5,
                  price: null,
                  price_label: 'Sur demande',
                  is_available: true,
                  is_featured: false,
                  images: [],
                  description: '',
                })
              }
              className="inline-flex items-center gap-2 px-4 py-2 bg-[#E10600] hover:bg-[#B00500] text-white text-xs uppercase tracking-wider font-bold rounded-md transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Ajouter un véhicule</span>
            </button>
          )}

          {activeTab === 'brands' && (
            <button
              onClick={() =>
                setEditingBrand({
                  name: '',
                  sort_order: brands.length + 1,
                  is_active: true,
                  logo_url: '',
                })
              }
              className="inline-flex items-center gap-2 px-4 py-2 bg-[#E10600] hover:bg-[#B00500] text-white text-xs uppercase tracking-wider font-bold rounded-md transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Ajouter une marque</span>
            </button>
          )}

          {activeTab === 'news' && (
            <button
              onClick={() =>
                setEditingArticle({
                  title: '',
                  category: 'Nouveautés 0 km',
                  excerpt: '',
                  content: '',
                  cover_image: '',
                  author: 'Équipe IPM Motors',
                  published_at: new Date().toISOString().split('T')[0],
                  read_time: '3 min',
                  is_featured: false,
                  is_published: true,
                })
              }
              className="inline-flex items-center gap-2 px-4 py-2 bg-[#E10600] hover:bg-[#B00500] text-white text-xs uppercase tracking-wider font-bold rounded-md transition-colors cursor-pointer shadow-lg shadow-[#E10600]/25"
            >
              <Plus className="w-4 h-4" />
              <span>Nouvelle actualité</span>
            </button>
          )}
        </div>

        {/* Tab 1: Vehicles List */}
        {activeTab === 'vehicles' && (
          <div className="space-y-4">
            {isLoadingVehicles ? (
              <div className="p-12 text-center text-[#8A8A8A]">Chargement des véhicules...</div>
            ) : vehicles.length === 0 ? (
              <div className="p-12 text-center bg-[#141414] rounded-lg border border-[#2A2A2A]">
                <p className="text-sm text-[#8A8A8A]">Aucun véhicule dans le catalogue.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {vehicles.map((v) => (
                  <div
                    key={v.id}
                    className={`bg-[#141414] rounded-lg border overflow-hidden flex flex-col justify-between transition-colors ${
                      v.is_available ? 'border-[#2A2A2A]' : 'border-red-900/40 opacity-70'
                    }`}
                  >
                    <div>
                      <div className="relative aspect-[16/10] bg-[#0A0A0A]">
                        <img
                          src={v.images?.[0] || '/src/assets/images/hero_dealership_car_1793116464643.jpg'}
                          alt={v.model}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute top-2 left-2 flex gap-1">
                          <span className="px-2 py-0.5 text-[10px] font-bold uppercase bg-[#E10600] text-white rounded">
                            Neuf 0 km
                          </span>
                          {v.is_featured && (
                            <span className="px-2 py-0.5 text-[10px] font-bold uppercase bg-amber-500 text-black rounded flex items-center gap-1">
                              <Star className="w-3 h-3 fill-black" />
                              Vedette
                            </span>
                          )}
                        </div>
                        <div className="absolute top-2 right-2">
                          <span
                            className={`px-2 py-0.5 text-[10px] font-bold rounded ${
                              v.is_available ? 'bg-emerald-950 text-emerald-400 border border-emerald-700' : 'bg-red-950 text-red-400 border border-red-800'
                            }`}
                          >
                            {v.is_available ? 'Affiché' : 'Masqué'}
                          </span>
                        </div>
                      </div>

                      <div className="p-4 space-y-2">
                        <div className="text-xs text-[#E10600] font-bold uppercase tracking-wider">
                          {v.brand} · {v.type}
                        </div>
                        <h3 className="text-lg font-bold text-white leading-tight">
                          {v.model} ({v.year})
                        </h3>
                        <p className="text-xs text-[#8A8A8A]">
                          {v.fuel} · {v.transmission}
                        </p>
                        <div className="text-sm font-bold text-white tabular-nums pt-1">
                          {v.price ? `${new Intl.NumberFormat('fr-FR').format(v.price)} FCFA` : v.price_label || 'Sur demande'}
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-[#0A0A0A] border-t border-[#2A2A2A] flex items-center justify-between gap-2">
                      <button
                        onClick={() => handleToggleVisibility(v)}
                        className="p-2 text-[#8A8A8A] hover:text-white hover:bg-white/5 rounded transition-colors"
                        title={v.is_available ? 'Masquer du site public' : 'Rendre visible sur le site'}
                      >
                        {v.is_available ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4 text-red-400" />}
                      </button>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => setEditingVehicle(v)}
                          className="px-3 py-1.5 bg-[#222222] hover:bg-[#333333] text-white text-xs font-semibold rounded flex items-center gap-1.5 transition-colors"
                        >
                          <Edit className="w-3.5 h-3.5" />
                          <span>Modifier</span>
                        </button>
                        <button
                          onClick={() => setDeleteConfirmVehicleId(v.id)}
                          className="p-2 text-red-400 hover:text-red-300 hover:bg-red-950/40 rounded transition-colors"
                          title="Supprimer définitivement"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Brands Management (PARTIE 1) */}
        {activeTab === 'brands' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-white">Marques partenaires & logos</h2>
                <p className="text-xs text-[#8A8A8A]">
                  Gestion de la table Supabase <code className="text-white">brands</code> et logos stockés dans le bucket <code className="text-white">brand-logos</code>.
                </p>
              </div>
              <button
                onClick={loadBrands}
                className="text-xs text-[#E10600] hover:underline"
              >
                Actualiser
              </button>
            </div>

            {isLoadingBrands ? (
              <div className="p-12 text-center text-[#8A8A8A]">Chargement des marques...</div>
            ) : brands.length === 0 ? (
              <div className="p-12 text-center bg-[#141414] rounded-lg border border-[#2A2A2A]">
                <p className="text-sm text-[#8A8A8A]">Aucune marque enregistrée.</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {brands.map((brand) => (
                  <div
                    key={brand.id}
                    className={`bg-[#141414] rounded-xl border p-4 flex flex-col justify-between transition-colors ${
                      brand.is_active ? 'border-[#2A2A2A]' : 'border-red-900/40 opacity-60'
                    }`}
                  >
                    <div className="space-y-3">
                      {/* Logo Preview Tile */}
                      <div className="w-full aspect-square bg-white rounded-lg p-2 flex items-center justify-center border border-neutral-200">
                        {brand.logo_url || DEFAULT_BRAND_LOGOS[brand.name] ? (
                          <img
                            key={brand.logo_url || brand.name}
                            src={brand.logo_url || DEFAULT_BRAND_LOGOS[brand.name]}
                            alt={`Logo ${brand.name}`}
                            className="max-h-10 max-w-[85%] object-contain"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement;
                              target.style.display = 'none';
                            }}
                          />
                        ) : (
                          <span className="text-xs font-bold text-neutral-800 uppercase">{brand.name}</span>
                        )}
                      </div>

                      <div className="text-center">
                        <h4 className="text-sm font-bold text-white">{brand.name}</h4>
                        <div className="flex items-center justify-center gap-2 text-[11px] text-[#8A8A8A] mt-1">
                          <span>Ordre : {brand.sort_order}</span>
                          <span>·</span>
                          <span className={brand.is_active ? 'text-emerald-400' : 'text-red-400'}>
                            {brand.is_active ? 'Actif' : 'Inactif'}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-[#2A2A2A] flex items-center justify-between">
                      <button
                        onClick={() => setEditingBrand(brand)}
                        className="text-xs text-[#8A8A8A] hover:text-white flex items-center gap-1"
                      >
                        <Edit className="w-3.5 h-3.5" />
                        <span>Modifier</span>
                      </button>
                      <button
                        onClick={() => setDeleteConfirmBrandId(brand.id)}
                        className="text-xs text-red-400 hover:text-red-300 p-1"
                        title="Supprimer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 3: News Management */}
        {activeTab === 'news' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-white">Actualités & Événements</h2>
                <p className="text-xs text-[#8A8A8A]">
                  Gestion des articles, nouveaux arrivages 0 km et offres du showroom.
                </p>
              </div>
              <button
                onClick={loadNews}
                className="text-xs text-[#E10600] hover:underline cursor-pointer"
              >
                Actualiser
              </button>
            </div>

            {isLoadingNews ? (
              <div className="p-12 text-center text-[#8A8A8A]">Chargement des actualités...</div>
            ) : newsList.length === 0 ? (
              <div className="p-12 text-center bg-[#141414] rounded-lg border border-[#2A2A2A]">
                <p className="text-sm text-[#8A8A8A]">Aucun article d'actualité pour le moment.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {newsList.map((article) => (
                  <div
                    key={article.id}
                    className={`bg-[#141414] rounded-xl border flex flex-col justify-between overflow-hidden transition-colors ${
                      article.is_published ? 'border-[#2A2A2A]' : 'border-red-950/60 opacity-60'
                    }`}
                  >
                    <div>
                      {/* Cover Thumbnail */}
                      <div className="relative aspect-[16/9] w-full bg-black overflow-hidden">
                        <img
                          src={article.cover_image}
                          alt={article.title}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.src = '/src/assets/images/hero_dealership_car_1793116464643.jpg';
                          }}
                        />
                        <div className="absolute top-2 left-2 flex items-center gap-1.5">
                          <span className="text-[10px] uppercase tracking-wider font-bold text-white bg-black/85 px-2 py-0.5 rounded backdrop-blur-sm">
                            {article.category}
                          </span>
                          {article.is_featured && (
                            <span className="text-[10px] uppercase font-bold text-white bg-[#E10600] px-2 py-0.5 rounded shadow">
                              À la une
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="p-4 space-y-2">
                        <div className="flex items-center justify-between text-[11px] text-[#8A8A8A]">
                          <span>{article.published_at}</span>
                          <span className={article.is_published ? 'text-emerald-400 font-semibold' : 'text-red-400 font-semibold'}>
                            {article.is_published ? 'Publié' : 'Brouillon'}
                          </span>
                        </div>
                        <h4 className="text-base font-bold text-white line-clamp-2">
                          {article.title}
                        </h4>
                        <p className="text-xs text-[#8A8A8A] line-clamp-2">
                          {article.excerpt}
                        </p>
                      </div>
                    </div>

                    <div className="p-4 bg-[#0A0A0A] border-t border-[#2A2A2A] flex items-center justify-between">
                      <button
                        onClick={() => setEditingArticle(article)}
                        className="text-xs text-[#8A8A8A] hover:text-white flex items-center gap-1.5 cursor-pointer"
                      >
                        <Edit className="w-3.5 h-3.5" />
                        <span>Modifier</span>
                      </button>

                      <button
                        onClick={() => setDeleteConfirmArticleId(article.id)}
                        className="text-xs text-red-400 hover:text-red-300 p-1 cursor-pointer"
                        title="Supprimer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 4: Leads List */}
        {activeTab === 'leads' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-white">Demandes de contact reçues</h2>
              <button
                onClick={loadLeads}
                className="text-xs text-[#E10600] hover:underline"
              >
                Actualiser la liste
              </button>
            </div>

            {isLoadingLeads ? (
              <div className="p-12 text-center text-[#8A8A8A]">Chargement des demandes...</div>
            ) : leads.length === 0 ? (
              <div className="p-12 text-center bg-[#141414] rounded-lg border border-[#2A2A2A]">
                <p className="text-sm text-[#8A8A8A]">Aucune demande pour le moment.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {leads.map((lead) => {
                  const replyMsg = `Bonjour ${lead.name}, nous avons bien reçu votre demande concernant nos véhicules neufs chez IPM Motors Cocody Riviera. Comment pouvons-nous vous aider ?`;
                  const replyUrl = buildWhatsAppUrl(replyMsg, lead.phone.replace(/[^0-9]/g, ''));

                  return (
                    <div
                      key={lead.id}
                      className="bg-[#141414] border border-[#2A2A2A] rounded-lg p-5 flex flex-col md:flex-row md:items-center justify-between gap-4"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-3">
                          <h4 className="text-base font-bold text-white">{lead.name}</h4>
                          <span className="text-xs text-[#8A8A8A] tabular-nums">
                            {lead.created_at ? new Date(lead.created_at).toLocaleDateString('fr-FR', {
                              day: '2-digit',
                              month: 'short',
                              year: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit'
                            }) : ''}
                          </span>
                        </div>
                        <p className="text-xs text-[#E10600] font-semibold">
                          Tél : <a href={`tel:${lead.phone}`} className="hover:underline">{lead.phone}</a>
                        </p>
                        <p className="text-sm text-[#CCCCCC] bg-[#0A0A0A] p-2.5 rounded border border-[#2A2A2A] mt-2">
                          "{lead.message}"
                        </p>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <a
                          href={`tel:${lead.phone}`}
                          className="px-3.5 py-2 bg-[#222222] hover:bg-[#333333] text-white text-xs font-semibold rounded-md flex items-center gap-1.5 transition-colors"
                        >
                          <Phone className="w-3.5 h-3.5 text-[#E10600]" />
                          <span>Appeler</span>
                        </a>
                        <a
                          href={replyUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-4 py-2 bg-[#E10600] hover:bg-[#B00500] text-white text-xs font-bold uppercase tracking-wider rounded-md flex items-center gap-1.5 transition-colors"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span>Répondre WhatsApp</span>
                        </a>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Tab 5: Newsletter Subscribers List */}
        {activeTab === 'newsletter' && (
          <div className="space-y-4">
            {isLoadingSubscribers ? (
              <div className="p-12 text-center text-[#8A8A8A]">Chargement des abonnés...</div>
            ) : subscribers.length === 0 ? (
              <div className="p-12 text-center bg-[#141414] rounded-lg border border-[#2A2A2A]">
                <Mail className="w-8 h-8 text-[#E10600] mx-auto mb-2 opacity-60" />
                <p className="text-sm text-[#8A8A8A]">Aucun abonné enregistré pour le moment.</p>
              </div>
            ) : (
              <div className="bg-[#141414] rounded-xl border border-[#2A2A2A] overflow-hidden">
                <div className="p-4 border-b border-[#2A2A2A] flex items-center justify-between">
                  <span className="text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold">
                    Liste des adresses e-mail ({subscribers.length})
                  </span>
                  <button
                    onClick={exportSubscribersCSV}
                    className="inline-flex items-center gap-1.5 text-xs text-[#E10600] font-semibold hover:underline"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Télécharger CSV</span>
                  </button>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-[#0E0E11] text-[#8A8A8A] uppercase font-mono border-b border-[#2A2A2A]">
                      <tr>
                        <th className="p-3.5">E-mail</th>
                        <th className="p-3.5">Source</th>
                        <th className="p-3.5">Date d'inscription</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#2A2A2A]">
                      {subscribers.map((sub) => (
                        <tr key={sub.id} className="hover:bg-white/5 transition-colors">
                          <td className="p-3.5 font-medium text-white">{sub.email}</td>
                          <td className="p-3.5 text-[#8A8A8A]">{sub.source || 'Site web'}</td>
                          <td className="p-3.5 text-[#8A8A8A] font-mono">
                            {new Date(sub.created_at).toLocaleDateString('fr-FR', {
                              day: '2-digit',
                              month: 'short',
                              year: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Delete Vehicle Confirmation Modal */}
      {deleteConfirmVehicleId && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-[#141414] border border-[#2A2A2A] rounded-xl max-w-md w-full p-6 space-y-4">
            <h3 className="text-lg font-bold text-white">Confirmer la suppression ?</h3>
            <p className="text-sm text-[#8A8A8A]">
              Cette action retirera définitivement ce véhicule du catalogue. Êtes-vous sûr de vouloir continuer ?
            </p>
            <div className="flex items-center justify-end gap-3 pt-4">
              <button
                onClick={() => setDeleteConfirmVehicleId(null)}
                className="px-4 py-2 bg-[#222222] text-white text-xs rounded font-medium hover:bg-[#333333]"
              >
                Annuler
              </button>
              <button
                onClick={() => handleDeleteVehicle(deleteConfirmVehicleId)}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs rounded font-bold uppercase tracking-wider"
              >
                Supprimer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Brand Confirmation Modal */}
      {deleteConfirmBrandId && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-[#141414] border border-[#2A2A2A] rounded-xl max-w-md w-full p-6 space-y-4">
            <h3 className="text-lg font-bold text-white">Supprimer cette marque ?</h3>
            <p className="text-sm text-[#8A8A8A]">
              Cette marque ne s'affichera plus dans la grille du site. Confirmez-vous la suppression ?
            </p>
            <div className="flex items-center justify-end gap-3 pt-4">
              <button
                onClick={() => setDeleteConfirmBrandId(null)}
                className="px-4 py-2 bg-[#222222] text-white text-xs rounded font-medium hover:bg-[#333333]"
              >
                Annuler
              </button>
              <button
                onClick={() => handleDeleteBrand(deleteConfirmBrandId)}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs rounded font-bold uppercase tracking-wider"
              >
                Supprimer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Article Confirmation Modal */}
      {deleteConfirmArticleId && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-[#141414] border border-[#2A2A2A] rounded-xl max-w-md w-full p-6 space-y-4">
            <h3 className="text-lg font-bold text-white">Supprimer cette actualité ?</h3>
            <p className="text-sm text-[#8A8A8A]">
              Cette action retirera définitivement cet article du site web. Êtes-vous sûr de vouloir continuer ?
            </p>
            <div className="flex items-center justify-end gap-3 pt-4">
              <button
                onClick={() => setDeleteConfirmArticleId(null)}
                className="px-4 py-2 bg-[#222222] text-white text-xs rounded font-medium hover:bg-[#333333] cursor-pointer"
              >
                Annuler
              </button>
              <button
                onClick={() => handleDeleteArticle(deleteConfirmArticleId)}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs rounded font-bold uppercase tracking-wider cursor-pointer"
              >
                Supprimer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add / Edit Article Modal */}
      {editingArticle && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#141414] border border-[#2A2A2A] rounded-xl max-w-2xl w-full max-h-[92vh] overflow-y-auto p-6 sm:p-8 space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-[#2A2A2A]">
              <h2 className="text-lg font-bold text-white">
                {editingArticle.id ? "Modifier l'actualité" : 'Nouvelle actualité 0 km'}
              </h2>
              <button onClick={() => setEditingArticle(null)} className="text-[#8A8A8A] hover:text-white cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveArticle} className="space-y-4">
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                  Titre de l'article *
                </label>
                <input
                  type="text"
                  required
                  value={editingArticle.title || ''}
                  onChange={(e) => setEditingArticle({ ...editingArticle, title: e.target.value })}
                  placeholder="Ex: Arrivage exclusif : Nouvelle flotte Land Cruiser 0 km"
                  className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded text-sm text-white focus:outline-none focus:border-[#E10600]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                    Catégorie
                  </label>
                  <select
                    value={editingArticle.category || 'Nouveautés 0 km'}
                    onChange={(e) => setEditingArticle({ ...editingArticle, category: e.target.value })}
                    className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded text-sm text-white focus:outline-none focus:border-[#E10600]"
                  >
                    <option value="Nouveautés 0 km">Nouveautés 0 km</option>
                    <option value="Offres Spéciales">Offres Spéciales</option>
                    <option value="Électrique & Hybride">Électrique & Hybride</option>
                    <option value="Tout-Terrain">Tout-Terrain & Prestige</option>
                    <option value="Événement IPM">Événement IPM</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                    Date de publication
                  </label>
                  <input
                    type="date"
                    value={editingArticle.published_at || new Date().toISOString().split('T')[0]}
                    onChange={(e) => setEditingArticle({ ...editingArticle, published_at: e.target.value })}
                    className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded text-sm text-white focus:outline-none focus:border-[#E10600]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                    Auteur
                  </label>
                  <input
                    type="text"
                    value={editingArticle.author || 'Équipe IPM Motors'}
                    onChange={(e) => setEditingArticle({ ...editingArticle, author: e.target.value })}
                    className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded text-sm text-white focus:outline-none focus:border-[#E10600]"
                  />
                </div>

                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                    Temps de lecture estimé
                  </label>
                  <input
                    type="text"
                    value={editingArticle.read_time || '3 min'}
                    onChange={(e) => setEditingArticle({ ...editingArticle, read_time: e.target.value })}
                    placeholder="Ex: 3 min"
                    className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded text-sm text-white focus:outline-none focus:border-[#E10600]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                  Résumé / Accroche (affiché sur la vignette) *
                </label>
                <textarea
                  rows={2}
                  required
                  value={editingArticle.excerpt || ''}
                  onChange={(e) => setEditingArticle({ ...editingArticle, excerpt: e.target.value })}
                  placeholder="Court résumé percutant pour attirer l'attention du client..."
                  className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded text-sm text-white focus:outline-none focus:border-[#E10600]"
                />
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                  Contenu détaillé de l'article *
                </label>
                <textarea
                  rows={5}
                  required
                  value={editingArticle.content || ''}
                  onChange={(e) => setEditingArticle({ ...editingArticle, content: e.target.value })}
                  placeholder="Texte complet de l'actualité, caractéristiques des véhicules, conditions de l'offre..."
                  className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded text-sm text-white focus:outline-none focus:border-[#E10600]"
                />
              </div>

              {/* Cover Image */}
              <div className="space-y-2">
                <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold">
                  Image de couverture de l'actualité
                </label>

                <input
                  type="text"
                  value={editingArticle.cover_image || ''}
                  onChange={(e) => setEditingArticle({ ...editingArticle, cover_image: e.target.value })}
                  placeholder="URL d'image (https://...) ou téléversez ci-dessous"
                  className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded text-xs text-white focus:outline-none focus:border-[#E10600] font-mono"
                />

                <div className="flex items-center gap-3">
                  <label className="inline-flex items-center gap-2 px-3 py-2 bg-[#222222] hover:bg-[#333333] text-white text-xs font-semibold rounded cursor-pointer transition-colors border border-[#333333]">
                    <Upload className="w-3.5 h-3.5 text-[#E10600]" />
                    <span>{uploadingArticleImage ? 'Téléversement...' : 'Téléverser une image'}</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleArticleImageUpload}
                      className="hidden"
                      disabled={uploadingArticleImage}
                    />
                  </label>
                </div>

                {editingArticle.cover_image && (
                  <div className="relative aspect-[16/9] max-h-40 rounded-lg overflow-hidden border border-[#333333] bg-black">
                    <img
                      src={editingArticle.cover_image}
                      alt="Aperçu couverture"
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
              </div>

              {/* Toggles */}
              <div className="flex flex-wrap items-center gap-6 pt-2">
                <label className="flex items-center gap-2 text-xs text-white cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingArticle.is_published ?? true}
                    onChange={(e) => setEditingArticle({ ...editingArticle, is_published: e.target.checked })}
                    className="w-4 h-4 text-[#E10600] rounded focus:ring-0"
                  />
                  <span>Publier immédiatement (visible sur le site)</span>
                </label>

                <label className="flex items-center gap-2 text-xs text-white cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingArticle.is_featured ?? false}
                    onChange={(e) => setEditingArticle({ ...editingArticle, is_featured: e.target.checked })}
                    className="w-4 h-4 text-[#E10600] rounded focus:ring-0"
                  />
                  <span>Mettre à la une (Grand format accueil)</span>
                </label>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-[#2A2A2A]">
                <button
                  type="button"
                  onClick={() => setEditingArticle(null)}
                  className="px-4 py-2 bg-[#222222] hover:bg-[#333333] text-white text-xs rounded font-medium cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  disabled={isSavingArticle}
                  className="px-6 py-2 bg-[#E10600] hover:bg-[#B00500] text-white text-xs font-bold uppercase tracking-wider rounded transition-colors cursor-pointer"
                >
                  {isSavingArticle ? 'Enregistrement...' : "Enregistrer l'actualité"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add / Edit Brand Modal */}
      {editingBrand && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#141414] border border-[#2A2A2A] rounded-xl max-w-md w-full p-6 space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-[#2A2A2A]">
              <h2 className="text-lg font-bold text-white">
                {editingBrand.id ? 'Modifier la marque' : 'Ajouter une marque'}
              </h2>
              <button onClick={() => setEditingBrand(null)} className="text-[#8A8A8A] hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveBrand} className="space-y-4">
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                  Nom de la marque *
                </label>
                <input
                  type="text"
                  required
                  value={editingBrand.name || ''}
                  onChange={(e) => setEditingBrand({ ...editingBrand, name: e.target.value })}
                  placeholder="Ex: BYD, Toyota, Jetour..."
                  className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded text-sm text-white focus:outline-none focus:border-[#E10600]"
                />
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                  Ordre d'affichage
                </label>
                <input
                  type="number"
                  value={editingBrand.sort_order || 1}
                  onChange={(e) => setEditingBrand({ ...editingBrand, sort_order: Number(e.target.value) })}
                  className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded text-sm text-white focus:outline-none focus:border-[#E10600]"
                />
              </div>

              {/* Logo Management */}
              <div className="space-y-2">
                <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold">
                  Logo de la marque
                </label>

                {/* Direct URL input */}
                <div>
                  <input
                    type="text"
                    value={editingBrand.logo_url || ''}
                    onChange={(e) => setEditingBrand({ ...editingBrand, logo_url: e.target.value })}
                    placeholder="Coller l'URL d'un logo (https://... ou data:image/...)"
                    className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded text-xs text-white focus:outline-none focus:border-[#E10600] font-mono"
                  />
                  <p className="text-[11px] text-[#8A8A8A] mt-1">
                    Vous pouvez coller directement un lien d'image ou téléverser un fichier ci-dessous.
                  </p>
                </div>

                {/* Upload & Action Buttons */}
                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <label className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#222222] hover:bg-[#333333] text-white text-xs font-semibold rounded cursor-pointer transition-colors border border-[#333333]">
                    <Upload className="w-3.5 h-3.5 text-[#E10600]" />
                    <span>{uploadingLogo ? 'Chargement...' : 'Téléverser un logo'}</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleLogoUpload}
                      className="hidden"
                      disabled={uploadingLogo}
                    />
                  </label>

                  {editingBrand.name && DEFAULT_BRAND_LOGOS[editingBrand.name] && (
                    <button
                      type="button"
                      onClick={() => {
                        const defLogo = resetBrandToDefault(editingBrand.name!);
                        if (defLogo) {
                          setEditingBrand((prev) => ({ ...prev, logo_url: defLogo }));
                          showNotification(`Logo officiel ${editingBrand.name} restauré`);
                        }
                      }}
                      className="px-3 py-1.5 bg-[#1A1A1A] hover:bg-[#252525] text-neutral-300 text-xs font-medium rounded border border-[#333333] transition-colors"
                    >
                      Restaurer logo officiel
                    </button>
                  )}

                  {editingBrand.logo_url && (
                    <button
                      type="button"
                      onClick={() => setEditingBrand((prev) => ({ ...prev, logo_url: '' }))}
                      className="px-2.5 py-1.5 bg-red-950/40 hover:bg-red-900/60 text-red-300 text-xs font-medium rounded border border-red-900/60 transition-colors"
                    >
                      Effacer
                    </button>
                  )}
                </div>

                {/* Live Preview matching the public site tile */}
                <div className="pt-2">
                  <div className="text-[11px] uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1.5">
                    Aperçu en direct (tel qu'affiché dans « Nos marques »)
                  </div>
                  <div className="w-full bg-white rounded-[12px] p-4 flex flex-col items-center justify-center border border-neutral-300 aspect-[16/9] max-h-32 shadow-inner">
                    {editingBrand.logo_url ? (
                      <img
                        key={editingBrand.logo_url}
                        src={editingBrand.logo_url}
                        alt={`Aperçu ${editingBrand.name || 'Marque'}`}
                        className="max-h-14 max-w-[85%] object-contain"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.style.display = 'none';
                        }}
                      />
                    ) : (
                      <span className="text-sm font-extrabold uppercase text-neutral-800 tracking-wider">
                        {editingBrand.name || 'NOM MARQUE'}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <div className="pt-2">
                <label className="flex items-center gap-2 text-xs text-white cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingBrand.is_active ?? true}
                    onChange={(e) => setEditingBrand({ ...editingBrand, is_active: e.target.checked })}
                    className="w-4 h-4 text-[#E10600] rounded focus:ring-0"
                  />
                  <span>Actif (visible dans la section Marques)</span>
                </label>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-[#2A2A2A]">
                <button
                  type="button"
                  onClick={() => setEditingBrand(null)}
                  className="px-4 py-2 bg-[#222222] hover:bg-[#333333] text-white text-xs rounded font-medium"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  disabled={isSavingBrand}
                  className="px-6 py-2 bg-[#E10600] hover:bg-[#B00500] text-white text-xs font-bold uppercase tracking-wider rounded transition-colors"
                >
                  {isSavingBrand ? 'Enregistrement...' : 'Enregistrer'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add / Edit Vehicle Modal */}
      {editingVehicle && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#141414] border border-[#2A2A2A] rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-[#2A2A2A]">
              <h2 className="text-xl font-bold text-white">
                {editingVehicle.id ? 'Modifier le véhicule' : 'Nouveau véhicule 0 km'}
              </h2>
              <button
                onClick={() => setEditingVehicle(null)}
                className="text-[#8A8A8A] hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveVehicle} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                    Marque du véhicule *
                  </label>
                  <select
                    required
                    value={editingVehicle.brand || (brands[0]?.name || 'Toyota')}
                    onChange={(e) => setEditingVehicle({ ...editingVehicle, brand: e.target.value })}
                    className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded text-sm text-white focus:outline-none focus:border-[#E10600]"
                  >
                    {brands.map((b) => (
                      <option key={b.id} value={b.name} className="bg-[#141414] text-white">
                        {b.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                    Modèle *
                  </label>
                  <input
                    type="text"
                    required
                    value={editingVehicle.model || ''}
                    onChange={(e) => setEditingVehicle({ ...editingVehicle, model: e.target.value })}
                    placeholder="Ex: Land Cruiser LC300 VXR"
                    className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded text-sm text-white focus:outline-none focus:border-[#E10600]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                    Type de carrosserie
                  </label>
                  <select
                    value={editingVehicle.type || 'SUV'}
                    onChange={(e) => setEditingVehicle({ ...editingVehicle, type: e.target.value as VehicleType })}
                    className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded text-sm text-white focus:outline-none focus:border-[#E10600]"
                  >
                    <option value="SUV">SUV</option>
                    <option value="Berline">Berline</option>
                    <option value="Pick-up">Pick-up</option>
                    <option value="Électrique">Électrique</option>
                    <option value="Citadine">Citadine</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                    Année
                  </label>
                  <input
                    type="number"
                    value={editingVehicle.year || 2025}
                    onChange={(e) => setEditingVehicle({ ...editingVehicle, year: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded text-sm text-white focus:outline-none focus:border-[#E10600]"
                  />
                </div>
                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                    Places
                  </label>
                  <input
                    type="number"
                    value={editingVehicle.seats || 5}
                    onChange={(e) => setEditingVehicle({ ...editingVehicle, seats: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded text-sm text-white focus:outline-none focus:border-[#E10600]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                    Carburant
                  </label>
                  <input
                    type="text"
                    value={editingVehicle.fuel || 'Essence'}
                    onChange={(e) => setEditingVehicle({ ...editingVehicle, fuel: e.target.value })}
                    placeholder="Ex: Essence, Diesel, Électrique, Hybride"
                    className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded text-sm text-white focus:outline-none focus:border-[#E10600]"
                  />
                </div>
                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                    Boîte de vitesses
                  </label>
                  <input
                    type="text"
                    value={editingVehicle.transmission || 'Automatique'}
                    onChange={(e) => setEditingVehicle({ ...editingVehicle, transmission: e.target.value })}
                    placeholder="Ex: Automatique"
                    className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded text-sm text-white focus:outline-none focus:border-[#E10600]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                  Motorisation / Puissance
                </label>
                <input
                  type="text"
                  value={editingVehicle.engine || ''}
                  onChange={(e) => setEditingVehicle({ ...editingVehicle, engine: e.target.value })}
                  placeholder="Ex: 3.5L V6 Bi-Turbo 415 ch ou Bimoteur 530 ch"
                  className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded text-sm text-white focus:outline-none focus:border-[#E10600]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                    Prix (FCFA, optionnel)
                  </label>
                  <input
                    type="number"
                    value={editingVehicle.price || ''}
                    onChange={(e) =>
                      setEditingVehicle({
                        ...editingVehicle,
                        price: e.target.value ? Number(e.target.value) : null,
                      })
                    }
                    placeholder="Laisser vide si sur demande"
                    className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded text-sm text-white focus:outline-none focus:border-[#E10600]"
                  />
                </div>
                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                    Libellé de prix
                  </label>
                  <input
                    type="text"
                    value={editingVehicle.price_label || 'Sur demande'}
                    onChange={(e) => setEditingVehicle({ ...editingVehicle, price_label: e.target.value })}
                    placeholder="Ex: Sur demande"
                    className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded text-sm text-white focus:outline-none focus:border-[#E10600]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                  Description & Équipements
                </label>
                <textarea
                  rows={3}
                  value={editingVehicle.description || ''}
                  onChange={(e) => setEditingVehicle({ ...editingVehicle, description: e.target.value })}
                  placeholder="Présentation des options de luxe, finitions, garanties..."
                  className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded text-sm text-white focus:outline-none focus:border-[#E10600]"
                />
              </div>

              {/* Photos Management */}
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                  Photos du véhicule (Bucket vehicle-images)
                </label>

                <div className="flex items-center gap-3 mb-3">
                  <label className="inline-flex items-center gap-2 px-4 py-2 bg-[#222222] hover:bg-[#333333] text-white text-xs font-semibold rounded cursor-pointer transition-colors border border-[#333333]">
                    <Upload className="w-3.5 h-3.5" />
                    <span>{uploadingImage ? 'Téléversement...' : 'Téléverser des photos'}</span>
                    <input
                      type="file"
                      multiple
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                      disabled={uploadingImage}
                    />
                  </label>
                  <span className="text-xs text-[#8A8A8A]">
                    {editingVehicle.images?.length || 0} image(s) associée(s)
                  </span>
                </div>

                {editingVehicle.images && editingVehicle.images.length > 0 && (
                  <div className="flex flex-wrap gap-2 p-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded">
                    {editingVehicle.images.map((img, idx) => (
                      <div key={idx} className="relative w-20 h-14 rounded overflow-hidden border border-[#333333] group">
                        <img src={img} alt="Aperçu" className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => {
                            setEditingVehicle({
                              ...editingVehicle,
                              images: editingVehicle.images?.filter((_, i) => i !== idx),
                            });
                          }}
                          className="absolute inset-0 bg-red-900/80 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Section Offre Spéciale */}
              <div className="p-4 rounded-xl border border-[#333333] bg-[#0E0E11] space-y-3">
                <label className="flex items-center gap-2 text-xs text-white font-semibold cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingVehicle.is_offer ?? false}
                    onChange={(e) => setEditingVehicle({ ...editingVehicle, is_offer: e.target.checked })}
                    className="w-4 h-4 text-[#E10600] rounded focus:ring-0"
                  />
                  <span>Véhicule en offre promotionnelle spéciale (affiché dans « Nos Offres »)</span>
                </label>

                {editingVehicle.is_offer && (
                  <div className="space-y-3 pt-2">
                    <div>
                      <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                        Badge de l'offre
                      </label>
                      <input
                        type="text"
                        value={editingVehicle.offer_badge || ''}
                        onChange={(e) => setEditingVehicle({ ...editingVehicle, offer_badge: e.target.value })}
                        placeholder="Ex: Pack Mobilité Électrique Offert, Immatriculation Offerte..."
                        className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded text-xs text-white focus:outline-none focus:border-[#E10600]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs uppercase tracking-wider text-[#8A8A8A] font-semibold mb-1">
                        Points forts de l'offre (un par ligne)
                      </label>
                      <textarea
                        rows={3}
                        value={(editingVehicle.offer_highlights || []).join('\n')}
                        onChange={(e) =>
                          setEditingVehicle({
                            ...editingVehicle,
                            offer_highlights: e.target.value.split('\n').filter(Boolean),
                          })
                        }
                        placeholder="Borne de recharge murale 11kW offerte&#10;Immatriculation et carte grise incluses&#10;Garantie 5 ans ou 100 000 km"
                        className="w-full px-3 py-2 bg-[#0A0A0A] border border-[#2A2A2A] rounded text-xs text-white focus:outline-none focus:border-[#E10600] font-sans"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Toggles */}
              <div className="flex items-center gap-6 pt-2">
                <label className="flex items-center gap-2 text-xs text-white cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingVehicle.is_available ?? true}
                    onChange={(e) =>
                      setEditingVehicle({ ...editingVehicle, is_available: e.target.checked })
                    }
                    className="w-4 h-4 text-[#E10600] rounded focus:ring-0"
                  />
                  <span>Disponible (visible sur le catalogue)</span>
                </label>

                <label className="flex items-center gap-2 text-xs text-white cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingVehicle.is_featured ?? false}
                    onChange={(e) =>
                      setEditingVehicle({ ...editingVehicle, is_featured: e.target.checked })
                    }
                    className="w-4 h-4 text-[#E10600] rounded focus:ring-0"
                  />
                  <span>Mettre en avant (Vedette)</span>
                </label>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-[#2A2A2A]">
                <button
                  type="button"
                  onClick={() => setEditingVehicle(null)}
                  className="px-4 py-2.5 bg-[#222222] hover:bg-[#333333] text-white text-xs rounded font-medium"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  disabled={isSavingVehicle}
                  className="px-6 py-2.5 bg-[#E10600] hover:bg-[#B00500] text-white text-xs font-bold uppercase tracking-wider rounded transition-colors"
                >
                  {isSavingVehicle ? 'Enregistrement...' : 'Enregistrer le véhicule'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
