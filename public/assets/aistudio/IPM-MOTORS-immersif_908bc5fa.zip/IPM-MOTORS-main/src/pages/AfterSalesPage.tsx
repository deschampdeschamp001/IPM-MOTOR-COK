import React, { useState, useEffect } from 'react';
import { FAQ_ITEMS } from '../data/faq';
import { DEALERSHIP_CONFIG, buildWhatsAppUrl } from '../config/dealership';
import {
  ShieldCheck,
  Wrench,
  FileCheck2,
  ChevronDown,
  Phone,
  MessageCircle,
  Clock,
  MapPin
} from 'lucide-react';

export const AfterSalesPage: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<'tous' | 'garantie' | 'entretien' | 'demarches'>('tous');
  const [expandedId, setExpandedId] = useState<string | null>(FAQ_ITEMS[0]?.id || null);

  useEffect(() => {
    document.title = 'Service Après-Vente & Garantie | IPM Motors Abidjan';
  }, []);

  const toggleAccordion = (id: string) => {
    setExpandedId(prev => (prev === id ? null : id));
  };

  const filteredFaq = activeCategory === 'tous'
    ? FAQ_ITEMS
    : FAQ_ITEMS.filter(f => f.category === activeCategory);

  const waUrl = buildWhatsAppUrl("Bonjour IPM Motors, je souhaite poser une question concernant la garantie et le service après-vente.");

  return (
    <div className="pt-24 sm:pt-32 pb-24 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Header épuré et minimaliste */}
      <div className="text-center max-w-3xl mx-auto mb-14">
        <span className="eyebrow block mb-2">Transparence & Sérénité</span>
        <h1 className="font-heading font-light text-3xl sm:text-5xl tracking-tight">
          Service Après-Vente & <span className="font-semibold text-[#e10600]">Garantie</span>
        </h1>
        <p className="text-sm sm:text-base text-[#6b6b72] mt-3 font-light leading-relaxed">
          Chez IPM MOTORS, l’acquisition d’un véhicule 0 km s’accompagne d’un suivi rigoureux. Nous assurons la garantie constructeur, l'entretien certifié et les démarches administratives à Abidjan.
        </p>

        {/* Quick contact shortcuts */}
        <div className="flex flex-wrap items-center justify-center gap-3 mt-6">
          <a
            href={waUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="pill-btn inline-flex items-center gap-2 px-5 py-2.5 bg-[#e10600] text-white text-xs font-semibold shadow-sm hover:bg-[#c30500]"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>Assistance WhatsApp directe</span>
          </a>
          <a
            href={`tel:${DEALERSHIP_CONFIG.phone}`}
            className="pill-btn inline-flex items-center gap-2 px-5 py-2.5 bg-[var(--surface)] text-[var(--fg)] border border-[var(--border)] text-xs font-medium hover:border-[#0b0b0c] dark:hover:border-white"
          >
            <Phone className="w-3.5 h-3.5 text-[#e10600]" />
            <span>{DEALERSHIP_CONFIG.phone}</span>
          </a>
        </div>
      </div>

      {/* 3 Piliers simplifiés */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
        <div className="p-6 sm:p-7 rounded-2xl border border-[var(--border)] bg-[var(--card)] flex flex-col justify-between">
          <div>
            <div className="w-10 h-10 rounded-xl bg-[#e10600]/10 text-[#e10600] flex items-center justify-center mb-4">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-bold text-[#e10600] tracking-wider uppercase block mb-1">Engagement 01</span>
            <h3 className="font-heading font-medium text-lg mb-2">Garantie Constructeur</h3>
            <p className="text-xs sm:text-sm text-[#6b6b72] font-light leading-relaxed">
              Couverture de 3 à 8 ans selon la marque (jusqu’à 160 000 km pour les batteries). Carnet d’entretien officiel remis à la livraison.
            </p>
          </div>
        </div>

        <div className="p-6 sm:p-7 rounded-2xl border border-[var(--border)] bg-[var(--card)] flex flex-col justify-between">
          <div>
            <div className="w-10 h-10 rounded-xl bg-[#e10600]/10 text-[#e10600] flex items-center justify-center mb-4">
              <Wrench className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-bold text-[#e10600] tracking-wider uppercase block mb-1">Engagement 02</span>
            <h3 className="font-heading font-medium text-lg mb-2">Ateliers & Pièces d'Origine</h3>
            <p className="text-xs sm:text-sm text-[#6b6b72] font-light leading-relaxed">
              Partenariat avec des centres techniques certifiés à Abidjan équipés des valises électroniques et pièces 100% d’origine OEM.
            </p>
          </div>
        </div>

        <div className="p-6 sm:p-7 rounded-2xl border border-[var(--border)] bg-[var(--card)] flex flex-col justify-between">
          <div>
            <div className="w-10 h-10 rounded-xl bg-[#e10600]/10 text-[#e10600] flex items-center justify-center mb-4">
              <FileCheck2 className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-bold text-[#e10600] tracking-wider uppercase block mb-1">Engagement 03</span>
            <h3 className="font-heading font-medium text-lg mb-2">Immatriculation Clé en Main</h3>
            <p className="text-xs sm:text-sm text-[#6b6b72] font-light leading-relaxed">
              Dédouanement complet, carte grise ivoirienne et pose des plaques d’immatriculation avant la remise des clés en showroom.
            </p>
          </div>
        </div>
      </div>

      {/* Section FAQ simplifiée */}
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-8">
          <span className="eyebrow block mb-1">Questions Fréquentes</span>
          <h2 className="font-heading font-light text-2xl sm:text-3xl">
            Tout savoir sur nos garanties
          </h2>
        </div>

        {/* Filtres de catégories sobres */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-8">
          {[
            { id: 'tous', label: 'Toutes' },
            { id: 'garantie', label: 'Garanties 0 km' },
            { id: 'entretien', label: 'Entretien & Ateliers' },
            { id: 'demarches', label: 'Plaques & Démarches' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveCategory(tab.id as any)}
              className={`pill-btn px-4 py-1.5 text-xs font-medium transition-colors ${
                activeCategory === tab.id
                  ? 'bg-[#0b0b0c] text-white dark:bg-white dark:text-zinc-950'
                  : 'bg-[var(--surface)] text-[#6b6b72] hover:text-[var(--fg)] border border-[var(--border)]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Accordéon épuré */}
        <div className="space-y-2">
          {filteredFaq.map((item) => {
            const isExpanded = expandedId === item.id;
            return (
              <div
                key={item.id}
                className="rounded-xl border border-[var(--border)] bg-[var(--card)] overflow-hidden"
              >
                <button
                  type="button"
                  onClick={() => toggleAccordion(item.id)}
                  aria-expanded={isExpanded}
                  className="w-full text-left p-4 sm:p-5 flex items-center justify-between gap-4 font-heading text-sm sm:text-base font-normal text-[var(--fg)]"
                >
                  <span className="leading-snug">{item.question}</span>
                  <ChevronDown
                    className={`w-4 h-4 text-[#6b6b72] shrink-0 transition-transform duration-200 ${
                      isExpanded ? 'rotate-180 text-[#e10600]' : ''
                    }`}
                  />
                </button>

                {isExpanded && (
                  <div className="px-4 sm:px-5 pb-5 pt-0 text-xs sm:text-sm text-[#6b6b72] font-light leading-relaxed border-t border-[var(--border)] pt-3">
                    {item.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Bandeau d'assistance showroom */}
        <div className="mt-12 p-6 rounded-2xl bg-[var(--surface)] border border-[var(--border)] flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="space-y-1">
            <h4 className="font-heading font-medium text-sm sm:text-base">Besoin d'un renseignement immédiat ?</h4>
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-4 text-xs text-[#6b6b72] font-light">
              <span className="inline-flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#e10600]" />
                Cocody Riviera Bonoumin
              </span>
              <span className="inline-flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-[#e10600]" />
                Lun - Sam : 08h00 - 18h30
              </span>
            </div>
          </div>

          <a
            href={waUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="pill-btn shrink-0 px-5 py-2.5 bg-[#e10600] text-white text-xs font-semibold inline-flex items-center gap-2"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>Contacter un technicien</span>
          </a>
        </div>
      </div>
    </div>
  );
};
