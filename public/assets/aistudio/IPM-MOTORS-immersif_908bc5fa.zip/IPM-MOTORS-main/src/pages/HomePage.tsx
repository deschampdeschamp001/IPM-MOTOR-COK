import React, { useState } from 'react';
import { Hero } from '../components/Hero';
import { VehicleShowcase } from '../components/home/VehicleShowcase';
import { ScrollReveal, CountUp } from '../components/home/ScrollReveal';
import { BodyTypeSilhouettes } from '../components/ui/BodyTypeSilhouettes';
import { VehicleCard } from '../components/VehicleCard';
import { useData } from '../context/DataContext';
import { Link } from '../router/Router';
import { DEALERSHIP_CONFIG, buildWhatsAppUrl } from '../config/dealership';
import {
  ArrowRight,
  ShieldCheck,
  Sparkles,
  Phone,
  MessageCircle,
  Clock,
  Award,
  CheckCircle2,
  Sliders,
  Store,
  Compass,
  FileCheck2,
  Wrench,
  Mail,
  Loader2
} from 'lucide-react';
import { subscribeNewsletter } from '../lib/newsletterStorage';

export const HomePage: React.FC = () => {
  const { vehicles, brands, newsArticles } = useData();

  // Newsletter state
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterStatus, setNewsletterStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [newsletterMsg, setNewsletterMsg] = useState('');

  const featuredVehicles = vehicles.filter(v => v.is_available).slice(0, 6);
  const offerVehicles = vehicles.filter(v => v.is_offer).slice(0, 3);
  const latestNews = newsArticles.filter(n => n.is_published).slice(0, 3);
  const activeBrands = brands.filter(b => b.is_active).slice(0, 12);

  const handleNewsletterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail) return;
    setNewsletterStatus('loading');
    const res = await subscribeNewsletter(newsletterEmail);
    if (res.success) {
      setNewsletterStatus('success');
      setNewsletterMsg(res.message);
      setNewsletterEmail('');
    } else {
      setNewsletterStatus('error');
      setNewsletterMsg(res.message);
    }
  };

  return (
    <div className="flex flex-col min-h-screen">
      {/* 1. HERO SLIDER (24H Chrono Shutter & Live Clock) */}
      <Hero />

      {/* 2. NOS MODÈLES & SILHOUETTE SELECTOR */}
      <section className="py-20 sm:py-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <span className="eyebrow block mb-2">Exclusivité 0 KM</span>
            <h2 className="font-heading font-light text-3xl sm:text-4xl lg:text-5xl tracking-tight">
              Nos Modèles <span className="font-semibold">en Stock</span>
            </h2>
            <p className="text-sm sm:text-base text-[#6b6b72] mt-2 max-w-xl font-light">
              Une sélection d’exception de véhicules 100% neufs disponibles immédiatement dans notre showroom à Cocody Riviera Bonoumin.
            </p>
          </div>

          <Link
            to="/modeles"
            className="inline-flex items-center gap-2 text-xs font-bold tracking-wider uppercase text-[#e10600] hover:text-[#c30500] group"
          >
            <span>Voir tout le catalogue ({vehicles.length})</span>
            <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        {/* Hairline Minimalist Body Type Silhouettes */}
        <div>
          <div className="text-xs uppercase tracking-wider text-[#6b6b72] font-semibold mb-4">
            Choisir par type de véhicule
          </div>
          <BodyTypeSilhouettes />
        </div>

        {/* Bottom Catalog Link CTA */}
        <div className="mt-12 text-center">
          <Link
            to="/modeles"
            className="pill-btn inline-flex items-center gap-2 px-8 py-3.5 bg-[var(--surface)] hover:bg-[#e10600] text-[var(--fg)] hover:text-white border border-[var(--border)] hover:border-[#e10600] text-xs font-semibold uppercase tracking-wider transition-all shadow-sm"
          >
            <span>Explorer tous les modèles disponibles ({vehicles.length})</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>

      {/* 2b. VITRINE HORIZONTALE (scroll épinglé : les véhicules défilent de droite à gauche) */}
      <VehicleShowcase vehicles={featuredVehicles} />

      {/* 3. NOS OFFRES (Carousel fluide qui défile automatiquement, blocs carrés, sans survol ni bordure qui s'allume) */}
      <section className="py-20 sm:py-24 bg-[var(--surface)] border-y border-[var(--border)] overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-10">
          <div className="text-center max-w-2xl mx-auto">
            <span className="eyebrow block mb-2">Conditions Privilège</span>
            <h2 className="font-heading font-light text-3xl sm:text-4xl lg:text-5xl tracking-tight">
              Nos Offres <span className="font-semibold">du Moment</span>
            </h2>
            <p className="text-sm sm:text-base text-[#6b6b72] mt-3 font-light">
              Profitez d’avantages exclusifs : immatriculation offerte, borne de recharge ou forfaits d’entretien garantis.
            </p>
          </div>
        </div>

        {/* Carousel continu fluide auto-défilant */}
        <div className="relative w-full overflow-hidden py-4">
          <div className="animate-marquee-fluid flex gap-6 px-4">
            {[...offerVehicles, ...offerVehicles, ...offerVehicles].map((vehicle, idx) => {
              const mainImg = vehicle.images?.[0] || '/assets/cars/hero_dealership_car_1793116464643.jpg';
              const waMessage = `Bonjour IPM Motors, je souhaite des informations sur l'offre spéciale concernant le véhicule ${vehicle.brand} ${vehicle.model} 0 km.`;
              const waUrl = buildWhatsAppUrl(waMessage);

              return (
                <div
                  key={`${vehicle.id}-${idx}`}
                  className="w-[300px] sm:w-[340px] aspect-square rounded-2xl border border-[var(--border)] bg-[var(--card)] p-5 flex flex-col justify-between shrink-0 select-none"
                >
                  {/* Top info */}
                  <div className="flex items-center justify-between gap-2">
                    <span className="inline-block px-2.5 py-0.5 rounded-full bg-[#e10600]/10 text-[#e10600] text-[10px] font-bold uppercase tracking-wider">
                      {vehicle.offer_badge || 'Offre 0 KM'}
                    </span>
                    <span className="text-[10px] font-bold text-[#6b6b72] tracking-wider uppercase">
                      {vehicle.brand}
                    </span>
                  </div>

                  {/* Center image & model title */}
                  <div className="flex-1 flex flex-col items-center justify-center my-2 overflow-hidden">
                    <div className="w-full h-28 sm:h-32 rounded-xl overflow-hidden bg-zinc-100 dark:bg-zinc-900 flex items-center justify-center mb-2">
                      <img
                        src={mainImg}
                        alt={`${vehicle.brand} ${vehicle.model}`}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          e.currentTarget.src = '/assets/aistudio/814493891_122239370216113743_2889832111464126919_n_8772dda4.jpg';
                        }}
                      />
                    </div>
                    <h3 className="font-heading font-medium text-sm sm:text-base text-center leading-snug line-clamp-1 w-full">
                      {vehicle.model}
                    </h3>
                    <p className="text-[11px] text-[#6b6b72] font-light text-center line-clamp-1 mt-0.5">
                      {vehicle.offer_highlights?.[0] || '100% Neuf 0 km · Prêt pour livraison immédiate'}
                    </p>
                  </div>

                  {/* Actions (Boutons sans survol ni bordure qui s'allume) */}
                  <div className="pt-2 border-t border-[var(--border)] flex flex-col gap-2">
                    <a
                      href={waUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="pill-btn w-full py-2.5 bg-[#e10600] text-white text-xs font-semibold flex items-center justify-center gap-2"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>Profiter de l'offre sur WhatsApp</span>
                    </a>

                    <Link
                      to={`/vehicule/${vehicle.id}`}
                      className="text-center text-[11px] text-[#6b6b72] hover:underline py-0.5"
                    >
                      Voir la fiche technique complète
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Banner: Pas de véhicule adapté ? */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
          <div className="rounded-3xl p-8 sm:p-10 bg-gradient-to-r from-zinc-900 to-black text-white flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl border border-zinc-800">
            <div className="max-w-xl text-center md:text-left">
              <span className="text-[#e10600] text-xs font-bold uppercase tracking-widest block mb-1">
                Commande sur-mesure
              </span>
              <h3 className="font-heading font-light text-2xl sm:text-3xl text-white">
                Vous recherchez une configuration spécifique ?
              </h3>
              <p className="text-sm text-zinc-400 mt-2 font-light">
                Nous commandons et importons votre véhicule 0 km d’usine selon vos critères exacts avec formalités complètes à Abidjan.
              </p>
            </div>

            <Link
              to="/contact"
              className="pill-btn shrink-0 px-8 py-3.5 bg-white hover:bg-zinc-100 text-zinc-950 text-xs font-bold uppercase tracking-wider transition-all"
            >
              Faire une demande sur-mesure
            </Link>
          </div>
        </div>
      </section>

      {/* 4. NOS MARQUES (Clickable logo tiles) */}
      <section className="py-20 sm:py-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="eyebrow block mb-2">Toutes marques, un seul showroom</span>
          <h2 className="font-heading font-light text-3xl sm:text-4xl lg:text-5xl tracking-tight">
            Nos <span className="font-semibold">Marques</span>
          </h2>
          <p className="text-sm sm:text-base text-[#6b6b72] mt-3 font-light">
            Cliquez sur un constructeur pour découvrir les modèles 0 km disponibles en concession.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 sm:gap-4">
          {activeBrands.map((brand) => {
            const brandSlug = brand.slug || brand.name.toLowerCase().replace(/\s+/g, '-');
            return (
              <Link
                key={brand.id}
                to={`/marques/${brandSlug}`}
                aria-label={`Découvrir les véhicules ${brand.name}`}
                className="group relative p-5 rounded-2xl bg-[var(--card)] dark:bg-[#141417] transition-all duration-300 flex flex-col items-center justify-center min-h-[120px] shadow-sm hover:shadow-md border-0 outline-none"
              >
                <div className="h-10 w-full flex items-center justify-center mb-2 filter grayscale group-hover:grayscale-0 transition-all duration-300">
                  {brand.logo_url ? (
                    <img
                      src={brand.logo_url}
                      alt={`Logo ${brand.name}`}
                      loading="lazy"
                      className="max-h-10 max-w-[90px] object-contain"
                      onError={(e) => {
                        e.currentTarget.style.display = 'none';
                      }}
                    />
                  ) : null}
                  {!brand.logo_url && (
                    <span className="font-heading font-bold text-sm tracking-wide text-zinc-700 dark:text-zinc-300">
                      {brand.name}
                    </span>
                  )}
                </div>
                <span className="text-xs font-medium text-[#6b6b72] group-hover:text-[#e10600] transition-colors">
                  {brand.name}
                </span>
              </Link>
            );
          })}
        </div>

        <div className="mt-8 text-center">
          <Link
            to="/marques"
            className="inline-flex items-center gap-2 text-xs font-semibold text-[#6b6b72] hover:text-[#e10600] transition-colors"
          >
            <span>Voir la liste détaillée des marques et origines</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </section>

      {/* 5. L'EXCELLENCE AUTOMOBILE (Design épuré et minimaliste avec fond jaune + 20% gris) */}
      <section className="py-20 sm:py-24 bg-[#f4f1dc] dark:bg-[#23221b] border-y border-[#e2dec0] dark:border-zinc-800 px-4 sm:px-6 lg:px-8 transition-colors">
        <div className="max-w-4xl mx-auto text-center">
          <span className="text-[#967d14] dark:text-[#dfc256] text-xs font-bold uppercase tracking-widest block mb-3">
            L’excellence automobile à votre portée !
          </span>
          <h2 className="font-heading font-light text-3xl sm:text-4xl lg:text-5xl tracking-tight text-zinc-900 dark:text-zinc-100 leading-tight mb-5">
            Bienvenue chez <span className="font-semibold text-[#e10600]">IPM MOTORS</span>
          </h2>
          <ScrollReveal
            text="Votre partenaire de confiance pour l’achat de véhicules neufs en Côte d’Ivoire. Leader ambitieux et acteur influent du secteur automobile, nous mettons notre expertise et notre passion au service de vos exigences pour vous proposer des véhicules qui allient prestige, performance, confort et élégance."
            className="text-xl sm:text-3xl text-zinc-800 dark:text-zinc-200 leading-snug font-light max-w-3xl mx-auto mb-8 text-balance"
          />

          <blockquote className="text-sm sm:text-base text-zinc-800 dark:text-zinc-200 font-medium italic max-w-xl mx-auto mb-8 py-3 border-y border-[#ded8bc] dark:border-zinc-700">
            « Avec IPM MOTORS, donnez une nouvelle dimension à vos déplacements ! »
          </blockquote>

          {/* 3 Simples repères */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-2xl mx-auto mb-8 text-center">
            <div className="p-4 rounded-xl bg-white/70 dark:bg-zinc-900/60 border border-[#ded9be] dark:border-zinc-800">
              <span className="font-heading font-semibold text-lg text-zinc-900 dark:text-white block"><CountUp to={100} suffix="%" /> Neufs</span>
              <span className="text-xs text-zinc-600 dark:text-zinc-400">0 km garantis constructeur</span>
            </div>
            <div className="p-4 rounded-xl bg-white/70 dark:bg-zinc-900/60 border border-[#ded9be] dark:border-zinc-800">
              <span className="font-heading font-semibold text-lg text-zinc-900 dark:text-white block"><CountUp to={13} suffix="+" /> Marques</span>
              <span className="text-xs text-zinc-600 dark:text-zinc-400">Grandes marques mondiales</span>
            </div>
            <div className="p-4 rounded-xl bg-white/70 dark:bg-zinc-900/60 border border-[#ded9be] dark:border-zinc-800">
              <span className="font-heading font-semibold text-lg text-zinc-900 dark:text-white block">Showroom Direct</span>
              <span className="text-xs text-zinc-600 dark:text-zinc-400">Cocody Riviera Bonoumin</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link
              to="/modeles"
              className="pill-btn inline-flex items-center gap-2 px-7 py-3 bg-[#e10600] hover:bg-[#c30500] text-white text-xs font-semibold shadow-sm"
            >
              <span>Explorer les véhicules neufs</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              to="/contact"
              className="pill-btn inline-flex items-center gap-2 px-7 py-3 bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 border border-[#ded9be] dark:border-zinc-700 text-xs font-semibold"
            >
              <span>Contacter un conseiller</span>
            </Link>
          </div>
        </div>
      </section>

      {/* 6. SERVICES (4 Clean luxury cards) */}
      <section className="py-20 sm:py-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="eyebrow block mb-2">Accompagnement Sur-Mesure</span>
          <h2 className="font-heading font-light text-3xl sm:text-4xl lg:text-5xl tracking-tight">
            Nos <span className="font-semibold">Services</span>
          </h2>
          <p className="text-sm sm:text-base text-[#6b6b72] mt-3 font-light">
            Une expérience haut de gamme pensée pour chaque étape de votre acquisition automobile.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Link
            to="/modeles"
            className="p-6 rounded-3xl border border-[var(--border)] bg-[var(--card)] hover:border-[#e10600] transition-all duration-300 group flex flex-col justify-between"
          >
            <div>
              <div className="w-12 h-12 rounded-2xl bg-[#e10600]/10 text-[#e10600] flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Store className="w-6 h-6" />
              </div>
              <h3 className="font-heading font-medium text-lg mb-2 group-hover:text-[#e10600] transition-colors">
                Véhicules en Stock
              </h3>
              <p className="text-xs text-[#6b6b72] font-light leading-relaxed">
                Parc de véhicules 100% neufs 0 km prêts pour enlèvement immédiat sans attente de fret.
              </p>
            </div>
            <div className="mt-6 flex items-center gap-1.5 text-xs font-semibold text-[#e10600]">
              <span>Consulter le stock</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
          </Link>

          <Link
            to="/contact"
            className="p-6 rounded-3xl border border-[var(--border)] bg-[var(--card)] hover:border-[#e10600] transition-all duration-300 group flex flex-col justify-between"
          >
            <div>
              <div className="w-12 h-12 rounded-2xl bg-[#e10600]/10 text-[#e10600] flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Sliders className="w-6 h-6" />
              </div>
              <h3 className="font-heading font-medium text-lg mb-2 group-hover:text-[#e10600] transition-colors">
                Commande Sur-Mesure
              </h3>
              <p className="text-xs text-[#6b6b72] font-light leading-relaxed">
                Configuration personnalisée d’usine : coloris exclusifs, selleries sur-mesure et options rares.
              </p>
            </div>
            <div className="mt-6 flex items-center gap-1.5 text-xs font-semibold text-[#e10600]">
              <span>Configurer un véhicule</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
          </Link>

          <Link
            to="/a-propos"
            className="p-6 rounded-3xl border border-[var(--border)] bg-[var(--card)] hover:border-[#e10600] transition-all duration-300 group flex flex-col justify-between"
          >
            <div>
              <div className="w-12 h-12 rounded-2xl bg-[#e10600]/10 text-[#e10600] flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Compass className="w-6 h-6" />
              </div>
              <h3 className="font-heading font-medium text-lg mb-2 group-hover:text-[#e10600] transition-colors">
                Showroom Riviera
              </h3>
              <p className="text-xs text-[#6b6b72] font-light leading-relaxed">
                Espace d’exposition climatisé à Bonoumin pour admirer et essayer votre futur véhicule en toute sérénité.
              </p>
            </div>
            <div className="mt-6 flex items-center gap-1.5 text-xs font-semibold text-[#e10600]">
              <span>Visiter le showroom</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
          </Link>

          <Link
            to="/contact"
            className="p-6 rounded-3xl border border-[var(--border)] bg-[var(--card)] hover:border-[#e10600] transition-all duration-300 group flex flex-col justify-between"
          >
            <div>
              <div className="w-12 h-12 rounded-2xl bg-[#e10600]/10 text-[#e10600] flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Sparkles className="w-6 h-6" />
              </div>
              <h3 className="font-heading font-medium text-lg mb-2 group-hover:text-[#e10600] transition-colors">
                VIP & Financement
              </h3>
              <p className="text-xs text-[#6b6b72] font-light leading-relaxed">
                Solutions bancaires et leasing avec nos partenaires ivoiriens, et livraison VIP à domicile.
              </p>
            </div>
            <div className="mt-6 flex items-center gap-1.5 text-xs font-semibold text-[#e10600]">
              <span>Contacter un conseiller VIP</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
          </Link>
        </div>
      </section>

      {/* 7. SERVICE APRÈS-VENTE (Design comme image 1 : grandes icônes, disposition 3 cartes aérées avec puces) */}
      <section className="py-20 sm:py-28 bg-[var(--surface)] border-y border-[var(--border)] px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          {/* En-tête centré comme dans l'image 1 */}
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-[#a17e0e] dark:text-[#dfc256] text-xs font-bold uppercase tracking-widest block mb-3">
              Tranquillité d’Esprit
            </span>
            <h2 className="font-heading font-bold text-3xl sm:text-4xl lg:text-5xl tracking-tight text-zinc-950 dark:text-white leading-tight mb-4">
              Service Après-Vente
            </h2>
            <p className="text-sm sm:text-base text-zinc-600 dark:text-zinc-400 font-light leading-relaxed max-w-2xl mx-auto">
              Un accompagnement durable pour rouler en toute confiance partout en Côte d’Ivoire.
            </p>
          </div>

          {/* 3 Cartes avec grandes icônes disposées comme sur l'image 1 */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Carte 1 : Garantie Constructeur */}
            <div className="p-8 sm:p-10 rounded-3xl bg-white dark:bg-[#141417] shadow-xl shadow-zinc-200/50 dark:shadow-none border border-zinc-100 dark:border-zinc-800 flex flex-col items-center text-center justify-between">
              <div className="flex flex-col items-center w-full">
                {/* Grande icône style image 1 (carte bancaire & bouclier) */}
                <div className="h-20 w-20 flex items-center justify-center mb-6 text-[#1e293b] dark:text-white">
                  <svg className="w-18 h-18" viewBox="0 0 64 64" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="6" y="16" width="38" height="26" rx="4" />
                    <line x1="6" y1="23" x2="44" y2="23" />
                    <rect x="11" y="29" width="8" height="5" rx="1" />
                    <g transform="translate(18, 12)">
                      <path d="M26 14v7c0 6-5 10-9 12-4-2-9-6-9-12v-7l9-4 9 4z" fill="var(--card)" />
                      <path d="M22 20l2.5 2.5 5.5-5.5" strokeWidth="2.4" />
                    </g>
                  </svg>
                </div>

                <h3 className="font-heading font-bold text-xl sm:text-2xl text-zinc-900 dark:text-white mb-3">
                  Garantie Constructeur
                </h3>
                <p className="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400 font-normal leading-relaxed mb-6">
                  Couverture officielle de 3 à 8 ans sur l'ensemble de nos véhicules neufs 0 km pour une sécurité totale dès le premier jour.
                </p>
              </div>

              {/* Puces comme sur l'image 1 */}
              <ul className="text-left space-y-2 text-xs text-zinc-600 dark:text-zinc-400 w-full pt-6 border-t border-zinc-100 dark:border-zinc-800/80">
                <li className="flex items-center gap-2.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-zinc-800 dark:bg-zinc-200 shrink-0" />
                  <span>Garantie internationale constructeur</span>
                </li>
                <li className="flex items-center gap-2.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-zinc-800 dark:bg-zinc-200 shrink-0" />
                  <span>Jusqu'à 160 000 km pour batteries</span>
                </li>
                <li className="flex items-center gap-2.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-zinc-800 dark:bg-zinc-200 shrink-0" />
                  <span>Moteur, boîte et électronique</span>
                </li>
                <li className="flex items-center gap-2.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-zinc-800 dark:bg-zinc-200 shrink-0" />
                  <span>Carnet de garantie officiel tamponné</span>
                </li>
              </ul>
            </div>

            {/* Carte 2 : Sécurité & Ateliers certifiés (identique au centre image 1) */}
            <div className="p-8 sm:p-10 rounded-3xl bg-white dark:bg-[#141417] shadow-xl shadow-zinc-200/50 dark:shadow-none border border-zinc-100 dark:border-zinc-800 flex flex-col items-center text-center justify-between">
              <div className="flex flex-col items-center w-full">
                {/* Grande icône bouclier avec coche comme au centre de l'image 1 */}
                <div className="h-20 w-20 flex items-center justify-center mb-6 text-[#1e293b] dark:text-white">
                  <svg className="w-18 h-18" viewBox="0 0 64 64" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M32 7l19 8v16c0 14-10.5 24-19 27C23.5 55 13 45 13 31V15L32 7z" />
                    <path d="M23 31l7 7 13-13" strokeWidth="2.5" />
                  </svg>
                </div>

                <h3 className="font-heading font-bold text-xl sm:text-2xl text-zinc-900 dark:text-white mb-3">
                  Entretien Certifié & Pièces OEM
                </h3>
                <p className="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400 font-normal leading-relaxed mb-6">
                  Réseau de centres techniques agréés à Abidjan respectant rigoureusement les normes constructeurs.
                </p>
              </div>

              {/* Puces comme sur l'image 1 */}
              <ul className="text-left space-y-2 text-xs text-zinc-600 dark:text-zinc-400 w-full pt-6 border-t border-zinc-100 dark:border-zinc-800/80">
                <li className="flex items-center gap-2.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-zinc-800 dark:bg-zinc-200 shrink-0" />
                  <span>Pièces 100% d'origine constructeur</span>
                </li>
                <li className="flex items-center gap-2.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-zinc-800 dark:bg-zinc-200 shrink-0" />
                  <span>Valises diagnostiques officielles</span>
                </li>
                <li className="flex items-center gap-2.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-zinc-800 dark:bg-zinc-200 shrink-0" />
                  <span>Techniciens formés multimarques</span>
                </li>
                <li className="flex items-center gap-2.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-zinc-800 dark:bg-zinc-200 shrink-0" />
                  <span>Traçabilité complète des entretiens</span>
                </li>
              </ul>
            </div>

            {/* Carte 3 : Pilotage & Démarches Clé en Main (icône réseau/main image 1) */}
            <div className="p-8 sm:p-10 rounded-3xl bg-white dark:bg-[#141417] shadow-xl shadow-zinc-200/50 dark:shadow-none border border-zinc-100 dark:border-zinc-800 flex flex-col items-center text-center justify-between">
              <div className="flex flex-col items-center w-full">
                {/* Grande icône utilisateurs / main d'accompagnement comme sur l'image 1 */}
                <div className="h-20 w-20 flex items-center justify-center mb-6 text-[#1e293b] dark:text-white">
                  <svg className="w-18 h-18" viewBox="0 0 64 64" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="22" cy="18" r="5" />
                    <circle cx="42" cy="18" r="5" />
                    <path d="M15 30c0-3.5 3.5-5.5 7-5.5" />
                    <path d="M49 30c0-3.5-3.5-5.5-7-5.5" />
                    <path d="M29 13a11 11 0 0 1 6 0" />
                    <path d="M35 23a11 11 0 0 1-6 0" />
                    {/* Main ouverte en support */}
                    <path d="M11 48h18l11-5c3-1.5 6.5-0.5 7.5 2v0c0.5 2-0.5 4-2.5 5l-12 5H11v-7z" />
                    <path d="M21 48v-4a3.5 3.5 0 0 1 3.5-3.5h4.5" />
                  </svg>
                </div>

                <h3 className="font-heading font-bold text-xl sm:text-2xl text-zinc-900 dark:text-white mb-3">
                  Démarches & Prise en Charge
                </h3>
                <p className="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400 font-normal leading-relaxed mb-6">
                  Toutes les formalités administratives ivoiriennes sont prises en charge pour une mise à la route immédiate.
                </p>
              </div>

              {/* Puces comme sur l'image 1 */}
              <ul className="text-left space-y-2 text-xs text-zinc-600 dark:text-zinc-400 w-full pt-6 border-t border-zinc-100 dark:border-zinc-800/80">
                <li className="flex items-center gap-2.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-zinc-800 dark:bg-zinc-200 shrink-0" />
                  <span>Dédouanement officiel sécurisé</span>
                </li>
                <li className="flex items-center gap-2.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-zinc-800 dark:bg-zinc-200 shrink-0" />
                  <span>Carte grise ivoirienne établie</span>
                </li>
                <li className="flex items-center gap-2.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-zinc-800 dark:bg-zinc-200 shrink-0" />
                  <span>Pose de plaques homologuées</span>
                </li>
                <li className="flex items-center gap-2.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-zinc-800 dark:bg-zinc-200 shrink-0" />
                  <span>Conseiller dédié disponible 6j/7</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Lien vers la page dédiée */}
          <div className="mt-14 text-center">
            <Link
              to="/apres-vente"
              className="pill-btn inline-flex items-center gap-2 px-8 py-3.5 bg-white dark:bg-[#141417] hover:bg-[#e10600] text-zinc-900 dark:text-white hover:text-white border border-zinc-200 dark:border-zinc-800 hover:border-[#e10600] text-xs font-semibold uppercase tracking-wider transition-all shadow-sm"
            >
              <span>En savoir plus sur nos garanties & SAV</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* 8. ACTUALITÉS (3 Latest Articles) */}
      <section className="py-20 sm:py-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <span className="eyebrow block mb-2">Magazine Automobile</span>
            <h2 className="font-heading font-light text-3xl sm:text-4xl lg:text-5xl tracking-tight">
              Dernières <span className="font-semibold">Actualités</span>
            </h2>
            <p className="text-sm sm:text-base text-[#6b6b72] mt-2 max-w-xl font-light">
              Nouveaux arrivages 0 km, décryptages technologiques et temps forts de notre concession.
            </p>
          </div>

          <Link
            to="/actualites"
            className="inline-flex items-center gap-2 text-xs font-bold tracking-wider uppercase text-[#e10600] hover:text-[#c30500] group"
          >
            <span>Toutes les actualités</span>
            <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {latestNews.map((article) => {
            const articleSlug = article.slug || article.id;
            return (
              <article
                key={article.id}
                className="group rounded-3xl border border-[var(--border)] bg-[var(--card)] overflow-hidden flex flex-col justify-between hover:border-[#e10600] transition-all duration-300 hover:shadow-lg"
              >
                <div>
                  <Link to={`/actualites/${articleSlug}`} className="block relative aspect-[16/10] overflow-hidden bg-zinc-950">
                    <img
                      src={article.cover_image}
                      alt={article.title}
                      loading="lazy"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      onError={(e) => {
                        e.currentTarget.src = '/assets/aistudio/814493891_122239370216113743_2889832111464126919_n_8772dda4.jpg';
                      }}
                    />
                    <div className="absolute top-3 left-3">
                      <span className="px-3 py-1 rounded-full text-[10px] font-bold tracking-wider uppercase bg-black/75 backdrop-blur-md text-white border border-white/20">
                        {article.category}
                      </span>
                    </div>
                  </Link>

                  <div className="p-6">
                    <div className="flex items-center gap-3 text-xs text-[#6b6b72] mb-2 font-mono">
                      <span>{article.published_at}</span>
                      <span>•</span>
                      <span>{article.read_time || '3 min'}</span>
                    </div>

                    <Link to={`/actualites/${articleSlug}`}>
                      <h3 className="font-heading font-medium text-lg leading-snug group-hover:text-[#e10600] transition-colors line-clamp-2">
                        {article.title}
                      </h3>
                    </Link>

                    <p className="text-xs text-[#6b6b72] mt-3 font-light leading-relaxed line-clamp-2">
                      {article.excerpt}
                    </p>
                  </div>
                </div>

                <div className="px-6 pb-6 pt-2 border-t border-[var(--border)]">
                  <Link
                    to={`/actualites/${articleSlug}`}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#e10600] group-hover:underline"
                  >
                    <span>Lire l'article</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Link>
                </div>
              </article>
            );
          })}
        </div>
      </section>

      {/* 9. NEWSLETTER ("Restez informé.") */}
      <section className="py-20 bg-[#0b0b0c] text-white border-t border-zinc-800 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <span className="text-[#e10600] text-xs font-bold uppercase tracking-widest block mb-2">
            Lettre Privilège
          </span>
          <h2 className="font-heading font-extralight text-3xl sm:text-5xl text-white tracking-tight mb-4">
            Restez <span className="font-semibold">informé.</span>
          </h2>
          <p className="text-sm sm:text-base text-zinc-400 font-light max-w-xl mx-auto mb-8">
            Soyez les premiers avertis de l’arrivée de nouvelles séries limitées 0 km, des arrivages de conteneurs et des conditions exceptionnelles à Abidjan.
          </p>

          <form onSubmit={handleNewsletterSubmit} className="max-w-md mx-auto flex flex-col sm:flex-row gap-3">
            <input
              type="email"
              value={newsletterEmail}
              onChange={(e) => setNewsletterEmail(e.target.value)}
              placeholder="Votre adresse e-mail professionnelle"
              required
              className="flex-1 px-5 py-3.5 rounded-full bg-zinc-900 border border-zinc-700 text-white placeholder-zinc-500 text-xs sm:text-sm focus:outline-none focus:border-[#e10600]"
            />
            <button
              type="submit"
              disabled={newsletterStatus === 'loading'}
              className="pill-btn px-7 py-3.5 bg-[#e10600] hover:bg-[#c30500] text-white text-xs font-semibold shrink-0 flex items-center justify-center gap-2 shadow-lg shadow-[#e10600]/25 disabled:opacity-50"
            >
              {newsletterStatus === 'loading' ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Envoi...</span>
                </>
              ) : (
                <>
                  <span>S'inscrire</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          </form>

          {newsletterMsg && (
            <div className={`mt-4 text-xs font-medium ${newsletterStatus === 'error' ? 'text-red-400' : 'text-emerald-400'}`}>
              {newsletterMsg}
            </div>
          )}

          <p className="text-[11px] text-zinc-500 mt-4 font-light">
            Zéro spam. Désabonnement en un clic à tout moment. Vos coordonnées restent strictement confidentielles.
          </p>
        </div>
      </section>
    </div>
  );
};
