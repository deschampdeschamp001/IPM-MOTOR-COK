import React from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';
import { Vehicle } from '../types';
import { Link } from '../router/Router';

interface VehicleCardProps {
  vehicle: Vehicle;
  onSelect?: (vehicle: Vehicle) => void;
}

export const VehicleCard: React.FC<VehicleCardProps> = ({ vehicle }) => {
  const mainImage = vehicle.images?.[0] || '/assets/cars/hero_dealership_car_1793116464643.jpg';

  const displayPrice = vehicle.price
    ? new Intl.NumberFormat('fr-FR').format(vehicle.price) + ' FCFA'
    : vehicle.price_label || 'Sur demande';

  return (
    <article className="group relative rounded-2xl border border-[var(--border)] bg-[var(--card)] dark:bg-[#141417] overflow-hidden flex flex-col transition-shadow duration-300 shadow-sm">
      {/* Photo Container */}
      <Link to={`/vehicule/${vehicle.id}`} className="relative aspect-[16/10] w-full overflow-hidden bg-zinc-950 block">
        <img
          src={mainImage}
          alt={`${vehicle.brand} ${vehicle.model} 0 km`}
          loading="lazy"
          className="w-full h-full object-cover object-center"
          onError={(e) => {
            e.currentTarget.src = '/assets/aistudio/814493891_122239370216113743_2889832111464126919_n_8772dda4.jpg';
          }}
        />

        {/* État du véhicule avec animation responsive au survol */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none transition-all duration-300 ease-out opacity-90 lg:opacity-0 lg:-translate-y-1 lg:group-hover:opacity-100 lg:group-hover:translate-y-0">
          <span className="px-2.5 py-1 rounded-full text-[10px] font-bold tracking-wider uppercase bg-black/80 backdrop-blur-md text-white border border-white/20">
            0 KM • NEUF
          </span>

          {vehicle.is_featured && (
            <span className="px-2.5 py-1 rounded-full text-[10px] font-bold tracking-wider uppercase bg-[#e10600] text-white flex items-center gap-1 shadow-sm">
              <Sparkles className="w-3 h-3" />
              <span>PREMIUM</span>
            </span>
          )}
        </div>
      </Link>

      {/* Vehicle Info : Nom, Année, Marque, Prix en dessous */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between">
        <div>
          {/* 1. Nom du véhicule */}
          <Link to={`/vehicule/${vehicle.id}`} className="block focus:outline-none">
            <h3 className="font-heading font-medium text-base sm:text-lg text-[var(--fg)] leading-snug line-clamp-1">
              {vehicle.model}
            </h3>
          </Link>

          {/* 2. Marque & Année */}
          <div className="flex items-center gap-2 mt-1 text-xs">
            <span className="font-bold tracking-wider text-[#e10600] uppercase text-[11px]">
              {vehicle.brand}
            </span>
            <span className="text-zinc-400 dark:text-zinc-600">•</span>
            <span className="text-[#6b6b72] font-mono text-xs">
              {vehicle.year || '2025'}
            </span>
            <span className="text-zinc-400 dark:text-zinc-600">•</span>
            <span className="text-[#6b6b72] text-xs">
              {vehicle.type}
            </span>
          </div>

          {/* 3. Prix en dessous */}
          <div className="mt-3.5">
            <span className="text-[10px] uppercase tracking-wider text-[#6b6b72] block font-mono">
              Prix Showroom
            </span>
            <span className="font-heading font-bold text-base sm:text-lg text-[var(--fg)]">
              {displayPrice}
            </span>
          </div>
        </div>

        {/* 4. Bouton En Savoir Plus avec flèche qui s'affiche au survol */}
        <Link
          to={`/vehicule/${vehicle.id}`}
          className="mt-4 pt-3 border-t border-[var(--border)] flex items-center justify-between text-xs font-semibold text-[#e10600] transition-all duration-300 lg:opacity-0 lg:translate-y-1 lg:group-hover:opacity-100 lg:group-hover:translate-y-0"
        >
          <span className="uppercase tracking-wider text-[11px]">En savoir plus</span>
          <div className="w-7 h-7 rounded-full bg-[#e10600] text-white flex items-center justify-center transform group-hover:translate-x-1 transition-transform shadow-sm">
            <ArrowRight className="w-3.5 h-3.5" />
          </div>
        </Link>
      </div>
    </article>
  );
};
