import React from 'react';
import { X, MapPin, Clock, Phone, Navigation, MessageSquare, ShieldCheck, Calendar } from 'lucide-react';
import { DEALERSHIP_CONFIG, buildWhatsAppUrl } from '../../config/dealership';

interface ShowroomModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ShowroomModal: React.FC<ShowroomModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const handleBookVisit = () => {
    const waUrl = buildWhatsAppUrl(
      'Bonjour IPM Motors, je souhaite réserver une visite VIP du showroom de Cocody Riviera Bonoumin pour découvrir vos véhicules 0 km en exposition.'
    );
    window.open(waUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#141414] border border-[#2A2A2A] rounded-2xl max-w-2xl w-full max-h-[92vh] overflow-y-auto p-6 sm:p-8 space-y-6 text-white shadow-2xl relative">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-[#2A2A2A] pb-4">
          <div>
            <div className="inline-flex items-center gap-1.5 text-[11px] uppercase tracking-widest font-bold text-[#E10600] mb-1">
              <MapPin className="w-3.5 h-3.5" />
              <span>Showroom Privé Cocody Riviera</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight">
              Le prestige automobile au cœur d'Abidjan
            </h2>
            <p className="text-xs text-[#8A8A8A] mt-1">
              {DEALERSHIP_CONFIG.address}, {DEALERSHIP_CONFIG.neighborhood}, {DEALERSHIP_CONFIG.city}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-[#8A8A8A] hover:text-white rounded-lg hover:bg-[#222222] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Real photo of the IPM Motors Cocody Fleet */}
        <div className="relative rounded-xl overflow-hidden border border-[#2A2A2A] aspect-video">
          <img
            src="/assets/aistudio/814493891_122239370216113743_2889832111464126919_n_8772dda4.jpg"
            alt="Flotte et Showroom IPM Motors Cocody Riviera"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent flex items-end p-4">
            <div className="text-xs text-white/90 font-medium">
              Parc d'exposition officiel IPM Motors — Véhicules neufs 0 km prêts pour livraison
            </div>
          </div>
        </div>

        {/* Information Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="p-4 bg-[#0A0A0A] rounded-xl border border-[#2A2A2A] space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#E10600]">
              <Clock className="w-4 h-4" />
              <span>Horaires d'ouverture</span>
            </div>
            <p className="text-xs text-neutral-300 leading-relaxed">
              <strong>Lundi au Vendredi :</strong> 08h00 – 18h30<br />
              <strong>Samedi :</strong> 09h00 – 17h00<br />
              <strong>Dimanche :</strong> Sur rendez-vous VIP
            </p>
          </div>

          <div className="p-4 bg-[#0A0A0A] rounded-xl border border-[#2A2A2A] space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#E10600]">
              <ShieldCheck className="w-4 h-4" />
              <span>Services exclusifs sur place</span>
            </div>
            <p className="text-xs text-neutral-300 leading-relaxed">
              • Accueil personnalisé & conseiller dédié<br />
              • Salon VIP d'échange & configuration<br />
              • Inspection technique 360° du véhicule 0 km<br />
              • Gestion administrative & plaques express
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-[#2A2A2A]">
          <a
            href={DEALERSHIP_CONFIG.googleMapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto px-4 py-2.5 bg-[#222222] hover:bg-[#333333] text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-2 transition-colors"
          >
            <Navigation className="w-4 h-4 text-[#E10600]" />
            <span>Itinéraire Google Maps</span>
          </a>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <a
              href={`tel:${DEALERSHIP_CONFIG.phone}`}
              className="px-4 py-2.5 bg-[#222222] hover:bg-[#333333] text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-2 transition-colors flex-1 sm:flex-none"
            >
              <Phone className="w-4 h-4 text-[#E10600]" />
              <span>Appeler le showroom</span>
            </a>
            <button
              onClick={handleBookVisit}
              className="px-5 py-2.5 bg-[#E10600] hover:bg-[#B00500] text-white text-xs font-bold uppercase tracking-wider rounded-lg flex items-center justify-center gap-2 transition-colors shadow-lg shadow-[#E10600]/25 cursor-pointer flex-1 sm:flex-none"
            >
              <Calendar className="w-4 h-4" />
              <span>Réserver une visite VIP</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
