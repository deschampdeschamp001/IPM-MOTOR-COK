import React, { useState, useMemo, useEffect } from 'react';
import { useData } from '../context/DataContext';
import { useSearchParams, Link } from '../router/Router';
import { VehicleCard } from '../components/VehicleCard';
import { X, RotateCcw, SlidersHorizontal, Search } from 'lucide-react';
import { POPULAR_BRANDS } from '../config/dealership';

export const ModelsPage: React.FC = () => {
  const { vehicles } = useData();
  const [searchParams, setSearchParams] = useSearchParams();
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);
  const [brandSearch, setBrandSearch] = useState('');
  const [sortBy, setSortBy] = useState<'default' | 'price-asc' | 'price-desc' | 'year-desc'>('default');

  const selectedType = searchParams.get('type') || '';
  const selectedMarque = searchParams.get('marque') || '';
  const selectedEnergie = searchParams.get('energie') || '';

  // Set document title
  useEffect(() => {
    document.title = 'Catalogue Véhicules Neufs 0 km | IPM Motors Abidjan';
  }, []);

  const availableEnergies = ['100% Électrique', 'Hybride', 'Essence', 'Diesel'];

  const setFilter = (key: 'type' | 'marque' | 'energie', value: string) => {
    const current = new URLSearchParams(searchParams);
    if (value) {
      current.set(key, value);
    } else {
      current.delete(key);
    }
    setSearchParams(current);
  };

  const clearAllFilters = () => {
    setSearchParams({});
    setBrandSearch('');
  };

  // Filtered vehicles
  const filteredVehicles = useMemo(() => {
    return vehicles.filter((v) => {
      if (!v.is_available) return false;

      // Type filter
      if (selectedType && selectedType !== 'Tous') {
        if (v.type.toLowerCase() !== selectedType.toLowerCase()) return false;
      }

      // Marque filter
      if (selectedMarque) {
        if (v.brand.toLowerCase() !== selectedMarque.toLowerCase()) return false;
      }

      // Energie filter
      if (selectedEnergie) {
        const vFuel = (v.fuel || '').toLowerCase();
        const sFuel = selectedEnergie.toLowerCase();
        if (!vFuel.includes(sFuel) && !sFuel.includes(vFuel)) return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') {
        return (a.price || 999999999) - (b.price || 999999999);
      }
      if (sortBy === 'price-desc') {
        return (b.price || 0) - (a.price || 0);
      }
      if (sortBy === 'year-desc') {
        return (b.year || 0) - (a.year || 0);
      }
      if (a.is_featured && !b.is_featured) return -1;
      if (!a.is_featured && b.is_featured) return 1;
      return 0;
    });
  }, [vehicles, selectedType, selectedMarque, selectedEnergie, sortBy]);

  const activeFiltersCount = (selectedType ? 1 : 0) + (selectedMarque ? 1 : 0) + (selectedEnergie ? 1 : 0);

  const filteredBrands = useMemo(() => {
    if (!brandSearch.trim()) return POPULAR_BRANDS;
    return POPULAR_BRANDS.filter(b => b.toLowerCase().includes(brandSearch.toLowerCase()));
  }, [brandSearch]);

  return (
    <div className="pt-20 sm:pt-24 lg:pt-20 lg:h-screen lg:overflow-hidden flex flex-col max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8">
      {/* Barre supérieure compacte fixe */}
      <div className="shrink-0 py-4 border-b border-[var(--border)] mb-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div>
            <h1 className="font-heading font-semibold text-lg sm:text-xl text-[var(--fg)] tracking-tight">
              Modèles Neufs <span className="text-[#e10600]">0 km</span>
            </h1>
            <span className="text-xs text-[#6b6b72] font-mono">
              <strong className="text-[var(--fg)] font-semibold">{filteredVehicles.length}</strong> véhicule{filteredVehicles.length > 1 ? 's' : ''} disponible{filteredVehicles.length > 1 ? 's' : ''} en showroom
            </span>
          </div>

          {activeFiltersCount > 0 && (
            <button
              onClick={clearAllFilters}
              className="ml-2 inline-flex items-center gap-1.5 text-xs text-[#e10600] hover:underline font-medium"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Effacer ({activeFiltersCount})</span>
            </button>
          )}
        </div>

        <div className="flex items-center gap-3">
          {/* Mobile Filter Toggle */}
          <button
            onClick={() => setMobileFilterOpen(true)}
            className="lg:hidden pill-btn px-4 py-2 bg-[var(--card)] text-xs font-semibold flex items-center gap-2 border-0 shadow-sm"
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-[#e10600]" />
            <span>Filtres {activeFiltersCount > 0 && `(${activeFiltersCount})`}</span>
          </button>

          {/* Tri minimaliste */}
          <div className="flex items-center gap-2 text-xs">
            <span className="text-[#6b6b72] hidden sm:inline">Trier :</span>
            <select
              value={sortBy}
              onChange={(e: any) => setSortBy(e.target.value)}
              className="px-3 py-1.5 rounded-xl bg-[var(--surface)] text-[var(--fg)] text-xs font-medium focus:outline-none border-0"
            >
              <option value="default">Recommandés</option>
              <option value="price-asc">Prix : croissant</option>
              <option value="price-desc">Prix : décroissant</option>
              <option value="year-desc">Année : plus récente</option>
            </select>
          </div>
        </div>
      </div>

      {/* Conteneur principal split-view moderne avec défilements indépendants */}
      <div className="flex-1 min-h-0 flex flex-col lg:flex-row gap-8 overflow-hidden pb-4">
        {/* Colonne gauche : Panneau Filtres avec DÉFILEMENT INDÉPENDANT & SANS AUCUN CONTOUR */}
        <aside
          className={`
            ${mobileFilterOpen ? 'fixed inset-0 z-50 p-6 bg-[var(--bg)] overflow-y-auto block' : 'hidden lg:block'}
            lg:relative lg:w-72 xl:w-80 lg:shrink-0 lg:h-full lg:overflow-y-auto lg:overscroll-contain custom-scrollbar lg:pr-3 space-y-6
          `}
        >
          {mobileFilterOpen && (
            <div className="flex items-center justify-between pb-4 border-b border-[var(--border)] lg:hidden mb-6">
              <span className="font-heading font-bold text-base">Filtres de recherche</span>
              <button onClick={() => setMobileFilterOpen(false)} className="p-2">
                <X className="w-5 h-5" />
              </button>
            </div>
          )}

          {/* Bloc 1 : Type de Carrosserie (SANS AUCUN CONTOUR) */}
          <div className="p-5 rounded-2xl bg-[var(--card)] dark:bg-[#141417] border-0 shadow-none outline-none">
            <div className="flex items-center justify-between mb-3.5">
              <h3 className="font-heading font-medium text-xs uppercase tracking-wider text-[#6b6b72]">
                Type de carrosserie
              </h3>
              {selectedType && (
                <button
                  onClick={() => setFilter('type', '')}
                  className="text-[10px] text-[#e10600] hover:underline"
                >
                  Tous
                </button>
              )}
            </div>

            <div className="space-y-1.5">
              <button
                onClick={() => setFilter('type', '')}
                className={`w-full text-left px-3 py-2 rounded-xl text-xs font-medium flex items-center justify-between transition-colors ${
                  !selectedType ? 'bg-[#e10600] text-white shadow-sm' : 'text-[var(--fg)] hover:bg-[var(--surface)]'
                }`}
              >
                <span>Tous les types</span>
                <span className="opacity-70 font-mono text-[11px]">({vehicles.length})</span>
              </button>
              {['SUV', 'Berline', 'Pick-up', 'Électrique', 'Citadine'].map((t) => {
                const count = vehicles.filter((v) => v.type.toLowerCase() === t.toLowerCase()).length;
                const isSelected = selectedType.toLowerCase() === t.toLowerCase();
                return (
                  <button
                    key={t}
                    onClick={() => setFilter('type', isSelected ? '' : t)}
                    className={`w-full text-left px-3 py-2 rounded-xl text-xs font-medium flex items-center justify-between transition-colors ${
                      isSelected ? 'bg-[#e10600] text-white shadow-sm' : 'text-[var(--fg)] hover:bg-[var(--surface)]'
                    }`}
                  >
                    <span>{t}</span>
                    <span className="opacity-70 font-mono text-[11px]">({count})</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Bloc 2 : Marques Populaires (SANS AUCUN CONTOUR & SCROLL INTERNE) */}
          <div className="p-5 rounded-2xl bg-[var(--card)] dark:bg-[#141417] border-0 shadow-none outline-none">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-heading font-medium text-xs uppercase tracking-wider text-[#6b6b72]">
                Marques
              </h3>
              {selectedMarque && (
                <button
                  onClick={() => setFilter('marque', '')}
                  className="text-[10px] text-[#e10600] hover:underline"
                >
                  Toutes
                </button>
              )}
            </div>

            {/* Barre de recherche marque rapide */}
            <div className="relative mb-3">
              <input
                type="text"
                placeholder="Filtrer une marque..."
                value={brandSearch}
                onChange={(e) => setBrandSearch(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 rounded-lg bg-[var(--surface)] text-xs text-[var(--fg)] focus:outline-none border-0"
              />
              <Search className="w-3.5 h-3.5 text-[#6b6b72] absolute left-2.5 top-1/2 -translate-y-1/2" />
            </div>

            <div className="space-y-1 max-h-56 overflow-y-auto custom-scrollbar pr-1">
              <button
                onClick={() => setFilter('marque', '')}
                className={`w-full text-left px-3 py-2 rounded-xl text-xs font-medium flex items-center justify-between transition-colors ${
                  !selectedMarque ? 'bg-[#e10600] text-white shadow-sm' : 'text-[var(--fg)] hover:bg-[var(--surface)]'
                }`}
              >
                <span>Toutes les marques</span>
              </button>
              {filteredBrands.map((brandName) => {
                const count = vehicles.filter((v) => v.brand.toLowerCase() === brandName.toLowerCase()).length;
                const isSelected = selectedMarque.toLowerCase() === brandName.toLowerCase();
                return (
                  <button
                    key={brandName}
                    onClick={() => setFilter('marque', isSelected ? '' : brandName)}
                    className={`w-full text-left px-3 py-2 rounded-xl text-xs font-medium flex items-center justify-between transition-colors ${
                      isSelected ? 'bg-[#e10600] text-white shadow-sm' : 'text-[var(--fg)] hover:bg-[var(--surface)]'
                    }`}
                  >
                    <span>{brandName}</span>
                    <span className="opacity-70 font-mono text-[11px]">({count})</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Bloc 3 : Motorisation / Énergie (SANS AUCUN CONTOUR) */}
          <div className="p-5 rounded-2xl bg-[var(--card)] dark:bg-[#141417] border-0 shadow-none outline-none">
            <div className="flex items-center justify-between mb-3.5">
              <h3 className="font-heading font-medium text-xs uppercase tracking-wider text-[#6b6b72]">
                Motorisation / Énergie
              </h3>
              {selectedEnergie && (
                <button
                  onClick={() => setFilter('energie', '')}
                  className="text-[10px] text-[#e10600] hover:underline"
                >
                  Toutes
                </button>
              )}
            </div>

            <div className="space-y-1.5">
              <button
                onClick={() => setFilter('energie', '')}
                className={`w-full text-left px-3 py-2 rounded-xl text-xs font-medium flex items-center justify-between transition-colors ${
                  !selectedEnergie ? 'bg-[#e10600] text-white shadow-sm' : 'text-[var(--fg)] hover:bg-[var(--surface)]'
                }`}
              >
                <span>Toutes énergies</span>
              </button>
              {availableEnergies.map((eng) => {
                const isSelected = selectedEnergie.toLowerCase() === eng.toLowerCase();
                const count = vehicles.filter(v => (v.fuel || '').toLowerCase().includes(eng.toLowerCase())).length;
                return (
                  <button
                    key={eng}
                    onClick={() => setFilter('energie', isSelected ? '' : eng)}
                    className={`w-full text-left px-3 py-2 rounded-xl text-xs font-medium flex items-center justify-between transition-colors ${
                      isSelected ? 'bg-[#e10600] text-white shadow-sm' : 'text-[var(--fg)] hover:bg-[var(--surface)]'
                    }`}
                  >
                    <span>{eng}</span>
                    <span className="opacity-70 font-mono text-[11px]">({count})</span>
                  </button>
                );
              })}
            </div>
          </div>

          {mobileFilterOpen && (
            <div className="pt-4 lg:hidden">
              <button
                onClick={() => setMobileFilterOpen(false)}
                className="w-full py-3.5 bg-[#e10600] text-white rounded-full font-semibold text-xs uppercase tracking-wider shadow-sm"
              >
                Voir les modèles ({filteredVehicles.length})
              </button>
            </div>
          )}
        </aside>

        {/* Colonne droite : Catalogue des véhicules avec DÉFILEMENT INDÉPENDANT */}
        <main className="flex-1 lg:h-full lg:overflow-y-auto lg:overscroll-contain custom-scrollbar lg:pl-1 lg:pr-2 pb-16">
          {filteredVehicles.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
              {filteredVehicles.map((vehicle) => (
                <VehicleCard key={vehicle.id} vehicle={vehicle} />
              ))}
            </div>
          ) : (
            <div className="p-12 text-center rounded-2xl bg-[var(--card)] dark:bg-[#141417] border-0">
              <h3 className="font-heading font-medium text-lg mb-2">
                Aucun modèle ne correspond à ces critères
              </h3>
              <p className="text-xs text-[#6b6b72] max-w-md mx-auto mb-6 font-light">
                Vous recherchez une motorisation ou une finition spécifique ? Nous importons votre véhicule d’usine 0 km selon votre cahier des charges.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                <button
                  onClick={clearAllFilters}
                  className="pill-btn px-6 py-2.5 bg-[var(--surface)] text-[var(--fg)] text-xs font-semibold"
                >
                  Effacer les filtres
                </button>
                <Link
                  to="/contact"
                  className="pill-btn px-6 py-2.5 bg-[#e10600] text-white text-xs font-semibold"
                >
                  Commander sur-mesure
                </Link>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};
