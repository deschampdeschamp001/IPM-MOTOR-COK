import React from 'react';
import { Phone, Mail, MapPin, Lock, ArrowUpRight } from 'lucide-react';
import { DEALERSHIP_CONFIG } from '../config/dealership';
import { Link } from '../router/Router';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#0b0b0c] text-white border-t border-zinc-800 pt-16 pb-12 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 lg:gap-8 pb-12 border-b border-zinc-800/80">
          {/* Brand & Story Column */}
          <div className="lg:col-span-2 space-y-4">
            <Link to="/" className="flex items-center gap-3 group">
              <div className="w-10 h-10 rounded-xl overflow-hidden bg-white/10 p-1 flex items-center justify-center border border-white/20">
                <img
                  src="/assets/aistudio/image_150e736b.png"
                  alt="IPM Motors"
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="flex flex-col">
                <span className="font-heading font-bold text-xl leading-none">
                  IPM <span className="text-[#e10600]">MOTORS</span>
                </span>
                <span className="text-[10px] tracking-wider uppercase text-zinc-400 mt-1 font-semibold">
                  {DEALERSHIP_CONFIG.fullName}
                </span>
              </div>
            </Link>

            <p className="text-sm text-zinc-400 leading-relaxed max-w-sm font-light">
              Leader ambitieux et acteur influent du secteur automobile en Côte d'Ivoire. Vente exclusive de véhicules 100% neufs, 0 km, au cœur de Cocody Riviera Bonoumin.
            </p>

            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-white/5 border border-white/10 rounded-full text-xs text-zinc-300">
              <span className="w-2 h-2 rounded-full bg-[#e10600] animate-pulse" />
              <span>Showroom ouvert du lundi au samedi</span>
            </div>
          </div>

          {/* Column: Modèles */}
          <div>
            <h4 className="eyebrow mb-4">Modèles & Types</h4>
            <ul className="space-y-2.5 text-sm text-zinc-400 font-normal">
              <li>
                <Link to="/modeles?type=SUV" className="hover:text-white transition-colors">
                  SUV de Prestige
                </Link>
              </li>
              <li>
                <Link to="/modeles?type=Berline" className="hover:text-white transition-colors">
                  Berlines Élégantes
                </Link>
              </li>
              <li>
                <Link to="/modeles?type=Pick-up" className="hover:text-white transition-colors">
                  Pick-up 4x4
                </Link>
              </li>
              <li>
                <Link to="/modeles?type=Électrique" className="hover:text-white transition-colors">
                  Mobilité Électrique & Hybride
                </Link>
              </li>
              <li>
                <Link to="/modeles?type=Citadine" className="hover:text-white transition-colors">
                  Citadines
                </Link>
              </li>
            </ul>
          </div>

          {/* Column: Découvrir */}
          <div>
            <h4 className="eyebrow mb-4">Découvrir</h4>
            <ul className="space-y-2.5 text-sm text-zinc-400 font-normal">
              <li>
                <Link to="/offres" className="hover:text-white transition-colors">
                  Nos Offres du Moment
                </Link>
              </li>
              <li>
                <Link to="/marques" className="hover:text-white transition-colors">
                  Toutes nos Marques
                </Link>
              </li>
              <li>
                <Link to="/apres-vente" className="hover:text-white transition-colors">
                  Garantie & Après-Vente
                </Link>
              </li>
              <li>
                <Link to="/actualites" className="hover:text-white transition-colors">
                  Magazine & Actualités
                </Link>
              </li>
              <li>
                <Link to="/a-propos" className="hover:text-white transition-colors">
                  À Propos d’IPM Motors
                </Link>
              </li>
            </ul>
          </div>

          {/* Column: Contact & Showroom */}
          <div>
            <h4 className="eyebrow mb-4">Showroom</h4>
            <ul className="space-y-3 text-sm text-zinc-400">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#e10600] shrink-0 mt-0.5" />
                <span className="text-xs leading-relaxed">
                  {DEALERSHIP_CONFIG.address}
                </span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#e10600] shrink-0" />
                <a href={`tel:${DEALERSHIP_CONFIG.phone}`} className="hover:text-white text-xs">
                  {DEALERSHIP_CONFIG.phoneDisplay}
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-[#e10600] shrink-0" />
                <a href={`mailto:${DEALERSHIP_CONFIG.email}`} className="hover:text-white text-xs">
                  {DEALERSHIP_CONFIG.email}
                </a>
              </li>
              <li className="pt-2">
                <a
                  href={DEALERSHIP_CONFIG.googleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs text-[#e10600] hover:underline"
                >
                  <span>Itinéraire Google Maps</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar: Copyright & Discreet Admin Link */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-zinc-500">
          <p>
            © {new Date().getFullYear()} {DEALERSHIP_CONFIG.fullName}. Tous droits réservés. Véhicules neufs 0 km à Abidjan.
          </p>
          <div className="flex items-center gap-6">
            <Link to="/admin" className="inline-flex items-center gap-1.5 text-zinc-500 hover:text-zinc-300 transition-colors">
              <Lock className="w-3.5 h-3.5" />
              <span>Espace Administration</span>
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};
