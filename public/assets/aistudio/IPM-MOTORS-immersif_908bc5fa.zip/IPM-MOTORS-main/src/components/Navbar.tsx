import React, { useState, useEffect } from 'react';
import { Menu, X, Phone, Sun, Moon, ArrowRight } from 'lucide-react';
import { DEALERSHIP_CONFIG } from '../config/dealership';
import { useTheme } from '../context/ThemeContext';
import { Link, useRouter } from '../router/Router';

export const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [overHero, setOverHero] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { toggleTheme, isDark } = useTheme();
  const { pathname } = useRouter();

  const isHome = pathname === '/';

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40);
      // Tant que le hero immersif occupe l'écran, la navbar reste transparente (texte blanc)
      const hero = document.getElementById('hero');
      setOverHero(!!hero && hero.getBoundingClientRect().bottom > 90);
    };
    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    window.addEventListener('resize', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('resize', handleScroll);
    };
  }, [pathname]);

  // Close mobile menu on route change
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [pathname]);

  const navLinks = [
    { label: 'Modèles', href: '/modeles' },
    { label: 'Offres', href: '/offres' },
    { label: 'Marques', href: '/marques' },
    { label: 'Après-vente', href: '/apres-vente' },
    { label: 'Actualités', href: '/actualites' },
    { label: 'À propos', href: '/a-propos' },
  ];

  const isTransparent = isHome && (!isScrolled || overHero);

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isTransparent
            ? 'bg-gradient-to-b from-black/80 via-black/40 to-transparent text-white py-5'
            : isDark
            ? 'bg-[#09090b]/90 backdrop-blur-xl border-b border-[#27272a] text-white py-3.5 shadow-lg shadow-black/20'
            : 'bg-white/90 backdrop-blur-xl border-b border-[#e7e7ea] text-[#0b0b0c] py-3.5 shadow-sm'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-6">
            {/* Brand Logo Lockup */}
            <Link to="/" className="flex items-center gap-3 group focus:outline-none">
              <div className="w-10 h-10 rounded-xl overflow-hidden bg-white/10 p-1 flex items-center justify-center border border-white/20 transition-transform duration-300 group-hover:scale-105">
                <img
                  src="/assets/aistudio/image_150e736b.png"
                  alt="IPM Motors"
                  className="w-full h-full object-contain"
                  onError={(e) => {
                    // Fallback to text initials if image fails
                    e.currentTarget.style.display = 'none';
                  }}
                />
              </div>
              <div className="flex flex-col">
                <span className="font-heading font-light tracking-tight text-lg sm:text-xl leading-none font-bold">
                  IPM <span className="text-[#e10600]">MOTORS</span>
                </span>
                <span className={`text-[10px] tracking-wider uppercase mt-1 font-semibold ${isTransparent ? 'text-white/70' : 'text-[#6b6b72]'}`}>
                  Abidjan • Neuf 0 km
                </span>
              </div>
            </Link>

            {/* Desktop Navigation Links */}
            <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
              {navLinks.map((item) => {
                const isActive = pathname === item.href || (item.href !== '/' && pathname.startsWith(item.href));
                return (
                  <Link
                    key={item.href}
                    to={item.href}
                    className={`px-3.5 py-1.5 rounded-full text-xs xl:text-sm font-medium tracking-tight transition-all duration-200 ${
                      isActive
                        ? 'bg-[#e10600] text-white font-semibold shadow-sm'
                        : isTransparent
                        ? 'text-white/90 hover:text-white hover:bg-white/10'
                        : isDark
                        ? 'text-zinc-300 hover:text-white hover:bg-zinc-800/80'
                        : 'text-[#0b0b0c] hover:text-black hover:bg-[#f5f5f6]'
                    }`}
                  >
                    {item.label}
                  </Link>
                );
              })}
            </nav>

            {/* Action CTAs */}
            <div className="hidden md:flex items-center gap-3">
              {/* Phone CTA */}
              <a
                href={`tel:${DEALERSHIP_CONFIG.phone}`}
                className={`flex items-center gap-2 text-xs font-semibold px-3 py-1.5 rounded-full transition-colors ${
                  isTransparent
                    ? 'text-white hover:text-white/80'
                    : isDark
                    ? 'text-zinc-200 hover:text-white'
                    : 'text-[#0b0b0c] hover:text-[#e10600]'
                }`}
              >
                <div className="w-7 h-7 rounded-full bg-[#e10600]/10 flex items-center justify-center text-[#e10600]">
                  <Phone className="w-3.5 h-3.5" />
                </div>
                <span>{DEALERSHIP_CONFIG.phoneDisplay}</span>
              </a>

              {/* Theme Toggle */}
              <button
                onClick={toggleTheme}
                type="button"
                aria-label="Changer de thème"
                className={`p-2 rounded-full transition-colors ${
                  isTransparent
                    ? 'bg-white/10 text-white hover:bg-white/20'
                    : isDark
                    ? 'bg-zinc-800 text-amber-400 hover:bg-zinc-700'
                    : 'bg-[#f5f5f6] text-[#6b6b72] hover:text-[#0b0b0c] hover:bg-neutral-200'
                }`}
              >
                {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </button>

              {/* Devis CTA Button */}
              <Link
                to="/contact"
                className="pill-btn inline-flex items-center gap-2 bg-[#e10600] hover:bg-[#c30500] text-white text-xs font-semibold px-5 py-2.5 shadow-md shadow-[#e10600]/20 hover:scale-[1.02] active:scale-[0.98] transition-all"
              >
                <span>Devis</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>

            {/* Mobile Actions & Burger Toggle */}
            <div className="flex items-center gap-2 lg:hidden">
              <button
                onClick={toggleTheme}
                type="button"
                aria-label="Changer de thème"
                className={`p-2 rounded-full ${
                  isTransparent
                    ? 'bg-white/10 text-white'
                    : isDark
                    ? 'bg-zinc-800 text-amber-400'
                    : 'bg-[#f5f5f6] text-[#6b6b72]'
                }`}
              >
                {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </button>

              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                aria-label={mobileMenuOpen ? 'Fermer le menu' : 'Ouvrir le menu'}
                className={`p-2 rounded-xl transition-colors ${
                  isTransparent
                    ? 'bg-white/10 text-white hover:bg-white/20'
                    : isDark
                    ? 'bg-zinc-800 text-white'
                    : 'bg-[#f5f5f6] text-[#0b0b0c]'
                }`}
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Full-screen Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 lg:hidden bg-black/60 backdrop-blur-md animate-fade-in">
          <div
            className={`fixed inset-y-0 right-0 w-full max-w-sm p-6 flex flex-col justify-between shadow-2xl transition-transform duration-300 ${
              isDark ? 'bg-[#0e0e11] text-white' : 'bg-white text-[#0b0b0c]'
            }`}
          >
            <div>
              <div className="flex items-center justify-between pb-6 border-b border-[var(--border)]">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg overflow-hidden bg-white/10 p-0.5">
                    <img
                      src="/assets/aistudio/image_150e736b.png"
                      alt="IPM"
                      className="w-full h-full object-contain"
                    />
                  </div>
                  <span className="font-heading font-bold text-lg">
                    IPM <span className="text-[#e10600]">MOTORS</span>
                  </span>
                </div>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-2 rounded-lg text-neutral-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="eyebrow mt-6 mb-3">Navigation</div>
              <nav className="flex flex-col gap-1">
                {navLinks.map((item) => {
                  const isActive = pathname === item.href;
                  return (
                    <Link
                      key={item.href}
                      to={item.href}
                      onClick={() => setMobileMenuOpen(false)}
                      className={`flex items-center justify-between px-4 py-3 rounded-xl text-base font-medium transition-colors ${
                        isActive
                          ? 'bg-[#e10600] text-white font-semibold'
                          : isDark
                          ? 'text-zinc-200 hover:bg-zinc-800/60'
                          : 'text-[#0b0b0c] hover:bg-[#f5f5f6]'
                      }`}
                    >
                      <span>{item.label}</span>
                      <ArrowRight className="w-4 h-4 opacity-60" />
                    </Link>
                  );
                })}
              </nav>
            </div>

            <div className="pt-6 border-t border-[var(--border)] space-y-4">
              <a
                href={`tel:${DEALERSHIP_CONFIG.phone}`}
                className="flex items-center justify-center gap-3 py-3 px-4 rounded-xl border border-[var(--border)] text-sm font-semibold hover:border-[#e10600]"
              >
                <Phone className="w-4 h-4 text-[#e10600]" />
                <span>Appeler le {DEALERSHIP_CONFIG.phoneDisplay}</span>
              </a>

              <Link
                to="/contact"
                onClick={() => setMobileMenuOpen(false)}
                className="pill-btn w-full py-3.5 bg-[#e10600] hover:bg-[#c30500] text-white font-semibold flex items-center justify-center gap-2 shadow-lg shadow-[#e10600]/25"
              >
                <span>Demander un devis VIP</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
