import { DealershipConfig } from '../types';

export const DEALERSHIP_CONFIG: DealershipConfig = {
  name: 'IPM MOTORS',
  fullName: 'Ivoire Premium Motors',
  phone: '+2250701202021',
  phoneDisplay: '07 01 20 20 21',
  whatsapp: '2250701202021',
  email: 'ipmotors225@gmail.com',
  address: 'Cocody Riviera Bonoumin, près du feu tricolore de la pharmacie Saint Paul (ou de la mosquée Mont Arafat de Bonoumin)',
  neighborhood: 'Cocody Riviera Bonoumin',
  city: 'Abidjan',
  country: "Côte d'Ivoire",
  coordinates: {
    lat: 5.28394,
    lng: -3.97594,
  },
  googleMapsUrl: 'https://maps.app.goo.gl/YWfUdsTF3xF5McaE6',
};

export const POPULAR_BRANDS = [
  'BYD',
  'Nissan',
  'BMW',
  'Kia',
  'Jetour',
  'Toyota',
  'Mitsubishi',
  'Suzuki',
  'Mercedes-Benz',
  'Changan',
  'Geely',
  'Haval',
  'Land Rover'
];

export const VEHICLE_TYPES = ['Tous', 'SUV', 'Berline', 'Pick-up', 'Électrique', 'Citadine'] as const;

/**
 * Helper to build prefilled WhatsApp URLs for user inquiries
 */
export function buildWhatsAppUrl(message: string, customPhone?: string): string {
  const phone = customPhone || DEALERSHIP_CONFIG.whatsapp;
  return `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
}
