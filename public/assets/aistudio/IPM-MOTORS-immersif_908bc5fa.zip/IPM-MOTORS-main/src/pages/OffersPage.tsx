import React, { useEffect } from 'react';
import { useData } from '../context/DataContext';
import { Link } from '../router/Router';
import { buildWhatsAppUrl } from '../config/dealership';
import { CheckCircle2, MessageCircle, ArrowRight, Sparkles, Tag, Shield } from 'lucide-react';

export const OffersPage: React.FC = () => {
  const { vehicles } = useData();

  useEffect(() => {
    document.title = 'Nos Offres Spéciales 0 km | IPM Motors Abidjan';
  }, []);

  const offerVehicles = vehicles.filter((v) => v.is_offer || v.is_featured);

  return (
    <div className="pt-24 sm:pt-32 pb-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-16">
        <span className="eyebrow block mb-2">Conditions Exceptionnelles</span>
        <h1 className="font-heading font-light text-3xl sm:text-5xl tracking-tight">
          Nos Offres <span className="font-semibold text-[#e10600]">du Moment</span>
        </h1>
        <p className="text-sm sm:text-base text-[#6b6b72] mt-3 font-light">
          Bénéficiez d’avantages exclusifs sur notre sélection de véhicules neufs 0 km : immatriculation offerte, garanties étendues et livraison VIP partout en Côte d’Ivoire.
        </p>
      </div>

      {/* Grid of Offers */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {offerVehicles.map((vehicle) => {
          const mainImg = vehicle.images?.[0] || '/assets/cars/hero_dealership_car_1793116464643.jpg';
          const waMessage = `Bonjour IPM Motors, je souhaite profiter de l'offre spéciale sur le véhicule ${vehicle.brand} ${vehicle.model} 0 km. Pouvez-vous m'envoyer les détails ?`;
          const waUrl = buildWhatsAppUrl(waMessage);

          return (
            <div
              key={vehicle.id}
              className="rounded-3xl border border-[var(--border)] bg-[var(--card)] p-7 flex flex-col justify-between hover:border-[#e10600] transition-all duration-300 hover:shadow-xl group"
            >
              <div>
                {/* Offer Badge */}
                <div className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-[#e10600]/10 border border-[#e10600]/25 text-[#e10600] text-[11px] font-bold tracking-wider uppercase mb-5">
                  <Tag className="w-3.5 h-3.5" />
                  <span>{vehicle.offer_badge || 'Offre Showroom Exclusif'}</span>
                </div>

                {/* Photo */}
                <Link to={`/vehicule/${vehicle.id}`} className="block relative aspect-[16/10] rounded-2xl overflow-hidden mb-6 bg-zinc-950">
                  <img
                    src={mainImg}
                    alt={`${vehicle.brand} ${vehicle.model}`}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    onError={(e) => {
                      e.currentTarget.src = '/assets/aistudio/814493891_122239370216113743_2889832111464126919_n_8772dda4.jpg';
                    }}
                  />
                  <div className="absolute top-3 left-3">
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-bold tracking-wider uppercase bg-black/80 backdrop-blur-md text-white border border-white/20">
                      0 KM D'ORIGINE
                    </span>
                  </div>
                </Link>

                <span className="text-[11px] font-bold text-[#e10600] tracking-wider uppercase block">
                  {vehicle.brand}
                </span>
                <h3 className="font-heading font-medium text-xl leading-snug mt-1 mb-3">
                  {vehicle.model}
                </h3>

                <p className="text-xs text-[#6b6b72] font-light leading-relaxed mb-6 line-clamp-2">
                  {vehicle.description}
                </p>

                {/* Offer Highlights List */}
                <div className="space-y-2.5 mb-6 pt-4 border-t border-[var(--border)]">
                  {(vehicle.offer_highlights && vehicle.offer_highlights.length > 0
                    ? vehicle.offer_highlights
                    : [
                        'Immatriculation et carte grise ivoirienne offertes',
                        'Livraison VIP à domicile ou sur rendez-vous',
                        'Garantie constructeur intégrale avec carnet officiel'
                      ]
                  ).map((highlight, idx) => (
                    <div key={idx} className="flex items-start gap-2.5 text-xs text-[#0b0b0c] dark:text-zinc-200">
                      <CheckCircle2 className="w-4 h-4 text-[#e10600] shrink-0 mt-0.5" />
                      <span>{highlight}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 border-t border-[var(--border)] space-y-2.5">
                <a
                  href={waUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="pill-btn w-full py-3.5 bg-[#e10600] hover:bg-[#c30500] text-white text-xs font-semibold flex items-center justify-center gap-2 shadow-md shadow-[#e10600]/25 transition-all"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Réclamer l'offre sur WhatsApp</span>
                </a>

                <Link
                  to={`/vehicule/${vehicle.id}`}
                  className="pill-btn w-full py-2.5 bg-[var(--surface)] hover:bg-[var(--border)] text-[var(--fg)] text-xs font-medium flex items-center justify-center gap-1.5 transition-colors"
                >
                  <span>Fiche technique détaillée</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </div>
            </div>
          );
        })}
      </div>

      {/* Custom Order Callout */}
      <div className="mt-20 p-8 sm:p-12 rounded-3xl bg-gradient-to-br from-zinc-900 to-black text-white border border-zinc-800 flex flex-col md:flex-row items-center justify-between gap-8">
        <div className="space-y-3 max-w-xl text-center md:text-left">
          <span className="text-[#e10600] text-xs font-bold uppercase tracking-widest block">
            Offre personnalisée
          </span>
          <h2 className="font-heading font-light text-2xl sm:text-4xl">
            Vous souhaitez un modèle hors stock ?
          </h2>
          <p className="text-sm text-zinc-400 font-light leading-relaxed">
            Profitez de nos conditions d’importation directe sans intermédiaire pour commander votre véhicule neuf au meilleur tarif du marché.
          </p>
        </div>

        <Link
          to="/contact"
          className="pill-btn shrink-0 px-8 py-4 bg-white hover:bg-zinc-100 text-zinc-950 text-xs font-bold uppercase tracking-wider shadow-lg"
        >
          Demander une offre sur-mesure
        </Link>
      </div>
    </div>
  );
};
