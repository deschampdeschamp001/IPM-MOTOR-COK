# Changements – hero immersif + animations de sections

## Nouveaux fichiers
- `src/data/heroScenes.ts` : les 5 scènes du hero (photo, gros mot, textes, liens). **C'est ici qu'on change les photos.**
- `src/components/home/VehicleShowcase.tsx` : vitrine horizontale épinglée (le scroll vertical fait défiler les véhicules).
- `src/components/home/ScrollReveal.tsx` : texte qui s'allume mot par mot + compteurs (`CountUp`).
- `netlify.toml` : build + redirection SPA (évite les 404 au rechargement de /modeles, /admin...).

## Fichiers modifiés
- `src/components/Hero.tsx` : remplacé par le hero scroll-scrubbé (cadre arrondi → plein écran, dézoom, wipe entre scènes, gros mot qui monte). Version statique si « réduire les animations » est activé.
- `src/pages/HomePage.tsx` : ajout de la vitrine (entre « Nos modèles » et « Nos offres ») + texte/compteurs animés dans « Bienvenue chez IPM MOTORS ».
- `src/components/Navbar.tsx` : reste transparente tant que le hero est à l'écran.
- `package.json` : `esbuild` ^0.25 → ^0.28 (conflit de dépendance avec vite 8 qui faisait échouer `npm install`).
- Tous les chemins `/public/assets/...` → `/assets/...` (les anciens chemins ne fonctionnent qu'en dev, pas en production sur Netlify).

## Option vidéo (hero)
Dans `heroScenes.ts`, ajoutez `video: '/assets/hero/showroom.mp4'` à la première scène :
la vidéo sera lue/rembobinée par le scroll. Encodage conseillé :
`ffmpeg -i in.mp4 -an -vf scale=1280:-2 -c:v libx264 -crf 26 -g 5 -movflags +faststart showroom.mp4`
