import React, { useEffect, useRef, useState } from 'react';
import {
  motion,
  MotionValue,
  useMotionValue,
  useMotionValueEvent,
  useReducedMotion,
  useScroll,
  useSpring,
  useTransform,
} from 'motion/react';
import { ArrowRight, MessageCircle } from 'lucide-react';
import { Vehicle } from '../../types';
import { Link } from '../../router/Router';
import { buildWhatsAppUrl } from '../../config/dealership';

const FALLBACK_IMG = '/assets/aistudio/814493891_122239370216113743_2889832111464126919_n_8772dda4.jpg';

/** Carte véhicule : l'image glisse légèrement à l'inverse du défilement (profondeur) */
const ShowcaseCard: React.FC<{ vehicle: Vehicle; p: MotionValue<number> }> = ({ vehicle, p }) => {
  const imgX = useTransform(p, [0, 1], ['-7%', '7%']);
  const img = vehicle.images?.[0] || FALLBACK_IMG;
  const wa = buildWhatsAppUrl(
    `Bonjour IPM Motors, je souhaite des informations sur le ${vehicle.brand} ${vehicle.model} 0 km.`,
  );

  return (
    <article className="relative shrink-0 w-[78vw] sm:w-[52vw] lg:w-[36vw] max-w-[620px] flex flex-col">
      <Link
        to={`/vehicule/${vehicle.id}`}
        className="group relative block aspect-[4/3] overflow-hidden rounded-3xl bg-zinc-900"
        aria-label={`Voir la fiche ${vehicle.brand} ${vehicle.model}`}
      >
        <motion.img
          src={img}
          alt={`${vehicle.brand} ${vehicle.model}`}
          loading="lazy"
          draggable={false}
          onError={(e) => {
            e.currentTarget.src = FALLBACK_IMG;
          }}
          className="absolute inset-y-0 -left-[10%] w-[120%] max-w-none h-full object-cover"
          style={{ x: imgX }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
        {vehicle.is_offer && vehicle.offer_badge && (
          <span className="absolute top-4 left-4 px-3 py-1 rounded-full bg-[#e10600] text-white text-[11px] font-semibold">
            {vehicle.offer_badge}
          </span>
        )}
        <span className="absolute bottom-4 left-5 right-5 flex items-end justify-between text-white">
          <span>
            <span className="block text-xs text-white/70">{vehicle.brand}</span>
            <span className="block font-heading font-medium text-xl sm:text-2xl leading-tight">{vehicle.model}</span>
          </span>
          <span className="text-xs text-white/80">{vehicle.year}</span>
        </span>
      </Link>

      <div className="mt-4 flex items-center justify-between gap-3">
        <p className="text-sm text-zinc-400 font-light truncate">
          {[vehicle.type, vehicle.fuel, vehicle.transmission].filter(Boolean).join(' · ')}
        </p>
        <a
          href={wa}
          target="_blank"
          rel="noopener noreferrer"
          className="pill-btn shrink-0 inline-flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-[#e10600] text-white text-xs font-semibold border border-white/15"
        >
          <MessageCircle className="w-3.5 h-3.5" />
          <span>{vehicle.price_label || 'Prix sur demande'}</span>
        </a>
      </div>
    </article>
  );
};

/**
 * Vitrine horizontale : la section reste épinglée à l'écran pendant que le scroll vertical
 * fait défiler les véhicules de droite à gauche.
 */
export const VehicleShowcase: React.FC<{ vehicles: Vehicle[] }> = ({ vehicles }) => {
  const items = vehicles.slice(0, 6);
  const reduce = useReducedMotion();
  const sectionRef = useRef<HTMLElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const shift = useMotionValue(0);
  const [sectionHeight, setSectionHeight] = useState<number | null>(null);
  const [current, setCurrent] = useState(1);

  const { scrollYProgress } = useScroll({ target: sectionRef, offset: ['start start', 'end end'] });
  const smooth = useSpring(scrollYProgress, { stiffness: 140, damping: 30, mass: 0.35 });
  // Petite pause au début et à la fin pour que le titre et la dernière carte soient bien lisibles
  const p = useTransform(smooth, [0.07, 0.93], [0, 1]);
  const x = useTransform([p, shift], ([a, s]: number[]) => -a * s);
  const barScale = p;

  // Mesure la largeur du ruban pour savoir de combien il doit défiler
  useEffect(() => {
    if (reduce) return;
    const measure = () => {
      const track = trackRef.current;
      if (!track) return;
      const overflow = Math.max(0, track.scrollWidth - window.innerWidth);
      shift.set(overflow);
      setSectionHeight(overflow + window.innerHeight * 1.1);
    };
    measure();
    const ro = new ResizeObserver(measure);
    if (trackRef.current) ro.observe(trackRef.current);
    window.addEventListener('resize', measure);
    return () => {
      ro.disconnect();
      window.removeEventListener('resize', measure);
    };
  }, [reduce, items.length, shift]);

  useMotionValueEvent(p, 'change', (v) => {
    setCurrent(Math.min(items.length, Math.max(1, Math.round(v * (items.length - 1)) + 1)));
  });

  if (items.length === 0) return null;

  const header = (
    <div className="shrink-0 w-[82vw] sm:w-[42vw] lg:w-[30vw] max-w-[460px] pr-6 flex flex-col justify-center">
      <span className="eyebrow block mb-3">En vitrine</span>
      <h2 className="font-heading font-extralight text-4xl sm:text-5xl tracking-tight leading-[1.05] text-white">
        Les derniers arrivages <span className="font-semibold">0 km</span>
      </h2>
      <p className="mt-4 text-sm sm:text-base text-zinc-400 font-light leading-relaxed">
        Faites défiler pour parcourir une sélection de notre parc, disponible dès maintenant à Cocody Riviera Bonoumin.
      </p>
    </div>
  );

  const footer = (
    <div className="shrink-0 w-[70vw] sm:w-[34vw] lg:w-[24vw] max-w-[380px] flex flex-col justify-center">
      <h3 className="font-heading font-light text-3xl sm:text-4xl text-white tracking-tight leading-tight">
        Un autre modèle <span className="font-semibold">en tête ?</span>
      </h3>
      <Link
        to="/modeles"
        className="pill-btn mt-6 self-start inline-flex items-center gap-2 px-7 py-3.5 bg-[#e10600] hover:bg-[#c30500] text-white text-sm font-semibold shadow-lg shadow-[#e10600]/30"
      >
        <span>Voir tout le catalogue</span>
        <ArrowRight className="w-4 h-4" />
      </Link>
    </div>
  );

  // Réduction des animations : simple ruban qu'on fait défiler au doigt / à la souris
  if (reduce) {
    return (
      <section className="bg-[#09090b] py-20 overflow-hidden">
        <div className="flex gap-6 px-4 sm:px-8 overflow-x-auto snap-x pb-4 custom-scrollbar">
          {header}
          {items.map((v) => (
            <ShowcaseCard key={v.id} vehicle={v} p={p} />
          ))}
          {footer}
        </div>
      </section>
    );
  }

  return (
    <section
      ref={sectionRef}
      aria-label="Vitrine des véhicules"
      className="relative bg-[#09090b]"
      style={{ height: sectionHeight ? `${sectionHeight}px` : '300vh' }}
    >
      <div className="sticky top-0 h-svh overflow-hidden flex flex-col justify-center">
        <motion.div ref={trackRef} style={{ x }} className="flex items-center gap-6 sm:gap-10 px-4 sm:px-8 lg:px-14 w-max will-change-transform">
          {header}
          {items.map((v) => (
            <ShowcaseCard key={v.id} vehicle={v} p={p} />
          ))}
          {footer}
        </motion.div>

        {/* Compteur et progression */}
        <div className="absolute left-4 sm:left-8 lg:left-14 right-4 sm:right-8 lg:right-14 bottom-8 flex items-center gap-4 text-xs text-zinc-400">
          <span className="font-mono tabular-nums text-white">
            {String(current).padStart(2, '0')} <span className="text-zinc-500">/ {String(items.length).padStart(2, '0')}</span>
          </span>
          <span className="relative h-px flex-1 bg-white/15 overflow-hidden">
            <motion.span style={{ scaleX: barScale }} className="absolute inset-0 bg-[#e10600] origin-left" />
          </span>
        </div>
      </div>
    </section>
  );
};
