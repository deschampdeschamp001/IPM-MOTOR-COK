import React, { useEffect } from 'react';
import { DEALERSHIP_CONFIG } from '../config/dealership';
import { Link } from '../router/Router';
import {
  ShieldCheck,
  Award,
  CheckCircle2,
  MapPin,
  Clock,
  Phone,
  ArrowRight,
  Sparkles,
  Users
} from 'lucide-react';

export const AboutPage: React.FC = () => {
  useEffect(() => {
    document.title = 'À Propos | IPM Motors Abidjan - L’Excellence Automobile';
  }, []);

  return (
    <div className="pt-24 sm:pt-32 pb-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Hero Header */}
      <div className="text-center max-w-3xl mx-auto mb-16">
        <span className="eyebrow block mb-2">Notre Histoire & Notre Vision</span>
        <h1 className="font-heading font-light text-3xl sm:text-5xl tracking-tight leading-tight">
          L’Excellence Automobile <span className="font-semibold text-[#e10600]">à votre portée</span>
        </h1>
        <p className="text-sm sm:text-base text-[#6b6b72] mt-3 font-light leading-relaxed">
          Bienvenue chez IPM MOTORS, votre partenaire de confiance pour l’achat de véhicules neufs 0 km en Côte d’Ivoire.
        </p>
      </div>

      {/* Main Presentation & Showcase Image */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mb-20">
        <div className="lg:col-span-7 space-y-6">
          <h2 className="font-heading font-light text-2xl sm:text-4xl leading-tight">
            Leader ambitieux et acteur influent du <span className="font-semibold">secteur automobile</span>
          </h2>

          <p className="text-sm sm:text-base text-[#6b6b72] leading-relaxed font-light">
            Bienvenue chez IPM MOTORS, votre partenaire de confiance pour l’achat de véhicules neufs en Côte d’Ivoire. Leader ambitieux et acteur influent du secteur automobile, nous mettons notre expertise et notre passion au service de vos exigences pour vous proposer des véhicules qui allient prestige, performance, confort et élégance.
          </p>

          <blockquote className="p-6 rounded-2xl bg-[var(--surface)] border-l-4 border-[#e10600] text-sm sm:text-base font-medium italic text-[var(--fg)]">
            « Avec IPM MOTORS, donnez une nouvelle dimension à vos déplacements ! »
          </blockquote>

          <p className="text-sm sm:text-base text-[#6b6b72] leading-relaxed font-light">
            Que vous recherchiez un SUV de luxe, une berline élégante, un véhicule familial ou un modèle aux performances exceptionnelles, nous vous accompagnons dans la réalisation de votre projet automobile avec professionnalisme, disponibilité et sens du service.
          </p>

          <p className="text-sm sm:text-base font-medium text-[var(--fg)]">
            IPM MOTORS, bien plus qu’un vendeur de véhicules : une vision du luxe, de la qualité et de la satisfaction client.
          </p>
        </div>

        <div className="lg:col-span-5">
          <div className="relative rounded-3xl overflow-hidden border border-[var(--border)] shadow-2xl aspect-[4/3]">
            <img
              src="/assets/aistudio/814493891_122239370216113743_2889832111464126919_n_8772dda4.jpg"
              alt="Showroom IPM Motors à Bonoumin"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-transparent to-transparent flex flex-col justify-end p-6 text-white">
              <span className="text-[10px] font-bold text-[#e10600] uppercase tracking-wider">
                Showroom Principal
              </span>
              <h3 className="font-heading font-medium text-lg mt-0.5">
                Cocody Riviera Bonoumin
              </h3>
              <p className="text-xs text-zinc-300 font-light mt-1">
                {DEALERSHIP_CONFIG.address}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 4 Numbered Pillars */}
      <div className="mb-20">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="eyebrow block mb-2">Nos Engagements</span>
          <h2 className="font-heading font-light text-2xl sm:text-4xl">
            Les 4 Piliers <span className="font-semibold">IPM Motors</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="p-7 rounded-3xl border border-[var(--border)] bg-[var(--card)] space-y-3">
            <span className="font-heading font-bold text-2xl text-[#e10600]">01</span>
            <h3 className="font-heading font-medium text-lg">100% Neuf 0 KM</h3>
            <p className="text-xs text-[#6b6b72] font-light leading-relaxed">
              Zéro kilométrage d’usage. Véhicules d'origine usine garantis avec documents officiels d'importation.
            </p>
          </div>

          <div className="p-7 rounded-3xl border border-[var(--border)] bg-[var(--card)] space-y-3">
            <span className="font-heading font-bold text-2xl text-[#e10600]">02</span>
            <h3 className="font-heading font-medium text-lg">Sélection Multimarque</h3>
            <p className="text-xs text-[#6b6b72] font-light leading-relaxed">
              Plus de 13 grandes marques réunies : allemandes, japonaises, coréennes et leaders électriques mondiaux.
            </p>
          </div>

          <div className="p-7 rounded-3xl border border-[var(--border)] bg-[var(--card)] space-y-3">
            <span className="font-heading font-bold text-2xl text-[#e10600]">03</span>
            <h3 className="font-heading font-medium text-lg">Disponibilité Immédiate</h3>
            <p className="text-xs text-[#6b6b72] font-light leading-relaxed">
              Stock physique prêt à Abidjan pour une livraison sous 24 à 48 heures sans attente d'acheminement maritime.
            </p>
          </div>

          <div className="p-7 rounded-3xl border border-[var(--border)] bg-[var(--card)] space-y-3">
            <span className="font-heading font-bold text-2xl text-[#e10600]">04</span>
            <h3 className="font-heading font-medium text-lg">Satisfaction Client VIP</h3>
            <p className="text-xs text-[#6b6b72] font-light leading-relaxed">
              Conseiller dédié, immatriculation express Quipux, livraison à domicile et écoute personnalisée continue.
            </p>
          </div>
        </div>
      </div>

      {/* Showroom Visit Callout */}
      <div className="p-8 sm:p-12 rounded-3xl bg-[var(--surface)] border border-[var(--border)] flex flex-col md:flex-row items-center justify-between gap-8">
        <div className="space-y-3 max-w-xl text-center md:text-left">
          <span className="eyebrow block">Rencontrons-nous</span>
          <h3 className="font-heading font-light text-2xl sm:text-3xl">
            Venez découvrir nos véhicules au showroom
          </h3>
          <p className="text-xs sm:text-sm text-[#6b6b72] font-light leading-relaxed">
            Notre showroom climatisé vous accueille à Cocody Riviera Bonoumin du lundi au samedi pour configurer votre véhicule ou réaliser un essai.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 shrink-0">
          <Link
            to="/contact"
            className="pill-btn px-7 py-3.5 bg-[#e10600] hover:bg-[#c30500] text-white text-xs font-semibold flex items-center justify-center gap-2 shadow-md shadow-[#e10600]/20"
          >
            <span>Prendre rendez-vous</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
          <a
            href={DEALERSHIP_CONFIG.googleMapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="pill-btn px-6 py-3.5 bg-[var(--card)] hover:bg-[var(--border)] text-[var(--fg)] text-xs font-semibold border border-[var(--border)] text-center"
          >
            Itinéraire GPS
          </a>
        </div>
      </div>
    </div>
  );
};
