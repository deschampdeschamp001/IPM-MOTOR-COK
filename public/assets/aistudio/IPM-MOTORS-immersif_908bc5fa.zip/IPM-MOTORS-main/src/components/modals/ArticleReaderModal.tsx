import React from 'react';
import { X, Calendar, Clock, Share2, MessageSquare, ArrowRight } from 'lucide-react';
import { NewsArticle } from '../../types';
import { buildWhatsAppUrl } from '../../config/dealership';

interface ArticleReaderModalProps {
  article: NewsArticle | null;
  onClose: () => void;
  onExploreVehicles?: () => void;
}

export const ArticleReaderModal: React.FC<ArticleReaderModalProps> = ({
  article,
  onClose,
  onExploreVehicles,
}) => {
  if (!article) return null;

  const handleShareWhatsApp = () => {
    const text = `Découvrez cet article sur IPM Motors : *${article.title}*\n${window.location.origin}/actualites`;
    const waUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
    window.open(waUrl, '_blank', 'noopener,noreferrer');
  };

  const handleInquireArticle = () => {
    const waMsg = `Bonjour IPM Motors, je viens de lire votre actualité : "${article.title}". Je souhaite obtenir plus d'informations à ce sujet.`;
    window.open(buildWhatsAppUrl(waMsg), '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-[#121212] border border-[#262626] rounded-2xl max-w-3xl w-full max-h-[92vh] overflow-y-auto text-white shadow-2xl relative flex flex-col">
        {/* Cover Image Header */}
        <div className="relative aspect-[16/9] w-full overflow-hidden bg-black shrink-0">
          <img
            src={article.cover_image}
            alt={article.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#121212] via-[#121212]/40 to-transparent" />

          {/* Close button */}
          <button
            onClick={onClose}
            aria-label="Fermer"
            className="absolute top-4 right-4 p-2 bg-black/60 hover:bg-black/90 text-white rounded-full backdrop-blur-sm transition-colors border border-white/10 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Category kicker */}
          <div className="absolute bottom-4 left-6 sm:left-8">
            <span className="text-[11px] uppercase tracking-widest font-extrabold text-[#E10600] bg-black/60 px-2.5 py-1 rounded backdrop-blur-sm border border-white/10">
              {article.category}
            </span>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 space-y-6 flex-1">
          {/* Metadata */}
          <div className="flex flex-wrap items-center gap-3 text-xs text-neutral-400">
            <div className="flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-[#E10600]" />
              <span>
                {new Date(article.published_at).toLocaleDateString('fr-FR', {
                  day: 'numeric',
                  month: 'long',
                  year: 'numeric',
                })}
              </span>
            </div>
            <span>·</span>
            <div className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-[#8A8A8A]" />
              <span>{article.read_time || '3 min'} de lecture</span>
            </div>
            {article.author && (
              <>
                <span>·</span>
                <span className="text-white font-medium">{article.author}</span>
              </>
            )}
          </div>

          {/* Article Title */}
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white leading-tight">
            {article.title}
          </h1>

          {/* Lead / Excerpt */}
          <p className="text-base sm:text-lg font-normal text-neutral-300 leading-relaxed border-l-2 border-[#E10600] pl-4 italic bg-[#181818]/50 py-2 rounded-r">
            {article.excerpt}
          </p>

          {/* Full Content */}
          <div className="prose prose-invert max-w-none text-sm sm:text-base text-neutral-300 leading-relaxed space-y-4 whitespace-pre-line font-normal">
            {article.content}
          </div>

          {/* Action Row */}
          <div className="pt-6 border-t border-[#262626] flex flex-col sm:flex-row items-center justify-between gap-4">
            <button
              onClick={handleShareWhatsApp}
              className="inline-flex items-center gap-2 text-xs font-semibold text-neutral-400 hover:text-white transition-colors cursor-pointer"
            >
              <Share2 className="w-4 h-4 text-[#E10600]" />
              <span>Partager sur WhatsApp</span>
            </button>

            <div className="flex items-center gap-3 w-full sm:w-auto">
              {onExploreVehicles && (
                <button
                  onClick={() => {
                    onClose();
                    onExploreVehicles();
                  }}
                  className="px-4 py-2.5 bg-[#222222] hover:bg-[#333333] text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer flex-1 sm:flex-none text-center"
                >
                  Voir le catalogue
                </button>
              )}
              <button
                onClick={handleInquireArticle}
                className="px-5 py-2.5 bg-[#E10600] hover:bg-[#B00500] text-white text-xs font-bold uppercase tracking-wider rounded-lg flex items-center justify-center gap-2 transition-colors cursor-pointer flex-1 sm:flex-none shadow-lg shadow-[#E10600]/25"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Nous contacter à ce sujet</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
