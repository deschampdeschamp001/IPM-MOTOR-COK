import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { Vehicle, Lead, Brand } from '../types';

const rawUrl = import.meta.env.VITE_SUPABASE_URL;
const rawAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Check if valid URL and key are provided
export const isSupabaseConfigured = (): boolean => {
  if (!rawUrl || !rawAnonKey) return false;
  if (rawUrl.includes('your-project') || rawAnonKey.includes('your-anon-key')) return false;
  try {
    const url = new URL(rawUrl);
    return Boolean(url.protocol && url.host);
  } catch {
    return false;
  }
};

let clientInstance: SupabaseClient | null = null;

if (isSupabaseConfigured()) {
  clientInstance = createClient(rawUrl, rawAnonKey, {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
    },
  });
}

export const supabase = clientInstance;

/**
 * Fetch all available vehicles from Supabase
 * Sorted by is_featured DESC, created_at DESC
 */
export async function getVehiclesFromDB(): Promise<{ data: Vehicle[] | null; error: Error | null }> {
  if (!supabase) {
    return { data: null, error: new Error('Supabase non configuré') };
  }

  try {
    const { data, error } = await supabase
      .from('vehicles')
      .select('*')
      .eq('is_available', true)
      .order('is_featured', { ascending: false })
      .order('created_at', { ascending: false });

    if (error) {
      return { data: null, error: new Error(error.message) };
    }

    return { data: data as Vehicle[], error: null };
  } catch (err: any) {
    return { data: null, error: new Error(err.message || 'Erreur de connexion') };
  }
}

/**
 * Admin: Fetch all vehicles including hidden ones
 */
export async function getAllVehiclesForAdmin(): Promise<{ data: Vehicle[] | null; error: Error | null }> {
  if (!supabase) {
    return { data: null, error: new Error('Supabase non configuré') };
  }

  try {
    const { data, error } = await supabase
      .from('vehicles')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      return { data: null, error: new Error(error.message) };
    }

    return { data: data as Vehicle[], error: null };
  } catch (err: any) {
    return { data: null, error: new Error(err.message || 'Erreur') };
  }
}

/**
 * Admin: Add or update vehicle
 */
export async function saveVehicleToDB(vehicleData: Partial<Vehicle>): Promise<{ data: Vehicle | null; error: Error | null }> {
  if (!supabase) {
    return { data: null, error: new Error('Supabase non configuré') };
  }

  try {
    if (vehicleData.id) {
      // Update
      const { data, error } = await supabase
        .from('vehicles')
        .update(vehicleData)
        .eq('id', vehicleData.id)
        .select()
        .single();

      if (error) throw error;
      return { data: data as Vehicle, error: null };
    } else {
      // Insert
      const { data, error } = await supabase
        .from('vehicles')
        .insert([vehicleData])
        .select()
        .single();

      if (error) throw error;
      return { data: data as Vehicle, error: null };
    }
  } catch (err: any) {
    return { data: null, error: new Error(err.message || 'Erreur de sauvegarde') };
  }
}

/**
 * Admin: Delete vehicle
 */
export async function deleteVehicleFromDB(id: string): Promise<{ success: boolean; error: Error | null }> {
  if (!supabase) {
    return { success: false, error: new Error('Supabase non configuré') };
  }

  try {
    const { error } = await supabase.from('vehicles').delete().eq('id', id);
    if (error) throw error;
    return { success: true, error: null };
  } catch (err: any) {
    return { success: false, error: new Error(err.message || 'Erreur de suppression') };
  }
}

/**
 * Admin: Toggle visibility
 */
export async function toggleVehicleVisibility(id: string, is_available: boolean): Promise<{ success: boolean; error: Error | null }> {
  if (!supabase) {
    return { success: false, error: new Error('Supabase non configuré') };
  }

  try {
    const { error } = await supabase.from('vehicles').update({ is_available }).eq('id', id);
    if (error) throw error;
    return { success: true, error: null };
  } catch (err: any) {
    return { success: false, error: new Error(err.message) };
  }
}

/**
 * Public: Save a contact request / lead
 */
export async function recordLeadInDB(leadData: Omit<Lead, 'id' | 'created_at'>): Promise<{ data: Lead | null; error: Error | null }> {
  if (!supabase) {
    return { data: null, error: new Error('Supabase non configuré') };
  }

  try {
    const { data, error } = await supabase
      .from('leads')
      .insert([leadData])
      .select()
      .single();

    if (error) throw error;
    return { data: data as Lead, error: null };
  } catch (err: any) {
    return { data: null, error: new Error(err.message || 'Erreur d’enregistrement') };
  }
}

/**
 * Admin: Fetch all leads
 */
export async function getLeadsFromDB(): Promise<{ data: Lead[] | null; error: Error | null }> {
  if (!supabase) {
    return { data: null, error: new Error('Supabase non configuré') };
  }

  try {
    const { data, error } = await supabase
      .from('leads')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) throw error;
    return { data: data as Lead[], error: null };
  } catch (err: any) {
    return { data: null, error: new Error(err.message || 'Erreur') };
  }
}

/**
 * Public: Fetch active brands sorted by sort_order
 */
export async function getBrandsFromDB(): Promise<{ data: Brand[] | null; error: Error | null }> {
  if (!supabase) {
    return { data: null, error: new Error('Supabase non configuré') };
  }

  try {
    const { data, error } = await supabase
      .from('brands')
      .select('*')
      .eq('is_active', true)
      .order('sort_order', { ascending: true });

    if (error) {
      return { data: null, error: new Error(error.message) };
    }

    return { data: data as Brand[], error: null };
  } catch (err: any) {
    return { data: null, error: new Error(err.message || 'Erreur de connexion') };
  }
}

/**
 * Admin: Fetch all brands (including inactive)
 */
export async function getAllBrandsForAdmin(): Promise<{ data: Brand[] | null; error: Error | null }> {
  if (!supabase) {
    return { data: null, error: new Error('Supabase non configuré') };
  }

  try {
    const { data, error } = await supabase
      .from('brands')
      .select('*')
      .order('sort_order', { ascending: true });

    if (error) throw error;
    return { data: data as Brand[], error: null };
  } catch (err: any) {
    return { data: null, error: new Error(err.message || 'Erreur') };
  }
}

/**
 * Admin: Save or update brand
 */
export async function saveBrandToDB(brandData: Partial<Brand>): Promise<{ data: Brand | null; error: Error | null }> {
  if (!supabase) {
    return { data: null, error: new Error('Supabase non configuré') };
  }

  try {
    const brandName = brandData.name?.trim();

    // 1. If valid UUID id or existing record
    if (brandData.id && !brandData.id.startsWith('brand-')) {
      const { data, error } = await supabase
        .from('brands')
        .update({
          name: brandName,
          logo_url: brandData.logo_url,
          sort_order: brandData.sort_order,
          is_active: brandData.is_active,
        })
        .eq('id', brandData.id)
        .select()
        .single();

      if (!error && data) {
        return { data: data as Brand, error: null };
      }
    }

    // 2. Check if a brand with the same name already exists in Supabase
    if (brandName) {
      const { data: existingBrand } = await supabase
        .from('brands')
        .select('id')
        .ilike('name', brandName)
        .maybeSingle();

      if (existingBrand?.id) {
        const { data: updated, error: updateError } = await supabase
          .from('brands')
          .update({
            name: brandName,
            logo_url: brandData.logo_url,
            sort_order: brandData.sort_order,
            is_active: brandData.is_active,
          })
          .eq('id', existingBrand.id)
          .select()
          .single();

        if (updateError) throw updateError;
        return { data: updated as Brand, error: null };
      }
    }

    // 3. Brand does not exist yet: insert new
    const payload: any = {
      name: brandName || 'Marque',
      logo_url: brandData.logo_url || '',
      sort_order: brandData.sort_order || 1,
      is_active: brandData.is_active ?? true,
    };

    const { data, error } = await supabase
      .from('brands')
      .insert([payload])
      .select()
      .single();

    if (error) throw error;
    return { data: data as Brand, error: null };
  } catch (err: any) {
    return { data: null, error: new Error(err.message || 'Erreur de sauvegarde') };
  }
}

/**
 * Admin: Delete brand
 */
export async function deleteBrandFromDB(id: string): Promise<{ success: boolean; error: Error | null }> {
  if (!supabase) {
    return { success: false, error: new Error('Supabase non configuré') };
  }

  try {
    const { error } = await supabase.from('brands').delete().eq('id', id);
    if (error) throw error;
    return { success: true, error: null };
  } catch (err: any) {
    return { success: false, error: new Error(err.message || 'Erreur de suppression') };
  }
}

/**
 * Admin: Upload image to vehicle-images bucket
 */
export async function uploadVehicleImage(file: File): Promise<{ url: string | null; error: Error | null }> {
  if (!supabase) {
    return { url: null, error: new Error('Supabase non configuré') };
  }

  try {
    const fileExt = file.name.split('.').pop();
    const fileName = `${Date.now()}-${Math.random().toString(36).substring(2, 9)}.${fileExt}`;
    const filePath = `catalog/${fileName}`;

    const { error: uploadError } = await supabase.storage
      .from('vehicle-images')
      .upload(filePath, file, {
        cacheControl: '3600',
        upsert: false,
      });

    if (uploadError) throw uploadError;

    const { data } = supabase.storage
      .from('vehicle-images')
      .getPublicUrl(filePath);

    return { url: data.publicUrl, error: null };
  } catch (err: any) {
    return { url: null, error: new Error(err.message || 'Erreur de téléversement') };
  }
}

/**
 * Admin: Upload brand logo to brand-logos bucket
 */
export async function uploadBrandLogo(file: File): Promise<{ url: string | null; error: Error | null }> {
  if (!supabase) {
    return { url: null, error: new Error('Supabase non configuré') };
  }

  try {
    const fileExt = file.name.split('.').pop();
    const fileName = `${Date.now()}-${Math.random().toString(36).substring(2, 9)}.${fileExt}`;
    const filePath = `logos/${fileName}`;

    const { error: uploadError } = await supabase.storage
      .from('brand-logos')
      .upload(filePath, file, {
        cacheControl: '3600',
        upsert: false,
      });

    if (uploadError) throw uploadError;

    const { data } = supabase.storage
      .from('brand-logos')
      .getPublicUrl(filePath);

    return { url: data.publicUrl, error: null };
  } catch (err: any) {
    return { url: null, error: new Error(err.message || 'Erreur de téléversement du logo') };
  }
}
