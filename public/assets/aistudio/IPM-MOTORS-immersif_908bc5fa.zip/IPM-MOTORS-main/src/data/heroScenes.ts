/**
 * Scènes du hero "scroll immersif".
 *
 * Pour changer une photo : remplacez `image` par un fichier placé dans /assets/...
 * (ex: '/assets/cars/ma-photo.webp'). Utilisez des photos paysage ≥ 1600 px de large,
 * compressées en WebP/AVIF (< 250 Ko idéalement).
 *
 * Option vidéo : renseignez `video` sur la PREMIÈRE scène (mp4 muet, court, encodé avec
 * une image-clé toutes les 5 images : ffmpeg -g 5). Elle sera "scrubbée" par le scroll
 * à la place du simple dézoom de la photo.
 */
export interface HeroScene {
  id: string;
  image: string;
  /** object-position CSS de l'image (cadrage) */
  imagePosition?: string;
  /** point d'origine du dézoom (scène 1 uniquement) */
  zoomOrigin?: string;
  /** vidéo optionnelle, scrubbée par le scroll (scène 1 uniquement) */
  video?: string;
  /** gros mot qui monte derrière la scène */
  word: string;
  /** taille du gros mot en vw */
  wordSize: number;
  badge: string;
  title: string;
  subtitle: string;
  cta: string;
  link: string;
  /** libellé court dans la rail de navigation */
  rail: string;
}

export const HERO_INTRO = {
  badge: 'Showroom Riviera Bonoumin • 0 km',
  titleLight: 'L’Excellence Automobile',
  titleStrong: 'à votre portée.',
};

export const HERO_SCENES: HeroScene[] = [
  {
    id: 'showroom',
    image: '/assets/aistudio/814493891_122239370216113743_2889832111464126919_n_8772dda4.jpg',
    imagePosition: '50% 72%',
    zoomOrigin: '88% 92%',
    word: 'PREMIUM',
    wordSize: 15,
    badge: 'Showroom Riviera Bonoumin',
    title: 'Un parc 100 % neuf, prêt à rouler.',
    subtitle:
      'Pick-up, SUV et berlines 0 km alignés devant vous, disponibles pour une livraison immédiate à Abidjan.',
    cta: 'Voir les véhicules en stock',
    link: '/modeles',
    rail: 'Showroom',
  },
  {
    id: 'prestige',
    image: '/assets/cars/car_mercedes_sedan_1793116467102.jpg',
    imagePosition: '50% 60%',
    word: 'PRESTIGE',
    wordSize: 13,
    badge: 'Berlines de prestige',
    title: 'Le sommet du raffinement.',
    subtitle:
      'Berlines de direction et limousines d’exception : finitions grand luxe et technologies d’avant-garde.',
    cta: 'Découvrir les berlines',
    link: '/modeles?type=Berline',
    rail: 'Prestige',
  },
  {
    id: 'electrique',
    image: '/assets/cars/car_byd_seal_1793116465632.jpg',
    imagePosition: '50% 60%',
    word: 'ÉLECTRIQUE',
    wordSize: 11.5,
    badge: '100 % électrique • Blade Battery',
    title: 'La révolution électrique.',
    subtitle:
      'Autonomie WLTP 520 km, 0-100 km/h en 3,8 s et borne de recharge offerte pour chaque commande.',
    cta: 'Voir l’électrique',
    link: '/modeles?type=Électrique',
    rail: 'Électrique',
  },
  {
    id: 'suv-4x4',
    image: '/assets/cars/car_toyota_4x4_1793116466608.jpg',
    imagePosition: '50% 60%',
    word: 'SUV & 4X4',
    wordSize: 12.5,
    badge: 'SUV & tout-terrain',
    title: 'Faits pour les pistes comme pour la ville.',
    subtitle:
      'Des SUV et 4x4 neufs, Toyota, Jetour, Haval et plus, avec garantie constructeur dès la livraison.',
    cta: 'Découvrir les SUV',
    link: '/modeles?type=SUV',
    rail: 'SUV & 4x4',
  },
  {
    id: 'sur-mesure',
    image: '/assets/cars/hero_dealership_car_1793116464643.jpg',
    imagePosition: '50% 55%',
    word: 'SUR-MESURE',
    wordSize: 11.5,
    badge: 'Service clé en main',
    title: 'Votre véhicule neuf, sans compromis.',
    subtitle:
      'Immatriculation express, carte grise, garantie constructeur intégrale et livraison VIP à domicile.',
    cta: 'Découvrir nos services',
    link: '/apres-vente',
    rail: 'Sur-mesure',
  },
];
